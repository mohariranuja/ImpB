﻿
// File Name : common.JS
// Owner : Abhijit Khedkar
// Created Date : 17 Jul 2015

// Updated By :Ravsaheb Arkas
// Updated Date : 06 Aug 2015

// Updated By :Shankar Gupta
// Updated Date : 25 Sep 2015

// Comment: Removed bootstrap code and added code for sidebar menu

$window = $(window);
var $resize, $width = $window.width();
// on window resizing set sidebar hieght
$window.resize(function () { setHeight(); });
//set sidebar height equal to window height
var setHeight = function () { $('#nav').css('height', ($(window).height() - 65)); return true; }
//sidebar collapsible menu
$(document).on('click', '[data-ride="collapse"] a', function (e) { var $this = $(e.target), $active; $this.is('a') || ($this = $this.closest('a')); $active = $this.parent().siblings(".active"); $active && $active.toggleClass('active').find('> ul:visible').slideUp(200); ($this.parent().hasClass('active') && $this.next().slideUp(200)) || $this.next().slideDown(200); $this.parent().toggleClass('active'); $this.next().is('ul') && e.preventDefault(); setTimeout(function () { $(document).trigger('updateNav'); }, 300); });
var applicationUrl;
jQuery(document).ready(function ($) {
    setHeight();
    //Active current page menu
    $('ul.nav.nav-main > li').removeClass('active');
    $('li[data-active="' + $('#hd_a_page').val() + '"]').addClass('active');
    applicationUrl = $("#applicationUrl").val();
    bindBrandDivDropdown($('#BrandId option:selected').val());
    // Change Event of Brand Dropdown Selection List
    $("#BrandId").change(function () {
        bindBrandDivDropdown($(this).val());
    });
    $("#BrandDivisionID").change(function () {
            $.ajax({
                cache: false,
                type: "POST",
                url: applicationUrl + "Home/manageBrandDivId",    // Call Method to Fetch BrandDivision to Bind woth Dropdown
                data: { "id": $(this).val() },
                success: function (data) {

                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert('Failed to manage Brand Divisions.');

                }
            });
     
    });

    $("#BrandDivisionID").append($('<option selected="false"></option>').val('0').html('-Please select-'));   // Default item addedd into BrandDivision Dropdown

    //This event is for showing the pop-up window for File Upload 
    $('#BtnImport').click(function () {

        var brandvalue = $('#BrandId option:selected').val();
        var branddivvalue = $('#BrandDivisionID option:selected').val();
        var brandtext = $('#BrandId option:selected').text();
        var branddivtext = $('#BrandDivisionID option:selected').text();
        
        if (brandvalue !== '0' && branddivvalue !== '0') {    // Validation for Brand Drop Down and Division Drodpown
            showProcessing();
          
            $('#partial').dialog({
                autoOpen: false,
                width: 500,
                resizable: false,
                modal: true,
                cache:false,
                open: function (event, ui) {
                    $('.ui-dialog').addClass('hidden');
                    var url = applicationUrl + "Upload/Index";
                    $.ajax({
                        type: "GET",
                        url: url,
                        data: { brandId: brandvalue, brandDivisionId: branddivvalue },
                        async: false,
                        cache:false,
                        success: function (response) {
                            $('.ui-dialog').removeClass('hidden');
                            $('#partial').html(response);
                            $('.ui-widget').css({ 'margin-top': '-62px' });
                        },
                        error: function (error) {
                            alert("errror");
                        }
                    });

                }

            });
            $('#partial').dialog('open');
            $("#partial").dialog("option", "closeOnEscape", false);
            $("#partial").siblings('div.ui-dialog-titlebar').remove();
            stopProcessing()
           

        }
        else {
            alert("Please Select Brand and Brand Division");
        }


    });


    //This event is called when we upload the file.
    $('body').on('click', '#btnFileUpload', function () {
        showProcessing();
        var serviceURL = applicationUrl + 'Upload/LoadFile';

        var formdata = new FormData();
        var fileInput = $("#file-upload").get(0);
        var ddvalue = $("#ProductType").val();

        for (i = 0; i < fileInput.files.length; i++) {
            var file = document.getElementById("file-upload").files[i];
            formdata.append("Upload", file);
        }
        formdata.append("ProductType", ddvalue);
        formdata.append("BrandId", $("#BrandId").val());
        formdata.append("BrandDivisionId", $("#BrandDivisionId").val());

        $.ajax({
            type: "POST",
            url: serviceURL,
            data: formdata,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (data) {


                if (data.IsSuccess) {
                  
                    document.location.href = applicationUrl + 'Upload/Preview?parsedData=' + data.TransactionId;
                   
                }
                else {

                    $.get(data.Url, function (partial) {
                        stopProcessing();
                        $('#partial').html(partial);
                    });

                }

            },

            error: function (error, response) {
                stopProcessing();
                alert("Error while uploading file.Please try again");
            }
        });


    });
    $('body').on('click', '#btnFileUploadCancel', function () {
        $('#partial').dialog('close');
        return false;
    });
    //Redirect to upload history page
    $('.lnkUploadHistory').on('click', function () {

        var brandvalue = $('#BrandId option:selected').val();
        var branddivvalue = $('#BrandDivisionID option:selected').val();
        var url = applicationUrl + "UploadHistory/ViewHistory?brandId=" + parseInt(brandvalue) + "&brnadDivId=" + parseInt(branddivvalue) + "";

        window.location = url;
    });
});




// This function is used to start the processing/loading screen.
function showProcessing() {

    $("#divLoading").show();
}
// This function is used to stop the processing/loading screen.
function stopProcessing() {
    $("#divLoading").hide();
  
}

function bindBrandDivDropdown(selectedItem)
{
    if (selectedItem != 0) {
        showProcessing();
    }
   // var selectedItem = $(this).val();
    var ddlStates = $("#BrandDivisionID");
    $.ajax({
        cache: false,
        type: "GET",
        url: applicationUrl + "Home/GetBrandDivisionByCountryId",    // Call Method to Fetch BrandDivision to Bind woth Dropdown
        data: { "BrandId": selectedItem },
        success: function (data) {
            ddlStates.html('');
            ddlStates.append($('<option selected="false"></option>').val('0').html('-Please select-'));
            $.each(data, function (id, option) {
               
                if (option.selected) {
                   
                    ddlStates.append($('<option selected="true"></option>').val(option.id).html(option.name));
                }
                else {
                    ddlStates.append($('<option></option>').val(option.id).html(option.name));
                }
                // Data Addedd into dropdown for BrandDivision
            });
            stopProcessing();
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert('Failed to retrieve Brand Divisions.');
            stopProcessing();
        }
    });
}