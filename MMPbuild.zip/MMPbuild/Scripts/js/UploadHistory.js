﻿/*This file contains javascript code  for Preview page*/

// File Name : UploadHistory.JS
// Owner : Ravsaheb Arkas
// Created Date : 22 Jul 2015

// Updated By : Ravsaheb Arkas
// Updated Date : 20 Aug 2015

// Comment: This file is related to Upload History  Page javascript
var applicationUrl;
jQuery(document).ready(function ($) {
    //jQuery.noConflict();
    applicationUrl = $("#applicationUrl").val();

    var defaultFileId = $("#uploadedFileId").val();
    
    $("#td_" + defaultFileId).css('background-color', '#01A9DB').addClass('active');

    $("#hdnFileCount").val(parseInt($("#hdnPageSize").val()));
    //Make ajax call on filter change
    $('#SelectedFilter').change(function () {
        SearchItem($('#BrandId option:selected').val(), $('#BrandDivisionID option:selected').val());
    });

    // this event is fired when we check any of the product 
    $('body').on('click', '.chkProduct', function (e) {
        if (e.handled != true) {

            e.handled = true;
            if ($(".chkProduct").length == $(".chkProduct:checked").length) {
                $("#chkAllProducts").prop("checked", true);
            } else {
                $("#chkAllProducts").prop("checked", false);
            }

            if ($(this).prop('checked')) {
                if ($.inArray($(this).val(), selectedCheckbox) == -1)
                    selectedCheckbox.push($(this).val());
            }
            else {
                selectedCheckbox.pop($(this).val());
            }


            ShowHideEditProductsButton();
        }
    });

    // this event is fired when we change the page     
    $('body').on('click', 'a.paging', function (e) {
        if (e.handled != true) {

            var obj = {
                "page": $(this).attr("pageNumber"),
                "id": $("#uploadedFileId").val(),
                "rows": "50",
                "columnName": $("#SelectedProductFilter").val(),
                "searchVal": $("#txtProductFilter").val()

            }
            var data = JSON.stringify(obj);
            DisplayProducts(data);

            e.handled = true;
        }

        return false;
    });

    //This mehtod is usefull to search Products from database
    $('body').on('keyup', '#txtProductFilter', function (e) {
        if ($("#SelectedProductFilter").val() != "0") {
            SearchProducts();
        }
    });

    //This mehtod gets called when we change product filter
    $('body').on('change', '#SelectedProductFilter', function (e) {
        SearchProducts();
    })

    function SearchProducts() {
        var obj = {
            "page": "1",
            "id": $("#uploadedFileId").val(),
            "rows": "50",
            "columnName": $("#SelectedProductFilter").val(),
            "searchVal": $("#txtProductFilter").val()

        }
        var data = JSON.stringify(obj);
        DisplayProducts(data);
    }

    // This event is fired when click on 'Select all' Checkebox
    $('body').on('click', '#chkAllProducts', function (e) {
        if (e.handled != true) {

            $(".chkProduct").prop('checked', $(this).prop('checked'));


            if ($(this).prop('checked')) {
                $('.chkProduct').each(function () {
                    if ($.inArray($(this).val(), selectedCheckbox) == -1)
                        selectedCheckbox.push($(this).val());
                });
            }
            else {
                $('.chkProduct').each(function () {
                    selectedCheckbox.pop($(this).val());
                });

            }

            ShowHideEditProductsButton();

            e.handled = true;
        }

        return;
    });


    // This event is fired when click on 'Edit Products' Button
    $('body').on('click', '#btnEditProducts', function (e) {
        if (e.handled != true) {
            e.handled = true;

            $("#selProducts").val(selectedCheckbox);
            $("#frmPreviewFile").submit();
        }

    });
    $('body').on('click', '#ShowSelectedProducts', function (e) {
        if (e.handled != true) {
            e.handled = true;
            $("#lblSelProducts").html(selectedCheckbox.join(","))
        }
        return false;
    });
    //Filter Files on selected Brand
    $("#BrandId").change(function () { SearchItem($('#BrandId option:selected').val(), 0); });
    //Filter files depend on selected brand division 
    $("#BrandDivisionID").change(function () { SearchItem($('#BrandId option:selected').val(), $('#BrandDivisionID option:selected').val()); });


});
//This mehtod is usefull to get files from database on base filters
//function SearchItem() {
$("#txtFileFilter").keyup(function () {
    SearchItem($('#BrandId option:selected').val(), $('#BrandDivisionID option:selected').val());
});




//Search files baseed on selected brand.
function SearchItem(brandvalue, branddivvalue) {
   
    $.ajax({
        type: 'Post',
        url: applicationUrl + "UploadHistory/GetFiles",
        data: { SearchValue: document.getElementById('txtFileFilter').value, filterCriteria: $("#SelectedFilter").val(), totalRecords: 1, brandId: parseInt(brandvalue), brandDivId: parseInt(branddivvalue) },
        success: function (data) {
            
            $("#resultList").html(data);
            //Get First file id and filename from hidden field.
            if ($("#firstFileId").val() != null) {

                var res = $("#firstFileId").val().split(",");

                if (res != null) {
                    //call to get file products from database.
                    GetFileProducts(res[0], res[1]);
                }
            }
            else
            {
                //if not found any file refresh right product panel with not record found.
                GetFileProducts(0, '');
            }
           
            HideShowMore(data);
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
    $("#hdnFileCount").val(2);
   
}
//This mehtod is usefull to get files from database on base filters
function ShowMoreFiles() {
    var brandvalue = $('#BrandId option:selected').val();
    var branddivvalue = $('#BrandDivisionID option:selected').val();
    $.ajax({
        type: 'Post',
        url: applicationUrl + "UploadHistory/GetFiles",
        data: { SearchValue: document.getElementById('txtFileFilter').value, filterCriteria: $("#SelectedFilter").val(), totalRecords: parseInt($("#hdnFileCount").val()), brandId: parseInt(brandvalue), brandDivId: parseInt(branddivvalue) },
        success: function (data) {

            $("#resultList").append(data);
            HideShowMore(data);
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
    $("#hdnFileCount").val(parseInt($("#hdnFileCount").val()) + parseInt($("#hdnPageSize").val()));

}
//This mehtod is usefull to hide Show more button if there is no records.
function HideShowMore(data) {
   
    if (data.indexOf('Not Found Any Records') > -1) {
        $("#divShowMore").hide();
    }
    else { $("#divShowMore").show(); }
}
// This Method is usefull to get file product from Database
function GetProducts(td) {

    var selectedId = $(td).attr('id').split('_')[1];  
    GetFileProducts(selectedId, $(td).attr('name'));
}

//This method is usefull to refresh product from database
function GetFileProducts(selectedId,fileName)
{
    var td = '#td_' + selectedId + '';

    $(td).css('background-color', '#01A9DB').addClass('active');
    $('td').not($(td)).css('background-color', 'white').removeClass('active');
    document.getElementById('filename').innerHTML = "Preview File | " + fileName + "";
    $.ajax({
        type: 'Post',
        url: applicationUrl + "UploadHistory/GetProducts",
        data: { UploadedFileId: selectedId },
        success: function (data) {
            $("#productList").html(data);
            stopProcessing();
        },
        error: function (xhr, ajaxOptions, thrownError) {

            alert(xhr.status);
            alert(thrownError);
        }
    });
}

//This method is usefull to change file name.
function ChangeFileName(textbox) {

    $.ajax({
        type: 'Post',
        url: applicationUrl + "UploadHistory/ChangeFileName",
        data: { uploadedFileId: $(textbox).attr('id'), fileName: $(textbox).val() },
        success: function (data) {
            document.getElementById('filename').innerHTML = "Preview File | " + $(textbox).val() + "";
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}
$('.focus').on('focusout', function (item) {
    var model = DisplayName
    alert('data' + item.DisplayName);
});





