﻿// File Name : DashBoad.JS
// Owner : Abhijit Khedkar
// Created Date : 10 Jul 2015

// Updated By : Ravsaheb Arkas
// Updated Date :  06 Aug 2015

// Comment: This file is related to Home Page javascript

var applicationUrl;
jQuery(document).ready(function ($) {
  
   
});