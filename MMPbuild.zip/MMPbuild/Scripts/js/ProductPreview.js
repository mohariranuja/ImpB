﻿/*This file contains javascript code  for Preview page*/

// File Name : DashBoad.JS
// Owner : Abhijit Khedkar
// Created Date : 10 Jul 2015

// Updated By : Ashish Pathak
// Updated Date : 15 Jul 2015

// Comment: This file is related to Product Preview  Page javascript
var applicationUrl;

//Before Dom is loaded
//showProcessing();
 
jQuery(document).ready(function ($) {
    
    //jQuery.noConflict();
    applicationUrl = $("#applicationUrl").val();

    $('#partial').dialog({
        autoOpen: false,
        width: 700,
        resizable: false,
        modal: true

    });

    //Disable brand and branddivision drop down  on preview page
    $("#BrandId").prop("disabled", true);
    $("#BrandDivisionID").prop("disabled", true);
   
    //If Dom is loaded
    //stopProcessing();

    $(".table-body").scroll(function () {
        $(".table-header").offset({ left: -1 * this.scrollLeft +150 });
    });

    //Function for displaying all the error rows.
    $("#errorRows").click(function () {
        var rows = $('#productRows tr');
        var errorRows = rows.filter('.errorRow').show();
        rows.not(errorRows).hide();

    });
    //Function for redirecting on Home Page By Clicking Cancel button.
    $("#btnCancel").click(function () {
        document.location.href = applicationUrl + 'Home/Index';
    });

    //function defination for showing loading progress before submitting form
    var IsLoadingStarted = function () {
        showProcessing();
        return true;
    }
    //Function for saving Attritbute mapping and Product Data
    $("#btnSaveAttributeMapping").click(function () {

        if (IsLoadingStarted()) {
            SubmitForm();
        }

    });

    //Function to saving Attritbute mapping and Product Data 
    function SubmitForm() {
       
        var url = applicationUrl + "Upload/SaveAttributeMapping";
        $.ajax({
            type: "POST",
            url: url,
            asynch: true,
            data: $("#frmAttributeMapping").serialize(),
            async: false,
            success: function (data) {

                if (!data.IsSuccess) {
                    document.location.href = applicationUrl + 'Upload/Preview?parsedData=' + data.TransactionId;
                }
                else {
                    $(".errorSection").hide();
                   

                    $.get(data.Url, function (partial) {
                        $('#partial').hide();
                        $('#partial').html(partial);
                        $('#partial').dialog('open');
                        $("#partial").dialog("option", "closeOnEscape", false);
                        $("#partial").siblings('div.ui-dialog-titlebar').remove();
                        $('#partial').show();
                        stopProcessing();

                    });
                   
                    


                }
            },
            error: function (error) {
                alert("errror");
            }
        });
    }

    // this event is called when clicked on error text
    $(".errorMsg").click(function () {

        showProcessing();
        var errorLines = $(this).attr("errorLines");
        if (errorLines == "") {
            stopProcessing();
            return false;
        }

        if (errorLines == "0") {
            // To Show all rows
            var rows = $('#productRows tr');
            rows.show();
            stopProcessing();

        }
        else {
            // To Show rows those having selected error 
            var errorArr = errorLines.split(',');
            $.each($("#productRows").find("tr"), function () {

                var rowNumber = $(this).attr("id").split('_')[1];

                if ($.inArray(rowNumber, errorArr) == -1)
                    $(this).hide();
                else
                    $(this).show();
                stopProcessing();

            });
        }

    });
    // Added by Shankar Gupta on 29 Sep 2015
    //to create sticky table 
    $('.fixed-table-container').css('width', $('.panel').width());
    var iStart = new Date().getTime();
    var oTable = $('#table-large-columns').dataTable(
	{
	    "sScrollY": "412px",
	    "sScrollX": "100%",
	    "sScrollXInner": "150%",
	    "bScrollCollapse": true,
	    "bPaginate": false,
	    "bFilter": false,
	    "bSort": false
	});
});