﻿/*This file contains javascript code  for Preview page*/

// File Name : EditProduct.JS
// Owner : Ravsaheb Arkas
// Created Date : 3 Aug 2015

// Updated By : Ravsaheb Arkas
// Updated Date : 3 Aug 2015

// Comment: This file is related to Edit Product Page javascript
var applicationUrl;
jQuery(document).ready(function ($) {
    //jQuery.noConflict();
    applicationUrl = $("#applicationUrl").val();
});
$("#btnSaveProducts").click(function () {
  
    showProcessing();

    $.ajax({
        type: 'Post',
        url: applicationUrl + "ProductList/SaveProducts",
        data: $("#frmSaveProducts").serialize(),
        success: function (data) {
            stopProcessing();
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
   
});
