using Microsoft.AspNetCore.SignalR;

namespace viewer.Hubs
{
    public class GridEventsHub: Hub
    {
        public GridEventsHub()
        {            
        }
    }
}