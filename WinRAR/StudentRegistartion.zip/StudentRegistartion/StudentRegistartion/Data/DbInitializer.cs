﻿using StudentRegistartion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentRegistartion.Data
{
    public static class DbInitializer
    {
        public static void Initialize(StudentContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Students.Any())
            {
                return;   // DB has been seeded
            }

            var students = new Student[]
            {
            new Student{FirstName="Carson",LastName="Alexander",Address="Sadashiv Peth, Pune"},
            new Student{FirstName="Meredith",LastName="Alonso" ,Address="Laxmo Road, Pune"},
            new Student{FirstName="Arturo",LastName="Anand" ,Address="Somwar Peth, Pune"},
            new Student{FirstName="Gytis",LastName="Barzdukas",Address="Paud Phata, Pune"},
            new Student{FirstName="Yan",LastName="Li",Address="Datta wadi, Pune"},
            new Student{FirstName="Peggy",LastName="Justice",Address="Karve Road, Pune"},
            new Student{FirstName="Laura",LastName="Norman",Address="Pashan, Pune"},
            new Student{FirstName="Nino",LastName="Olivetto",Address="Bavdhan, Pune"}
            };
            foreach (Student s in students)
            {
                context.Students.Add(s);
            }
            context.SaveChanges();

            
        }
    }
}
