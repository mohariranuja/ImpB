﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentRegistartion.Models;
using Microsoft.EntityFrameworkCore;
using StudentRegistartion.Model;

namespace StudentRegistartion.Data
{
    public class StudentContext : DbContext
    {
        public StudentContext(DbContextOptions<StudentContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<UserRolesMapping> UserRolesMappings { get; set; }
        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().ToTable("User");
            modelBuilder.Entity<UserRolesMapping>().ToTable("UserRolesMapping");
            modelBuilder.Entity<Student>().ToTable("Student");
        }
    }
}
