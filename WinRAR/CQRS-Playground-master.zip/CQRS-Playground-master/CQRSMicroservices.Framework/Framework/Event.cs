﻿namespace CQRSMicroservices.Framework
{
  public abstract class Event
  {
    public abstract string ToJson();
  }
}