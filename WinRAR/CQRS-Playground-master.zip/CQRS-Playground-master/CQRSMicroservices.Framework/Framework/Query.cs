﻿namespace CQRSMicroservices.Framework
{
  public class Query
  {
  }
}