﻿namespace CQRSMicroservices.Framework
{
  public abstract class Command
  {
    public abstract string ToJson();
  }
}