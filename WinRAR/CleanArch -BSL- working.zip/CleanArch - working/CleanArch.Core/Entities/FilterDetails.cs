﻿namespace CleanArch.Core.Entities
{
    public class FilterDetails
    {
        public string FilterColumnName { get; set; } = null;
        public string FilterColumnOperator { get; set; } = null;
        public string FilterColumnValue { get; set; } = null;
    }
}
