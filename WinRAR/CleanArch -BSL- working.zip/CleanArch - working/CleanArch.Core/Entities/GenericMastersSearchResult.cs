﻿namespace CleanArch.Core.Entities
{
    public class GenericMastersSearchResult
    {
        public List<GenericMasterResult> genericMasterResultList { get; set; }
        public int? TotalCount { get; set; }
    }
}
