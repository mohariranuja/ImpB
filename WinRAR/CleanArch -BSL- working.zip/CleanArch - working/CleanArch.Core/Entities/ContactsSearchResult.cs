﻿namespace CleanArch.Core.Entities
{
    public class ContactsSearchResult
    {
        public List<ContactResult> contactResultList { get; set; }
        public int? TotalCount { get; set; }
    }
}
