﻿namespace CleanArch.Core.Entities
{
    public class ContactRequest
    {
       // [DefaultValue(null)]
      //  public int? Id { get; set; } = null;
     //   [DefaultValue(null)]
       // public int? RegionId { get; set; } = null;

        public string  SEARCH_TEXT { get; set; } = null;
        public string SORT_COLUMN_NAME { get; set; } = null;
        public string SORT_COLUMN_DIRECTION { get; set; } = null;
        public int? START_INDEX { get; set; } = null;
        public int? PAGE_SIZE { get; set; } = null;

    }
}
