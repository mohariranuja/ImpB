﻿
using System.ComponentModel;

namespace CleanArch.Core.Entities
{
    public class GenericSearchRequest
    {
        [DefaultValue(null)]
        public int? START_INDEX { get; set; } = null;
        [DefaultValue(null)]
        public int? PAGE_SIZE { get; set; } = null;

        public List<FilterDetails> filterDetails { get; set; } = null;
    }
}
