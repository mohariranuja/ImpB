﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArch.Core.Entities
{
    public class SortDetails
    {
        public string SORT_COLUMN_NAME { get; set; } = null;
        public string SORT_COLUMN_DIRECTION { get; set; } = null;
    }
}
