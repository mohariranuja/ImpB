﻿using System.ComponentModel;

namespace CleanArch.Core.Entities
{
    public class ContactRequests
    {
        //[DefaultValue(null)]
        //public int? CountryId { get; set; } = null;
        //[DefaultValue(null)]
        //public int? RegionId { get; set; } = null;
        [DefaultValue(null)]
        public int? StartIndex { get; set; } = null;
        [DefaultValue(null)]
        public int? PageSize { get; set; } = null;
        // public string  SEARCH_TEXT { get; set; } = null;

        public List<FilterDetails> filterDetails { get; set; } = null;
        //[DefaultValue(null)]
        //public List<SortDetails> sortDetails { get; set; } = null;       

    }
}
