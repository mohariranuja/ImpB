﻿using CleanArch.Core.Entities;
using CleanArch.Core.Interfaces;
using CleanArch.Core.Master;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace CleanArch.Infrastructure.Persistence
{
    public class ApplicationDBContext : DbContext, IApplicationDBContext
    {
        #region Ctor
        private string connectionString;
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
         : base(options)
        {
        }
        #endregion
        private string GetConnectionstring()

        {

            var builder = new ConfigurationBuilder();

             builder.AddJsonFile("appsettings.json", optional: false);
            //builder.Add("appsettings.json");
            var configuration = builder.Build();

            return configuration.GetConnectionString("DBConnection").ToString();

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        {

            if (string.IsNullOrEmpty(this.connectionString))

                this.connectionString = GetConnectionstring();

            optionsBuilder.UseSqlServer(this.connectionString);

        }

        #region DbSet
        public DbSet<AppSetting> AppSettings { get; set; }
        public DbSet<Core.Entities.Contact> Contacts { get; set; }
        public DbSet<ContactList> ContactLists { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
        }
        #endregion
        #region Methods
        public Task<int> SaveChangesAsync()
        {
            return base.SaveChangesAsync();
        }
        #endregion

    }
}
