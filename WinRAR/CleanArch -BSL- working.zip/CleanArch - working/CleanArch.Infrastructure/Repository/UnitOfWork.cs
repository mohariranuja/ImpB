﻿using CleanArch.Application.Interfaces;

namespace CleanArch.Infrastructure.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(IContactRepository contactRepository, IContactListRepository contactsListRepository)
        {
            Contacts = contactRepository;
            ContactsList = contactsListRepository;
        }

        public IContactRepository Contacts { get; set; }

        public IContactListRepository ContactsList { get; set; }
    }
}
