﻿
using System.Data;
using Microsoft.EntityFrameworkCore;

using System.Linq.Expressions;
using CleanArch.Infrastructure.Persistence;
using CleanArch.Application.Interfaces;
using CleanArch.Core.Entities;

namespace CleanArch.Infrastructure.Repository
{
    public class ContactListRepository : IContactListRepository
    {
        #region ===[ Private Members ]=============================================================

       
        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public ContactListRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
           
        }

        #endregion
        #region ===[ ICountryListRepository Methods ]==================================================

       

        async Task<IReadOnlyList<ContactList>> IContactListRepository.GetManyAsync(ContactRequest request)
        {
            return await _dbContext.ContactLists.FromSqlInterpolated<ContactList>($" sp_GetContactData {request.SEARCH_TEXT} ,{request.SORT_COLUMN_NAME},{request.SORT_COLUMN_DIRECTION} ,{request.START_INDEX},{request.PAGE_SIZE}").ToListAsync();
            // return await _dbContext.CountryLists.FromSqlInterpolated<CountryList>($" {StoreProc.Sp_GetCountryList} {request.CountryId} ,{request.RegionId}").ToListAsync();
        }

        public async Task<ContactsSearchResult> GetManyAsync1(
        Expression<Func<Contact, bool>> filter = null,
        Func<IQueryable<Contact>, IOrderedQueryable<Contact>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<Contact> query = _dbContext.Contacts;//.Where(x=>x.FirstName!="NA");

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            
            IQueryable<Contact> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var pagesitem = await query.ToListAsync();
            var contactResultList = new List<ContactResult>();
            foreach (Contact regMaster in pagesitem)
            {
                var list1 = new ContactResult { Id = regMaster.Id, FirstName = regMaster.FirstName, LastName= regMaster.LastName, Email= regMaster.Email, PhoneNumber= regMaster.PhoneNumber };
                contactResultList.Add(list1);
            }

            ContactsSearchResult result = new ContactsSearchResult();
            result.TotalCount = countSearch;
            result.contactResultList = contactResultList;
            return result;
        }



        #endregion
    }
}
