﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using CleanArch.Infrastructure.Persistence;
using CleanArch.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace CleanArch.Api.Filter
{
    public class ValidateEntityExistsAttribute<T> : IActionFilter where T : class, IEntity
    {
        private readonly ApplicationDBContext _context;

        public ValidateEntityExistsAttribute(ApplicationDBContext context)
        {
            _context = context;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            int id = 0;

            if (context.ActionArguments.ContainsKey("Id"))
            {
                id = (int)context.ActionArguments["id"];
            }
            else
            {
                context.Result = new BadRequestObjectResult("Bad id parameter");
                return;
            }
            DbSet<T> dbSet = _context.Set<T>();

            if (dbSet.SingleOrDefault(x => x.Id == id) != null)
            {
                context.HttpContext.Items.Add("entity", dbSet.SingleOrDefault(x => x.Id == id));
            }
            else
            {
                context.Result = new NotFoundResult();
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
        }
    }
}
