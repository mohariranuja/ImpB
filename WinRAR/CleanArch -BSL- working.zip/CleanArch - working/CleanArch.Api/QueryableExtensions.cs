﻿using CleanArch.Core.Entities;
using System;
using System.Linq.Expressions;

namespace CleanArch.Api
{
    public static class QueryableExtensions
    {
        public static IQueryable<T> SortBy<T>(this IQueryable<T> source,
            IEnumerable<string> fieldsToSort)
        {
            Expression expression = source.Expression;
            bool firstTime = true;

            foreach (var f in fieldsToSort)
            {
                // { x }
                var parameter = Expression.Parameter(typeof(T), "x");

                // { x.FIELD }, e.g, { x.ID }, { x.Name }, etc
                var selector = Expression.PropertyOrField(parameter, f);

                // { x => x.FIELD }
                var lambda = Expression.Lambda(selector, parameter);

                // You can include sorting directions for advanced cases
                var method = firstTime
                    ? "OrderBy"
                    : "ThenBy";

                // { OrderBy(x => x.FIELD) }
                expression = Expression.Call(
                    typeof(Queryable),
                    method,
                    new Type[] { source.ElementType, selector.Type },
                    expression,
                    Expression.Quote(lambda)
                );

                firstTime = false;
            }

            return firstTime
                ? source
                : source.Provider.CreateQuery<T>(expression);
        }

        


    }

    public class FilterHelper<T>
    {
        public static Expression<Func<T, bool>> getFilter(FilterDetails? objList)
        {
            ParameterExpression parameter = Expression.Parameter(typeof(T), "e");
            MemberExpression property = Expression.Property(parameter, objList!.FilterColumnName);
            MethodCallExpression? startsWithA = null;
            if (property.Type.Name == "String")
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            else if (property.Type.Name == "Int32")
            {

                startsWithA = Expression.Call(property, typeof(Int32).GetMethod(objList.FilterColumnOperator, [typeof(Int32)])!, Expression.Constant(Convert.ToInt32(objList.FilterColumnValue)));
            }
            else
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            Expression<Func<T, bool>> lambdaExpression = Expression.Lambda<Func<T, bool>>(startsWithA, parameter);
            return lambdaExpression;

        }
        public static Expression<Func<T, bool>> CombineFilters(List<Expression<Func<T, bool>>> filters)
        {
            if (filters.Count == 0)
            {
                return null;
            }

            Expression<Func<T, bool>> combinedFilter = filters[0];
            for (int i = 1; i < filters.Count; i++)
            {
                combinedFilter = CombineFilters(combinedFilter, filters[i]);
            }

            return combinedFilter;
        }

        private static Expression<Func<T, bool>> CombineFilters(Expression<Func<T, bool>> filter1, Expression<Func<T, bool>> filter2)
        {
            var parameter = Expression.Parameter(typeof(T));
            var combinedBody = Expression.AndAlso(
                Expression.Invoke(filter1, parameter),
                Expression.Invoke(filter2, parameter)
            );

            return Expression.Lambda<Func<T, bool>>(combinedBody, parameter);
        }
    }

    public class SortHelper<T>
    {
        // Example method to generate sort condition dynamically
        public static Func<IQueryable<T>, IOrderedQueryable<T>> GenerateSortCondition(List<SortDetails> sortCriteria)
        {
            var queryParam = Expression.Parameter(typeof(T), "p");
            Expression queryExpr = null;

            foreach (var criteria in sortCriteria)
            {
                var propertyExpr = Expression.Property(queryParam, criteria.SORT_COLUMN_NAME);
                var keySelector = Expression.Lambda(propertyExpr, queryParam);
                var orderByMethod = criteria.SORT_COLUMN_DIRECTION.ToLower() == "asc" ? "OrderBy" : "OrderByDescending";

                queryExpr = queryExpr == null
                            ? (Expression)Expression.Call(typeof(Queryable), orderByMethod, new Type[] { typeof(T), propertyExpr.Type }, Expression.Constant(null, typeof(IQueryable<T>)), keySelector)
                            : (Expression)Expression.Call(typeof(Queryable), "ThenBy", new Type[] { typeof(T), propertyExpr.Type }, queryExpr, keySelector);
            }

            return Expression.Lambda<Func<IQueryable<T>, IOrderedQueryable<T>>>(queryExpr, queryParam).Compile();
        }
        public static Func<IQueryable<T>, IOrderedQueryable<T>> GenerateSortCondition1(params (string property, bool ascending)[] sortCriteria)
        {
            var queryParam = Expression.Parameter(typeof(T), "p");
            Expression queryExpr = null;

            foreach (var criteria in sortCriteria)
            {
                var propertyExpr = Expression.Property(queryParam, criteria.property);
                var keySelector = Expression.Lambda(propertyExpr, queryParam);
                var orderByMethod = criteria.ascending ? "OrderBy" : "OrderByDescending";

                queryExpr = queryExpr == null
                            ? (Expression)Expression.Call(typeof(Queryable), orderByMethod, new Type[] { typeof(T), propertyExpr.Type }, Expression.Constant(null, typeof(IQueryable<T>)), keySelector)
                            : (Expression)Expression.Call(typeof(Queryable), "ThenBy", new Type[] { typeof(T), propertyExpr.Type }, queryExpr, keySelector);
            }

            return Expression.Lambda<Func<IQueryable<T>, IOrderedQueryable<T>>>(queryExpr, queryParam).Compile();
        }

    }

}
