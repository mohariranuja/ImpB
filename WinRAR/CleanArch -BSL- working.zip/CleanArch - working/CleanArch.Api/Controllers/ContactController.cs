﻿using CleanArch.Api.Filter;
using CleanArch.Api.Middleware;
using CleanArch.Api.Models;
using CleanArch.Application.Interfaces;
using CleanArch.Core.Entities;
using CleanArch.Logging;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;

namespace CleanArch.Api.Controllers
{
    public class ContactController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;

        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize ContactController by injecting an object type of IUnitOfWork
        /// </summary>
        public ContactController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }

        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpGet]
        public async Task<ApiResponse<List<Contact>>> GetAll()
        {
            
            var apiResponse = new ApiResponse<List<Contact>>();

           // try
           // {
                var data = await _unitOfWork.Contacts.GetAllAsync();
                apiResponse.Success = true;
                apiResponse.Result = data.ToList();
            /* }
             catch (SqlException ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("SQL Exception:", ex);
             }
             catch (Exception ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("Exception:", ex);
             }*/
            if (apiResponse.Result.Count == 0)
                throw new CustomException("Contacts not found. Try again");

            return apiResponse;
        }

        [HttpGet("{id}")]
        [ServiceFilter(typeof(ValidateEntityExistsAttribute<Contact>))]
        public async Task<ApiResponse<Contact>> GetById(int id)
        {

            var apiResponse = new ApiResponse<Contact>();

           // try
           // {
                var data = await _unitOfWork.Contacts.GetByIdAsync(id);
                apiResponse.Success = true;
                apiResponse.Result = data;
            /* }
             catch (SqlException ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("SQL Exception:", ex);
             }
             catch (Exception ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("Exception:", ex);
             }*/
            if (apiResponse.Result == null)
                throw new CustomException("Contact not found. Try again");
            return apiResponse;
        }

        [HttpPost]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ApiResponse<string>> Add(Contact contact)
        {
            var apiResponse = new ApiResponse<string>();

            //try
           // {
                var data = await _unitOfWork.Contacts.AddAsync(contact);
                apiResponse.Success = true;
                apiResponse.Result = data;
            /*  }
              catch (SqlException ex)
              {
                  apiResponse.Success = false;
                  apiResponse.Message = ex.Message;
                  Logger.Instance.Error("SQL Exception:", ex);
              }
              catch (Exception ex)
              {
                  apiResponse.Success = false;
                  apiResponse.Message = ex.Message;
                  Logger.Instance.Error("Exception:", ex);
              }*/
            if (apiResponse.Result == null)
                throw new CustomException("Error while adding the record.");

            return apiResponse;            
        }

        [HttpPut]
        [ServiceFilter(typeof(ValidationFilterAttribute))]
        public async Task<ApiResponse<string>> Update(Contact contact)
        {
            var apiResponse = new ApiResponse<string>();

           // try
           // {
                var data = await _unitOfWork.Contacts.UpdateAsync(contact);
                apiResponse.Success = true;
                apiResponse.Result = data;
            /* }
             catch (SqlException ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("SQL Exception:", ex);
             }
             catch (Exception ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("Exception:", ex);
             }*/
            if (apiResponse.Result == null)
                throw new CustomException("Contact not found. Try again");
            return apiResponse;
        }

        [HttpDelete]
        [ServiceFilter(typeof(ValidateEntityExistsAttribute<Contact>))]
        public async Task<ApiResponse<string>> Delete(int id)
        {
            var apiResponse = new ApiResponse<string>();

           // try
           // {
                var data = await _unitOfWork.Contacts.DeleteAsync(id);
                apiResponse.Success = true;
                apiResponse.Result = data;
            /* }
             catch (SqlException ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("SQL Exception:", ex);
             }
             catch (Exception ex)
             {
                 apiResponse.Success = false;
                 apiResponse.Message = ex.Message;
                 Logger.Instance.Error("Exception:", ex);
             }*/
            if (apiResponse.Result == null)
            {
                //throw new KeyNotFoundException("Contact not found. Try again");
                throw new CustomException("hjhjhj");
            }
            

            return apiResponse;
        }
        [HttpPost("getCountrySearchData")]
        public async Task<ApiResponse<ContactsSearchResult>> GetCountrySearchData(ContactRequests request)
        {
            var apiResponse = new ApiResponse<ContactsSearchResult>();
            Expression<Func<Contact, bool>> filterData = getFilterData(request)!;
            int? top = null;
            int? skip = null;
            if (request.StartIndex == 0)
            {
                top = null;
                skip = null;
            }
            if (request.StartIndex == 0 && request.PageSize == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.StartIndex == 0 && request.PageSize > 0)
            {
                top = request.PageSize;
                skip = null;
            }
            else
            {
                top = request.PageSize;
                skip = (request.StartIndex - 1) * request.PageSize;
            }

            var data = await _unitOfWork.ContactsList.GetManyAsync1(filterData, null, top, skip);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result.TotalCount == 0)
                throw new CustomException("No record Found");
            return apiResponse;
        }

        [NonAction]
        public Expression<Func<Contact, bool>>? getFilterData(ContactRequests request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<Contact, bool>>> obList = new List<Expression<Func<Contact, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(getFilter(kvp));
                }

                var combinedFilter = FilterHelper<Contact>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        [NonAction]
        public static Expression<Func<Contact, bool>> getFilter(FilterDetails? objList)
        {
            ParameterExpression parameter = Expression.Parameter(typeof(Contact), "e");
            MemberExpression property = Expression.Property(parameter, objList!.FilterColumnName);
            MethodCallExpression? startsWithA = null;
            if (property.Type.Name == "String")
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            else if (property.Type.Name == "Int32")
            {

                startsWithA = Expression.Call(property, typeof(Int32).GetMethod(objList.FilterColumnOperator, [typeof(Int32)])!, Expression.Constant(Convert.ToInt32(objList.FilterColumnValue)));
            }
            else
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            Expression<Func<Contact, bool>> lambdaExpression = Expression.Lambda<Func<Contact, bool>>(startsWithA, parameter);
            return lambdaExpression;

        }
        #endregion
    }
}
