﻿using CleanArch.Api.Middleware;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Reflection;
using System.Text.Json;

public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(httpContext, ex);
            }
        }
        private async Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            var response = context.Response;

        var errorResponse = new ResponseModel();
            
            switch (exception)
            {
                case CustomException ex:
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    errorResponse.responseMessage = ex.Message;
                    errorResponse.responseCode = (int)HttpStatusCode.InternalServerError;
                break;
             case ApplicationException ex:
                 if (ex.Message.Contains("Invalid token"))
                 {
                     response.StatusCode = (int)System.Net.HttpStatusCode.Forbidden;
                     errorResponse.responseMessage = ex.Message;
                     errorResponse.responseCode = (int)System.Net.HttpStatusCode.Forbidden;
                 break;
                 }
                 response.StatusCode = (int)HttpStatusCode.BadRequest;
                 errorResponse.responseMessage = ex.Message;
                 errorResponse.responseCode = (int)HttpStatusCode.BadRequest;
             break;
             case KeyNotFoundException ex:
                 response.StatusCode = (int)HttpStatusCode.NotFound;
                 errorResponse.responseMessage = ex.Message;
                 errorResponse.responseCode = (int)HttpStatusCode.NotFound;
             break;
            case SqlException ex:
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    errorResponse.responseMessage = ex.Message;
                    errorResponse.responseCode = (int)HttpStatusCode.InternalServerError;
                break;
            default:
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    errorResponse.responseMessage = "Sorry for inconvinience, we have been notified..";
                //  errorResponse.responseMessage = "Internal Server errors. Check Logs!";
                errorResponse.responseCode = (int)HttpStatusCode.InternalServerError;
                break;
            }
            _logger.LogError(exception.Message);
            var result = JsonSerializer.Serialize(errorResponse);
            await context.Response.WriteAsync(result);
        }
    }

