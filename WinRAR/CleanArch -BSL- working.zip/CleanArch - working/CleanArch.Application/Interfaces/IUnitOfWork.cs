﻿namespace CleanArch.Application.Interfaces
{
    public interface IUnitOfWork
    {
        IContactListRepository ContactsList { get; }
        IContactRepository Contacts { get; }
    }
}
