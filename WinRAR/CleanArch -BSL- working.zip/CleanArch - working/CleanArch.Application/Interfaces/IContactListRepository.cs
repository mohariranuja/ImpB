﻿using CleanArch.Core.Entities;
using System.Linq.Expressions;

namespace CleanArch.Application.Interfaces
{
    public interface IContactListRepository : IFilterRepository<ContactList>
    {
        public Task<IReadOnlyList<ContactList>> GetManyAsync(ContactRequest request);
      
        public  Task<ContactsSearchResult> GetManyAsync1(
          Expression<Func<Contact, bool>> filter = null,
          Func<IQueryable<Contact>, IOrderedQueryable<Contact>> orderBy = null,
          int? top = null,
          int? skip = null,
          params string[] includeProperties);
    }
}
