﻿using System.Web;
using System.Web.Mvc;

namespace Fundraise.MvcExample
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
