# Fundraise

[![Build status](https://ci.appveyor.com/api/projects/status/2k8rv0m891wxh783?svg=true)](https://ci.appveyor.com/project/alindgren/fundraise)

A .NET core library for building crowdfunding applications.  See [wiki](https://github.com/alindgren/Fundraise/wiki) for documentation.

This is a work-in-progress and is a learning project for me -- it's the first time I am working with .NET Core and Entity Framework.  While I am starting with an example MVC project, I am also planning to use this for an Umbraco package.

Feedback and contributions are welcome! Please [create an issue](https://github.com/alindgren/Fundraise/issues/new) to start a conversation or contact me on twitter [@alexlindgren](https://twitter.com/alexlindgren).
