﻿namespace Fundraise.Services
{
    interface IDonationService
    {
        void Donate(double amount);
    }
}
