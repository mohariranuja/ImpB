﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("DriverBehaviourRiskView")]
    public class DriverBehaviourRiskView
    {
        [Key]
        public int DriverBehaviourId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? Time_Entered { get; set; }
        public DateTime? EFFDate { get; set; }
        public int SeqNo { get; set; }
        public DateTime? Time_Recorded { get; set; }
        public string RiskIndex { get; set; }
        public int RiskIndexId { get; set; }
        public string Descr200 { get; set; }
        public string? EDOT_Descr { get; set; }
        public DateTime? Date2 { get; set; }
        public DateTime? Time_Edit { get; set; }
        public string DOT_Test_date { get; set; }
        public string DOT_Recordable { get; set; }
        public int IncidentTypeId { get; set; }
        public int IncidentValueId { get; set; }
        public int ViolationValueId { get; set; }
        public string IncidentType { get; set; }
        public string IncidentValue { get; set; }
        public string ViolationValue { get; set; }
        public string? DescrLong_Notes { get; set; }
        public bool? IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}