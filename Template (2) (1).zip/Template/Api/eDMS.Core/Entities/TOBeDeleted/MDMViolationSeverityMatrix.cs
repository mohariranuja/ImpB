﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("MDMViolationSeverityMatrix")]
    public class MDMViolationSeverityMatrix
    {
        [Key]
        public int ViolationSeverityMatrixId { get; set; }
        public int IncidentValue { get; set; }
        public int ViolationValue { get; set; }
        public string ViolationDescription { get; set; }
        public bool IsActiveViolationSeverityMatrix { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}