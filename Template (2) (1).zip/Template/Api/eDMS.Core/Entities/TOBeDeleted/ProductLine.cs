﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    [Table("ProductLine")]
    public class ProductLine
    {
        [Key]
        public int ProductLineId { get; set; }
        public string? Description { get; set; }
        public bool? IsActiveProductLine { get; set; }
        public string? ExternalSystemId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string? ProductLineCode { get; set; }
    }
}
