﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EverestVPS.Core.Entities
{
    [Table("mstEmployeeVPRate")]
    public class RateTemplateProductLine
    {
        [Key]
        [Column("EmpRateId")]
        public Int64 RateId { get; set; }       
        public string? PsoftId { get; set; }       
        public DateTime EffectiveDate { get; set; }        
        public string VPCode { get; set; }       
        public string? CurrencyId { get; set; }
        public byte GuaranteedDay { get; set; }       
        public decimal Rate { get; set; }
       // public bool IsActive { get; set; }
        public string ? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ? LastModifiedBy { get; set; }
        public DateTime? LastModificationDate { get; set; }
    }
}
