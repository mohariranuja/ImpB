﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("TestType")]
    public class TestType
    {

        [Key]
        public int TestTypeId { get; set; }
        public string TestTypeName { get; set; }
        public int TestCategoryId { get; set; }
        public string TestCategoryName { get; set; }
        public string FieldValue { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}