﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("MDMDriverType")]
    public class MDMDriverType
    {
        [Key]
        public int DriverTypeId { get; set; }
        public string DriverType { get; set; }
        public string DriverTypeDescription { get; set; }
        public bool IsActiveDriverType { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}