﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("DRIVER_LTYP")]
    public class DriverLTyp
    {
        [Key]
        public int DriverLTypId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public string LicenseType { get; set; }
        public string DriversLicNBR { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? IsActive { get; set; }
    }
}