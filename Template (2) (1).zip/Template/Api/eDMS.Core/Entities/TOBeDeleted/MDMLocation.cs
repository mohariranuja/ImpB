﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    [Table("MDMLocation")]
    public class MDMLocation
    {
        [Key]
        public int LocationId { get; set; }
        public string Locationcode { get; set; }
        public string LocationDescription { get; set; }
        public bool IsActiveLocation { get; set; }
        public int CreatedBy { get; set; }
        public string? Country { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
