﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("MDMRiskType")]
    public class MDMRiskType
    {
        [Key]
        public int RiskTypeId { get; set; }
        public string RiskType { get; set; }
        public string? RiskTypeDescription { get; set; }
        public int CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}