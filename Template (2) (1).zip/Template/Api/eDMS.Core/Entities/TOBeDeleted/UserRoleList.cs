﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    public class UserRoleList
    {
        [Key]
        public int UserRoleId { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public bool IsActiveUserRole { get; set; }
        public int CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }

        public DateTime? CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }

      //  public List<MdmRole> MdmRoles { get; set; }
    
        public bool IsGlobalAccess { get; set; }

        public int EmpId { get; set; }
        public string? EmplId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
      
        public string? ManagerName { get; set; }     

        public string ManagerCode { get; set; }
    }
}
