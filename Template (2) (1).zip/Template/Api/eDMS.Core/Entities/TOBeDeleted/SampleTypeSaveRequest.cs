﻿using System.ComponentModel.DataAnnotations;
namespace eDMS.Core.Model
{
    public class SampleTypeSaveRequest
    {
        [Key]
        public int SampleTypeId { get; set; }
        public int TestCategoryId { get; set; }
        //public string TestCategoryName { get; set; }
        public int TestTypeId { get; set; }
        //public string TestTypeName { get; set; }
        public string SampleTypeName { get; set; }
        public bool? IsActive { get; set; }
        public int CreatedBy { get; set; }
        public string FieldValue { get; set; }
    }
}