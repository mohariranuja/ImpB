﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("ApprovalHistory")]
    public class ApprovalHistory
    {
        [Key]
        public int ApprovalHistoryId { get; set; }
        public int ApproverEmployeeId { get; set; }
        public int LoginUserId { get; set; }
        public int DriverEmployeeId { get; set; }
        public bool? IsApproved { get; set; }
        public string ApproverFirstName { get; set; }
        public string ApproverLastName { get; set; }
        public string LoginFirstName { get; set; }
        public string LoginLastName { get; set; }
        public string DriverFirstName { get; set; }
        public string DriverLastName { get; set; }
        public DateTime EmailSendDate { get; set; }
        public DateTime? ResponseDate { get; set; }
        public int CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? HrEmployeeId { get; set; }
        public int? ManagerEmployeeId { get; set; }

    }
}