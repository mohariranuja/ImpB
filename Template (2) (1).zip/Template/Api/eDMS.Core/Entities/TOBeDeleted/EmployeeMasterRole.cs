﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    public class EmployeeMasterRole
    {
        [Key]
        public int EmpId { get; set; }
        public string? EmplId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ManagerName { get; set; }
        public string? HRStatus { get; set; }

        public string RoleName { get; set; }
        public int? RoleId { get; set; }

        public string ManagerCode { get; set; }
        public bool IsGlobalAccess { get; set; }
    }
}
