﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("MDMPsxlatitem")]
    [Keyless]
    public class Psxlatitem
    {
        public string FIELDNAME { get; set; }
        public string FIELDVALUE { get; set; }
        public DateTime? EFFDT { get; set; }
        public string XLATSHORTNAME { get; set; }
        public string EFF_STATUS { get; set; }
        public string XLATLONGNAME { get; set; }
        public DateTime? LASTUPDDATETIME { get; set; }
        public string LASTUPDOPRID { get; set; }
        public int SYNCID { get; set; }
    }
}