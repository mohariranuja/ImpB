﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("TestResult")]
    public class TestResult
    {
        [Key]
        public int TestResultId { get; set; }
        public int TestCategoryId { get; set; }
        public string TestCategoryName { get; set; }
        public int TestTypeId { get; set; }
        public string TestTypeName { get; set; }
        public string TestResultName { get; set; }
        public bool? IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string FieldValue { get; set; }
    }
}