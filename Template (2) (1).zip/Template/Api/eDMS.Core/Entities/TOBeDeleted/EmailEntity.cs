﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Entities
{
    public class EmailEntity
    {
        [Required]
        [RegularExpression(eDMSConstant.eMailRegx)]
        public string From { get; set; }
        [Required]
        [RegularExpression(eDMSConstant.eMailRegx)]
        public string To { get; set; }
        [Required]
        public string Subject { get; set; }
        [Required]
        public string Body { get; set; }
        public IFormFile Attachment { get; set; }
    }
}