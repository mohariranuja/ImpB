﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    [Table("MDMLegalEntity")]
    public class MDMLegalEntity
    {
        [Key]
        public int LegalEntityId { get; set; }
        public string LegalEntityName { get; set; }
        public string? LegalEntityDesc { get; set; }
        public string? Country { get; set; }

        public string? Address { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string? ExtendedSystemId { get; set; }

	

	
    }
}
