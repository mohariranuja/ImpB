﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("DOTDrug_AlcoholTest")]
    public class DOTDrug_AlcoholTest
    {
        [Key]
        public int DOTDrug_AlcoholTestId { get; set; }
        public int EmployeeId { get; set; }
        public string EmpId { get; set; }
        public int TestCategoryId { get; set; }
        public string ExamCategory { get; set; }
        public DateTime? ExamDate { get; set; }
        public string ExamType { get; set; }
        public string Agency { get; set; }
        public string SampleType { get; set; }
        public string PhysicianId { get; set; }
        public string PhysicianName { get; set; }
        public string TestResultDrug { get; set; }
        public string TestNumber { get; set; }
        public string Description { get; set; }
        public string Disposition { get; set; }
        public string Amphetamine { get; set; }
        public string Cocaine { get; set; }
        public string Marijuana { get; set; }
        public string Opiates { get; set; }
        public string Phencyclidine { get; set; }
        public string Other { get; set; }
        public string? Comments { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? IsActive { get; set; }
    }
}