﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    [Table("MDMRiskIndex")]
    public class MDMRiskIndex
    {

        [Key]
        public int RiskIndexId { get; set; }
        public string RiskIndex { get; set; }
       

        public int CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }
        public bool? IsActiveRiskIndex { get; set; }
        public DateTime? ModifiedOn { get; set; }
       
      
    }
}
