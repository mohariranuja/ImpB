﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("DriverLicense")]
    public class DriverLicense
    {
        [Key]
        public int DriverLicId { get; set; }
        public string EMPLId { get; set; }
        public int EmployeeId { get; set; }
        public decimal SEQNUM { get; set; }
        public DateTime? ExpirationDT { get; set; }
        public string LicenseType { get; set; }
        public string DriverLicenseNumber { get; set; }
        public string State { get; set; }
        
        public int RiskIndexId { get; set; }
        public string CompanySanctionedDriver { get; set; }
       // public string DQRecComplete { get; set; }
        public string QualifiedDriver { get; set; }
        public string SERV_PERMIT { get; set; }
        public string CDL_LICENSE { get; set; }
        public string DOT_ASSOC_NO { get; set; }
        public string DriverType { get; set; }
        public string Country { get; set; }
        public int CountryId { get; set; }
        public DateTime? ValidFromDate { get; set; }
        public DateTime? EXPIRATN_DT { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public decimal Violations { get; set; }
        public decimal NUMBER_OF_PTS { get; set; }
        public string LIC_SUSPENDED_SW { get; set; }
        public string ISSUED_BY_FRA { get; set; }
        public string ISSUE_DEST_FRA { get; set; }
        public string Permission { get; set; }
        public DateTime? PR_EMP_DG_TST { get; set; }
        public string DISA_NBR { get; set; }
        public string LIC_SUSPENDED { get; set; }
        public string EmployeeCode { get; set; }
        public string PRE_EMPLMNT_TYPE { get; set; }
        public string PREREQ { get; set; }
        public int? OverAllRiskIndexId { get; set; }
        public int? AbstractRiskIndexId { get; set; }
        public int? HOSRiskIndexId { get; set; }
        public int? VOPERiskIndexId { get; set; }
        public int? BehaviorRiskIndexId { get; set; }
        public string DL_PRIMARY { get; set; }
        public string? Comments { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? TerminationDate { get; set; }
        public int? StateId { get; set; }
        public int? LicenseTypeId { get; set; }
        public int? DriverTypeId { get; set; }
    }
}