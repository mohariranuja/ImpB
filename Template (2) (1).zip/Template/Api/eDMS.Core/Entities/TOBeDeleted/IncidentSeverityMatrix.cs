﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("MDMIncidentSeverityMatrix")]
    public class IncidentSeverityMatrix
    {
        [Key]
        public int IncidentSeverityMatrixId { get; set; }
        public int IncidentValue { get; set; }
        public int IncidentTypeId { get; set; }
        public int RiskIndexId { get; set; }
        public string IncidentSeverityMatrixDescription { get; set; }
        public bool IsActiveIncidentSeverityMatrix { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}