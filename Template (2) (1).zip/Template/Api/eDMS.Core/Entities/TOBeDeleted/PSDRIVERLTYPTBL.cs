﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("PS_DRIVER_LTYP_TBL")]
    public class PSDRIVERLTYPTBL
    {
        [Key]
        public int DriverLTypTblId { get; set; }
        public string Country { get; set; }
        public string LicenseType { get; set; }
        public DateTime EFFDate { get; set; }
        public string EFFStatus { get; set; }
        public string Descr { get; set; }
        public string SystemDataFlag { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? IsActive { get; set; }
    }
}