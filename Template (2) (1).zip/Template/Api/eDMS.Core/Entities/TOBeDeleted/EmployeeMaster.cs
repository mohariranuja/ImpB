﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("EmployeeMaster")]
    public class EmployeeMaster
    {
        [Key]
        public int EmpId { get; set; }
        public string? EmplId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string? MiddleName { get; set; }
        public int ManagerId { get; set; }
        public int LocationId { get; set; }
        public int PositionId { get; set; }
        public string? DriverType { get; set; }
        public int CountryId { get; set; }
        public bool? IsQualifiedDriver { get; set; }
        public bool? IsHRActive { get; set; }
        public DateTime? LastLoggedIn { get; set; }
        public string? PreferredLanguage { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public string? EmpType { get; set; }
        public string? HRStatus { get; set; }
        public string? EmpStatus { get; set; }
        public string? AlternateName { get; set; }
        public string? SecondLastName { get; set; }
        public string? DisplayName { get; set; }
        public string? HRId { get; set; }
        public string? HRName { get; set; }
        public string? FullTimePartTime { get; set; }
        public DateTime? HireDate { get; set; }
        public string? HireCountry { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string? Sex { get; set; }
        public string? MaritalStatus { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? CountryOfBirth { get; set; }
        public string? EmailId { get; set; }
        public string? Nationality { get; set; }
        public string? CompanySanctionedDriver { get; set; }
        public string? CommercialDriverLicense { get; set; }
        public string? Country { get; set; }
        public string? State { get; set; }
        public string? ProductLine { get; set; }
        public string? ProductLineDescription { get; set; }
        public string? SubProductLine { get; set; }
        public string? SubProductLineDescription { get; set; }
        public string? Location { get; set; }
        public string? LocationDescription { get; set; }
        public string? DepartmentId { get; set; }
        public string? DepartmentDescription { get; set; }
        public string? JobCode { get; set; }
        public string? JobCodeDescription { get; set; }
        public string? PositionDescription { get; set; }
        public string? ReportsTo { get; set; }
        public string? ReportsToDescription { get; set; }
        public string? ManagerName { get; set; }
        public string? BusinessUnit { get; set; }
        public string? BusinessUnitDescription { get; set; }
        public string? Devision { get; set; }
        public string? DevisionDescription { get; set; }
        public string? Region { get; set; }
        public string? CostCenter { get; set; }
        public string? Action { get; set; }
        public string? ActionReason { get; set; }
        public string ManagerCode { get; set; }
    }
}