﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("DL_UPLD_WRK")]
    public class DLUPLDWRK
    {
        [Key]
        public int DL_UPLD_WRK_Id { get; set; }
        public string EMPLId { get; set; }
        public int EmployeeId { get; set; }
        public string DocCategory { get; set; }
        public string DLDocType { get; set; }
        public DateTime? DLUpldDate { get; set; }
        public DateTime? ValidFromDate { get; set; }
        public DateTime? ValidToDate { get; set; }
        public string RiskIndex { get; set; }
        public int RiskIndexId { get; set; }
        public string MandatoryItem { get; set; }
        public string? UploadStatus { get; set; }
        public string? NotComplete { get; set; }
        public string? ReviewStatus { get; set; }
        public string? ViewDetailBetween { get; set; }
        public string? Upload_Tc_Units_PB { get; set; }
        public string? DL_Doc_Head { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? IsActive { get; set; }
    }
}