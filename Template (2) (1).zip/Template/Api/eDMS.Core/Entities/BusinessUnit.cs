﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Entities
{
    [Table("BusinessUnit")]
    public class BusinessUnit
    {
        [Key]
        public int BusinessUnitId { get; set; }
        public string BusinessUnitName { get; set; }        
        public bool? IsBusinessUnitActive { get; set; }
        public string? ExtendedSystemId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}





