﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("MDMCountry")]
    public class Country
    {
        [Key]
        public int CountryId { get; set; }
        public int RegionId { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public int CreatedBy { get; set; }
        public bool IsActiveAgency { get; set; }
    }
}