﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Entities
{
    [Table("HoursOfService")]
    public class HoursOfService
    {
        [Key]
        public int HoursOfServiceId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public decimal SequenceNo { get; set; }
        public DateTime? Date1 { get; set; }
        public string DocumentType { get; set; }
        public DateTime? DLUploadDate { get; set; }
        public string MonthXLAT { get; set; }
        public string YearCD { get; set; }
        public int RegionId { get; set; }
        public string Region { get; set; }
        public int CountryId { get; set; }
        public string Country { get; set; }
        public string? DocOrgName { get; set; }
        public string? DocServerName { get; set; }
        public string? LastUpdOprId { get; set; }
        [Timestamp]
        public byte[]? LastUpdDtTm { get; set; } = Array.Empty<byte>();
        public string? ServerPath { get; set; }
        public string? ServerRoot { get; set; }
        public string? UploadStatus { get; set; }
        public string Submitted { get; set; }
        public string GovtAudited { get; set; }
        public string? MinorViolation { get; set; }
        public string MajorViolation { get; set; }
        public string? DocViewDownload { get; set; }
        public string? DocModify { get; set; }
        public string RiskIndex { get; set; }
        public int RiskIndexId { get; set; }
        public string IncidentType { get; set; }
        public int IncidentTypeId { get; set; }
        public string IncidentValue { get; set; }
        public int IncidentValueId { get; set; }
        public string? EDotDesc { get; set; }
        public string? DescLongNotes { get; set; }
        public string? Comments { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool? IsActive { get; set; }
    }
}