﻿namespace eDMS.Core
{
    public class CommonMethods
    {
        public string GetDocumentCategory(string driverType, string cdlLicense)
        {
            string documentCategory = string.Empty;
            if (driverType == eDMSConstant.driverTypeDOT && cdlLicense == eDMSConstant.yes)
                documentCategory = driverType + eDMSConstant.documentCategoryCDL;
            else if (driverType == eDMSConstant.driverTypeDOT && cdlLicense == eDMSConstant.no)
                documentCategory = driverType + eDMSConstant.documentCategoryNONCDL;
            if (driverType == eDMSConstant.driverTypeNDOT)
                documentCategory = eDMSConstant.documentCategoryNONDOT;
            return documentCategory;
        }

        public string GetDocType(string region, string driverType)
        {
            string docType = string.Empty;
            if (region.Contains(eDMSConstant.canadaCode))
                docType = eDMSConstant.abstrPROD; //"ABSTR_PROD";
            else if (region.Contains(eDMSConstant.usCode))
            {
                if (driverType == eDMSConstant.driverTypeDOT)
                    docType = eDMSConstant.anlrevFRM; //"ANLREV_FRM";

                else if (driverType == eDMSConstant.driverTypeNDOT)
                    docType = eDMSConstant.drvMVRRCD; //"DRV_MVRRCD";
            }
            else
                docType = eDMSConstant.drvMVRRCD; //"DRV_MVRRCD";

            return docType;
        }
    }
}