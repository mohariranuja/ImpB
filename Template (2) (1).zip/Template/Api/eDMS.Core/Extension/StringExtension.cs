﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Extension
{
   
    public static class StringExtension
    {
        public static bool IsNullOrEmpty(this string value )
        {
            return string.IsNullOrEmpty( value );
        }
        public static void ThrowIfNull<T>(this T obj, string paramName)
        {
            if ( obj == null )
            {
                throw new ArgumentNullException(paramName);
            }
        }

        public static bool Is<T>(this string s)
        {
            TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
            try
            {
                object val = converter.ConvertFromInvariantString(s);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static DateTime GetDateFromString(this string dateString)
        {
            if(!string.IsNullOrEmpty( dateString ))
            {
                DateTime result;
                var isValidDate = DateTime.TryParse( dateString, out result );
                return isValidDate?result :DateTime.MinValue;
            }
            return DateTime.MinValue;
        }
    }
}
