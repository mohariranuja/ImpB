﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class CountryRequest
    {
        [DefaultValue(null)]
        public int? CountryId { get; set; } = null;
        [DefaultValue(null)]
        public int? RegionId { get; set; } = null;

        public string  SEARCH_TEXT { get; set; } = null;
        public string SORT_COLUMN_NAME { get; set; } = null;
        public string SORT_COLUMN_DIRECTION { get; set; } = null;
        public int? START_INDEX { get; set; } = null;
        public int? PAGE_SIZE { get; set; } = null;

    }
}
