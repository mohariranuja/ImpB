﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class DriverRiskInfo
    {
        [Key]
        public int DriverRiskId { get; set; }
        public int DriverLicenseId { get; set; }
        public int RiskTypeId { get; set; }
        public int RiskIndexValueId { get; set; }
        public string RiskType { get; set; }
        public string RiskIndex { get; set; }
    }
}
