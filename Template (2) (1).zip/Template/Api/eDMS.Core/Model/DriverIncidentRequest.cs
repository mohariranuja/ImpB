﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class DriverIncidentRequest
    {
        [Key]
        public int DriverBehaviourId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? Time_Entered { get; set; }
        public int IncidentTypeId { get; set; }
        public int IncidentValueId { get; set; }
        public int ViolationSeverityMatrixId { get; set; }
        public int RiskIndexId { get; set; }
        public string Descr200 { get; set; }
        public string DescrLong_Notes { get; set; }
        public DateTime? Date2 { get; set; }
        public DateTime? Time_Recorded { get; set; }
        public DateTime? EFFDate { get; set; }
        public DateTime? Time_Edit { get; set; }
        public string DOT_Test_date { get; set; }
        public string DOT_Recordable { get; set; }
        public int LoginEmpId { get; set; }
    }
}