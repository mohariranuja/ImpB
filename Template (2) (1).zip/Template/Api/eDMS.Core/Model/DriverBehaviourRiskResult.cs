﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class DriverBehaviourRiskResult
    {
        [Key]
        public int DriverBehaviourId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? Time_Entered { get; set; }
        public int IncidentTypeId { get; set; }
        public string IncidentType { get; set; }
        public int IncidentValueId { get; set; }
        public string IncidentValue { get; set; }
        public int ViolationValueId { get; set; }
        public string ViolationValue { get; set; }
        public bool? IsActive { get; set; }
        public string RiskIndex { get; set; }
        public int RiskIndexId { get; set; }
        public string Descr200 { get; set; }
        public string? DescrLong_Notes { get; set; }
        public DateTime? Date2 { get; set; }
        public DateTime? TIME_RECORDED { get; set; }
        public DateTime? EFFDate { get; set; }
        public DateTime? TIME_EDIT { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}