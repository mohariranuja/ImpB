﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class CountryList
    {
        [Key]
        public int CountryId { get; set; }
        public int RegionId { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }        
        public int CreatedBy { get; set; }
        //public DateTime CreatedDate { get; set; }
        //public string LastModifiedBy { get; set; }
        //public DateTime LastModifiedDate { get; set; }
    }
}
