﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class CountryRequests
    {
        //[DefaultValue(null)]
        //public int? CountryId { get; set; } = null;
        //[DefaultValue(null)]
        //public int? RegionId { get; set; } = null;
        [DefaultValue(null)]
        public int? StartIndex { get; set; } = null;
        [DefaultValue(null)]
        public int? PageSize { get; set; } = null;
        // public string  SEARCH_TEXT { get; set; } = null;

        public List<FilterDetails> filterDetails { get; set; } = null;
        //[DefaultValue(null)]
        //public List<SortDetails> sortDetails { get; set; } = null;       

    }
}
