﻿namespace eDMS.Core.Model
{
    public class DriverLicenseRequest
    {
        public int EmployeeId { get; set; }
        public string EmpId { get; set; }
        public List<string> LicenseType { get; set; }        
        public string SERV_PERMIT { get; set; }
        public DateTime EXPIRATN_DT { get; set; }
        public DateTime EXPIRATION_DT { get; set; }
        public DateTime PR_EMP_DG_TST { get; set; }
        public string PRE_EMPLMNT_TYPE { get; set; }
        public string CDL_LICENSE { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string DISA_NBR { get; set; }
        public string DOT_ASSOC_NO { get; set; }
        public string DriverEvaluationRisk { get; set; }
        public string HOSComplianceRisk { get; set; }
        public string DriverBehaviorRisk { get; set; }
    }
}