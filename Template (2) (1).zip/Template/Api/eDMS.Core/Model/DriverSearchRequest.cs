﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class DriverSearchRequest
    {
       // [DefaultValue(null)]
        public int? EmpId { get; set; } = null;
        public string? EmplId { get; set; }// = null;
        //[DefaultValue(null)]
        public string FirstName { get; set; }// = null;
      // [DefaultValue(null)]
        public string LastName { get; set; } //= null;
      //  [DefaultValue(null)]
        public string SecondLastName { get; set; } //= null;
       // [DefaultValue(null)]
        public string AlternateCharacterName { get; set; } //= null;

       // [DefaultValue(null)]
        public string LocationCode { get; set; } //= null;

        //public int ManagerId { get; set; }

        //[DefaultValue(null)]
        public string ManagerName { get; set; }// = null;

        //[DefaultValue(null)]
        public string HRStatus { get; set; } //= null;
      //  [DefaultValue(true)]
        public string IsDriverEvaluator { get; set; }
        public int LoggedInUserId { get; set; }
        public bool IsGlobalAccess { get; set; }

        public int? START_INDEX { get; set; } = null;
        public int? PAGE_SIZE { get; set; } = null;

        public string ManagerCode { get; set; }

    }
}
