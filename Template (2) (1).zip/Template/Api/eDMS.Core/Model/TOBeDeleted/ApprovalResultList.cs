﻿namespace eDMS.Core.Model
{
    public class ApprovalResultList
    {
        public List<ApprovalResult> approvalResult { get; set; }
        public int? TotalCounts { get; set; }
    }
}