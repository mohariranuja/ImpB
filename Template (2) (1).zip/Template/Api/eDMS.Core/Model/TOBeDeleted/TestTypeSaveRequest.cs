﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eDMS.Core.Model
{
    public class TestTypeSaveRequest
    {
        [Key]
        public int TestTypeId { get; set; }
        public string TestTypeName { get; set; }
        public int TestCategoryId { get; set; }
        public string FieldValue { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
    }
}
