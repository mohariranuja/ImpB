﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class AuditReportResponse
    {
        [Key]
        public int DriverRiskId { get; set; }
        public string RiskIndex { get; set; }
        public DateTime ModifiedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public string? ModifiedByName { get; set; }
    }
}