﻿namespace eDMS.Core.Model
{
    public class TestCategoryResponse
    {
        public List<TestCategoriesResponse> TestCategoryResponseList { get; set; }
        public int? TotalCount { get; set; }
    }
}