﻿namespace eDMS.Core.Model
{
    public class MDMManagerAccessSearchResult
    {
        public List<MDMManagerAccessResult> managerUserAccess { get; set; }
        public int? TotalCount { get; set; }
    }
}