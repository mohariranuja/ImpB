﻿namespace eDMS.Core.Model
{
    public class AgencyResponseList
    {
        public List<AgencyResponse> agencyResponseList { get; set; }
        public int TotalCount { get; set; }
    }
}