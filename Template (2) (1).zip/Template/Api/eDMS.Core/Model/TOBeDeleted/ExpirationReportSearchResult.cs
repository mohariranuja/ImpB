﻿using eDMS.Core.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class ExpirationReportSearchResult
    {

        [Key]
          //  public int EmpId { get; set; }
            [DisplayName("Employee Code")]
             public string? EmplId { get; set; }
            [DisplayName("First Name")]
            public string FirstName { get; set; }
        [DisplayName("Middle Name")]
        public string? MiddleName { get; set; }
        [DisplayName("Last Name")]
            public string LastName { get; set; }
        
            //[DisplayName("Second Last Name")]
            //public string? SecondLastName { get; set; }
            //[DisplayName("Alternate Name")]
            //public string? AlternateName { get; set; }
           
            [DisplayName("Location Code")]
            public string? Location { get; set; }
        //[DisplayName("Location Description")]
        // public string? LocationDescription { get; set; }
            [DisplayName("Manager Code")]
            public string ManagerCode { get; set; }
            [DisplayName("Manager Name")]              
              public string? ManagerName { get; set; }
            [DisplayName("HR Status")]
            public string? HRStatus { get; set; }
            [DisplayName("Driver Evaluator")]
            public string? DriverEvaluator { get; set; }
            [DisplayName("Qualified Driver")]
            public string QualifiedDriver { get; set; }

                [DisplayName("DQ Status")]
                public string DQRecComplete { get; set; }
        [DisplayName("Vehicle Driver Type")]
        public string DriverType { get; set; }

        [DisplayName("Business Unit Description")]
        public string? BusinessUnitDescription { get; set; }

        [DisplayName("Region Name")]
        public string? RegionName { get; set; }

        [DisplayName("Product Line")]
        public string? ProductLineCode { get; set; }
        [DisplayName("Product Line Description")]
        public string? ProductLineDescription { get; set; }
        [DisplayName("Sub Product Line")]
        public string? SubProductLineCode { get; set; }
        [DisplayName("Sub Product Line Description")]
        public string? SubProductLineDescription { get; set; }
        [DisplayName("Department Description")]
        public string? DepartmentDescription { get; set; }
        [DisplayName("Driver License Number")]
        public string DriverLicenseNumber { get; set; }
        [DisplayName("Driver's License Country")]
        public string Country { get; set; }
        [DisplayName("Driver's License State")]
        public string? State { get; set; }
        [DisplayName("Issue Location")]
        public string ISSUE_DEST_FRA { get; set; }
        [DisplayName("Issuing Authority")]
        public string ISSUED_BY_FRA { get; set; }

        //[DisplayName("Position Description")]
        //public string? PositionDescription { get; set; }
        [DisplayName("Termination Date")]
        public string? TerminationDate { get; set; }
        [DisplayName("Suspended")]
        public string LIC_SUSPENDED { get; set; }
        [DisplayName("Valid From")]
        public string? ValidFromDate { get; set; }
        [DisplayName("Valid To")]
        public string? ExpirationDT { get; set; }
        [DisplayName("Hire Country")]
        public string? HireCountry { get; set; }
        [DisplayName("Legal Entity")]
        public string? PayrollCompany { get; set; }
       

        //  public string CountryName { get; set; }







        //[DisplayName("Department")]
        //public string? DepartmentId { get; set; }

        //[DisplayName("Division")]
        //public string? Devision { get; set; }
        //[DisplayName("Division Description")]
        //public string? DevisionDescription { get; set; }
        // [DisplayName("Business Unit")]
        //public string? BusinessUnit { get; set; }

        //[DisplayName("Region")]
        //public string? Region { get; set; }
        //[DisplayName("Region Code")]
        //public string? RegionCode { get; set; }

        //[DisplayName("Expiration Date")]


































    }
}
