﻿namespace eDMS.Core.Model
{
    public class TestResultResponseList
    {
        public List<TestResultResponse> testResultResponseList { get; set; }
        public int TotalCount { get; set; }
    }
}