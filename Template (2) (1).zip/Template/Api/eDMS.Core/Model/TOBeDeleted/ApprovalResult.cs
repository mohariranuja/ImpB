﻿namespace eDMS.Core.Model
{
    public class ApprovalResult
    {
        public int ApprovalHistoryId { get; set; }
        public int EmpId { get; set; }
        public string EmplId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string? MiddleName { get; set; }
        //public int ManagerId { get; set; }
        public string? ManagerName { get; set; }
        public string Location { get; set; }
        public string Country { get; set; }
        public string DriverType { get; set; }
        public string DriverTypeDescription { get; set; }
        public string ManagerCode { get; set; }
        public int LoginUserId { get; set; }
        public int DriverEmployeeId { get; set; }
    }
}