﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class ApprovalEmail
    {
        //ApproverFirstName   ApproverLastName LoginFirstName LoginLastName    DriverFirstName DriverLastName EmailSendDate   IsApproved ResponseDate    CreatedBy CreatedOn   ModifiedBy ModifiedOn  IsActive
        [Required]
        public int LoginUserId { get; set; }
        [Required]
        public int ApproverEmployeeId { get; set; }
        [Required]
        public int DriverEmployeeId { get; set; }
        public int OldRiskIndex { get; set; }
        [Required]
        public int NewRiskIndex { get; set; }
        [Required]
        public bool isUSEmail { get; set; }
    }
}