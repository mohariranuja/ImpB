﻿namespace eDMS.Core.Model
{
    public class AuditReportResponses
    {
        public List<AuditReportResponse> auditResponse { get; set; }
        public int? TotalCounts { get; set; }
    }
}