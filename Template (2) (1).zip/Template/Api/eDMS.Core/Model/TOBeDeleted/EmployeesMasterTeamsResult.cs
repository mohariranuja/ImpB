﻿namespace eDMS.Core.Model
{
    public class EmployeesMasterTeamsResult
    {
        public List<EmployeeData> employeesMasterTeamsResults { get; set; }
        public int? TotalCount { get; set; }
    }
}