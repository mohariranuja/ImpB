﻿namespace eDMS.Core.Model
{
    public class IncidentsSeverityMatrixResult
    {
        public List<IncidentSeverityMatrixSet> incidentSeverityMatrices { get; set; }
        public int? TotalCount { get; set; }
    }
}