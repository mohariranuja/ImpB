﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class IncidentSeverityMatrixSet
    {
        [Key]
        public int IncidentSeverityMatrixId { get; set; }
        public int IncidentValue { get; set; }
        public int IncidentTypeId { get; set; }
        public string IncidentType { get; set; }
        public int RiskIndexId { get; set; }
        public string IncidentSeverityMatrixDescription { get; set; }
        public bool IsActiveIncidentSeverityMatrix { get; set; }
    }
}