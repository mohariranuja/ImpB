﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Entities
{
    public class AgencySaveRequest
    {
        [Key]
        public int AgencyId { get; set; }
        public string AgencyName { get; set; }
        public int? CountryId { get; set; }
        public int? RegionId { get; set; }
        public string FieldValue { get; set; }
        public int CreatedBy { get; set; }
        public bool IsActive { get; set; }
    }
}