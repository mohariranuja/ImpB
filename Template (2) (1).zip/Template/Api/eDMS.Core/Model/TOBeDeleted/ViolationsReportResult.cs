﻿namespace eDMS.Core.Model
{
    public class ViolationsReportResult
    {
        public List<ViolationReportResult> violationReportResult { get; set; }
        public int? TotalCount { get; set; }
    }
}