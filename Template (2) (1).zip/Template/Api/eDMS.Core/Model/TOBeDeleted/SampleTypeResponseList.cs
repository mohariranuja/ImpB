﻿namespace eDMS.Core.Model
{
    public class SampleTypeResponseList
    {
        public List<SampleTypeResponse> sampleTypeResponseList { get; set; }
        public int TotalCount { get; set; }
    }
}