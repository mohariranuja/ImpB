﻿namespace eDMS.Core.Model
{
    public class DocumentUploadsReportResult
    {
        public List<DocumentUploadResult> documentUpload { get; set; }
        public int? TotalCount { get; set; }
    }
}