﻿namespace eDMS.Core.Model
{
    public class ViolationValuesSearchResponce
    {
        public List<ViolationValueSearchResponce> violationValueSearchResponceList { get; set; }
        public int? TotalCount { get; set; }
    }
}