﻿using Microsoft.EntityFrameworkCore.Storage;
using System.Transactions;

namespace eDMS.RiskCalculations.Models
{
    public class RisksRequest
    {
        public int DriverRiskId { get; set; }
        public int DriverLicenseId { get; set; }
        public int DriverId { get; set; }
        public string? EmplId { get; set; } //This is driverID in string format This is EmplId
        public Transaction? inputScope { get; set; } = null;
        public string? Region { get; set; }
        public IDbContextTransaction? inputTransaction { get; set; } = null;
    }
} 