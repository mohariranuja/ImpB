﻿namespace eDMS.Core.Model
{
    public class DLUpdWorkRisk
    {
        public int MVRiskIndexId { get; set; }
        public string MVRiskIndex { get; set; }
        public int DERiskIndexId { get; set; }
        public string DERiskIndex { get; set; }
    }
}