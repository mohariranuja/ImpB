﻿namespace eDMS.Core.Model
{
    public class DocumentUploadReportRequest
    {
        // [DefaultValue(null)]
        public string? EmplId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? DLDocType { get; set; }
        public string? UploadStatus { get; set; }
        public int? START_INDEX { get; set; } = null;
        public int? PAGE_SIZE { get; set; } = null;
    }
}