﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class MDMManagerCountryAccess
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public string CountryIds { get; set; }
        public string CountryName { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}
