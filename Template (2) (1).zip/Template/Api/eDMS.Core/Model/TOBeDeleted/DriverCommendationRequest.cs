﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class DriverCommendationRequest
    {
        [Key]
        public int DriverBehaviourId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? Time_Entered { get; set; }
        public int IncidentTypeId { get; set; }
        public string Descr200 { get; set; }        
    }
}