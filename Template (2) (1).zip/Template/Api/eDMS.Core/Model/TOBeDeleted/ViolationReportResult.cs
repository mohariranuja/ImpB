﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class ViolationReportResult
    {
        //public int EmpId { get; set; }
        [Key]
        public int ID { get; set; }
        [DisplayName("Employee Code")]
        public string? EmplId { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Middle Name")]
        public string? MiddleName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [DisplayName("Location Code")]
        public string? Location { get; set; }
        [DisplayName("Manager Code")]
        public string? ManagerCode { get; set; }
        [DisplayName("Manager Name")]
        public string? ManagerName { get; set; }
        [DisplayName("HR Status")]
        public string? HRStatus { get; set; }
        [DisplayName("Driver Evaluator")]
        public string? PREREQ { get; set; }
        [DisplayName("Qualified Driver")]
        public bool? IsQualifiedDriver { get; set; }
        [DisplayName("DQ Status")]
        public string? DQRecComplete { get; set; }
        [DisplayName("Driver Type")]
        public string? DriverType { get; set; }
        //public string? BusinessUnit { get; set; }
        [DisplayName("Business Unit")]
        public string? BusinessUnitDescription { get; set; }
        [DisplayName("Region Name")]
        public string? RegionName { get; set; }
        [DisplayName("Product Line Code")]
        public string? ProductLineCode { get; set; }
        [DisplayName("Product Line Description")]
        public string? ProductLineDescription { get; set; }
        [DisplayName("Sub Product Line Code")]
        public string? SubProductLineCode { get; set; }
        [DisplayName("Sub Product Line Description")]
        public string? SubProductLineDescription { get; set; }
        [DisplayName("Department Description")]
        public string? DepartmentDescription { get; set; }
        [DisplayName("Type Of Incident")]
        public string? TypeOfIncident { get; set; }
        [DisplayName("Date Of The Incident")]
        public string? DateOfTheIncident { get; set; }
        [DisplayName("Time Of Incident")]
        public string? Time_Entered { get; set; }
        [DisplayName("Incident Type")]
        public string? IncidentType { get; set; }
        [DisplayName("Long Description")]
        public string? LongDescription { get; set; }
        [DisplayName("Incident Value")]
        public int? IncidentValue { get; set; }
        [DisplayName("Incident Severity Matrix Description")]
        public string? IncidentSeverityMatrixDescription { get; set; }
        [DisplayName("Description Of Corrective Action")]
        public string? DescriptionOfCorrectiveAction { get; set; }
        [DisplayName("Violation Value")]
        public int? ViolationValue { get; set; }
        [DisplayName("Violation Description")]
        public string? ViolationDescription { get; set; }
        [DisplayName("Drug Test Date")]
        public string? Date2 { get; set; }
        [DisplayName("Drug Test Time")] 
        public string? Time_Recorded { get; set; }
        [DisplayName("Alcohol Test Date")]
        public string? EffDate { get; set; }
        [DisplayName("Alcohol Test Time")]
        public string? Time_Edit { get; set; }
        [DisplayName("DOT Test Date")]
        public string? DOT_Test_date { get; set; }
        [DisplayName("DOT Recordable")]
        public string? DOT_Recordable { get; set; }
        [DisplayName("Updated Month")]
        public string? DLUploadDate { get; set; }
        [DisplayName("Month")]
        public string? MonthXLAT { get; set; }
        [DisplayName("Year")]
        public string? YearCD { get; set; }
        public string? Submitted { get; set; }
        [DisplayName("Audited")]
        public string? GovtAudited { get; set; }
        [DisplayName("Major Violation")]
        public string? MajorViolation { get; set; }
        public string? Comments { get; set; }
        [DisplayName("Hire Country")]
        public string? HireCountry { get; set; }
        [DisplayName("Legal Entity")]
        public string? PayrollCompany { get; set; }
        }
}