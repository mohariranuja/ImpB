﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class DocumentUploadResult
    {
        public int EmpId { get; set; }
        public string? EmplId { get; set; }
        public string FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string LastName { get; set; }
        public string? Location { get; set; }
        public string EmailId { get; set; }
        public string? ManagerCode { get; set; }
        public string? ManagerName { get; set; }
        public string? ManagerEmail { get; set; }
        public string? Country { get; set; }
        public string? LocationDescription { get; set; }
        public string? State { get; set; }
        public string? DriverType { get; set; }
        [Key]
        public int? DL_UPLD_WRK_Id { get; set; }
        public string? DLDocType { get; set; }
        public string? UploadStatus { get; set; }
    }
}