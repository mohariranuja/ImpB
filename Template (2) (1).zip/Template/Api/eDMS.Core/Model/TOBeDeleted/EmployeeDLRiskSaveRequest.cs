﻿namespace eDMS.Core.Model
{
    public class EmployeeDLRiskSaveRequest
    {
        public int EmployeeId { get; set; }
        public string EmplId { get; set; }
        public List<string> LicenseType { get; set; }        
        public string SERV_PERMIT { get; set; }
        public DateTime? EXPIRATN_DT { get; set; }
        public DateTime? PR_EMP_DG_TST { get; set; }
        public string PRE_EMPLMNT_TYPE { get; set; }
        public string CDL_LICENSE { get; set; }
        public string Permission { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string DISA_NBR { get; set; }
        public int MVRiskIndexId { get; set; }
        public int DERiskIndexId { get; set; }
        public int OARiskIndexId { get; set; }
        public string Region { get; set; }
        public string DOT_ASSOC_NO { get; set; }
        public bool? IsQualifiedDriver { get; set;}
        public int LoginEmpId { get; set; }
    }
}