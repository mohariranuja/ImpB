﻿namespace eDMS.Core.Model
{
    public class HoursOfServiceGetManyResponse
    {
        public List<HoursOfServiceGetResponse> HoursOfServices { get; set; }
        public int? TotalCount { get; set; }
    }
}