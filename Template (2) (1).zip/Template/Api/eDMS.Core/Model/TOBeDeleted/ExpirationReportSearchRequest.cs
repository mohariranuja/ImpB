﻿namespace eDMS.Core.Model
{
    public class ExpirationReportSearchRequest
    {
        public int AlertPeriod { get; set; }
        public string? EmplId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string SecondLastName { get; set; }
        public string AlternateCharacterName { get; set; }
        public string LocationCode { get; set; }
        public string ManagerCode { get; set; }
        public string HRStatus { get; set; }
        public string IsDriverEvaluator { get; set; }
        public int BusinessUnitId { get; set; }
        //public string BusinessUnit { get; set; }       
        public string DivisionCode { get; set; }
        public string RegionCode { get; set; }
        public string DepartmentId { get; set; }
        public int ProductLineId { get; set; }
        public int SubProductLineId { get; set; }
        public string DQRecComplete { get; set; }
        public bool? IsQualifiedDriver { get; set; }
        public string? LegalEntitydesc { get; set; }
        public string? HireCountryCode { get; set; }         
        //public string ProductLineCode { get; set; }
        //public string SubProductLineCode { get; set; }     
        public int? START_INDEX { get; set; } = null;
        public int? PAGE_SIZE { get; set; } = null;
    }
}