﻿namespace eDMS.Core.Model
{
    public class DrugTestGetResponse
    {
        public List<DrugAlcoholTestResponse> DrugAlcoholTest { get; set; }
        public int? TotalCount { get; set; }
    }
}