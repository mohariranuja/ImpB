﻿using System.ComponentModel;

namespace eDMS.Core.Model
{
    public class ManagerSearchRequest
    {
        //[DefaultValue(null)]
        //  public string FirstName { get; set; }// = null;
        // [DefaultValue(null)]
        //  public string LastName { get; set; } //= null;
        //  [DefaultValue(null)]
        // [DefaultValue(null)]
        //  public int? ManagerId { get; set; } = null;

        //[DefaultValue(null)]
        //   public string ManagerName { get; set; }// = null;

        [DefaultValue(null)]
        public int? START_INDEX { get; set; } = null;
        [DefaultValue(null)]
        public int? PAGE_SIZE { get; set; } = null;

        public List<FilterDetails> filterDetails { get; set; } = null;
    }
}