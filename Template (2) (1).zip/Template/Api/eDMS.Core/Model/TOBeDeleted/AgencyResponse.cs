﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class AgencyResponse
    {
        [Key]
        public int AgencyId { get; set; }
        public string AgencyName { get; set; }
        public int? CountryId { get; set; }
        public string? CountryName { get; set; }
        public int? RegionId { get; set; }
        public string FieldValue { get; set; }
        public bool IsActive { get; set; }
    }
}