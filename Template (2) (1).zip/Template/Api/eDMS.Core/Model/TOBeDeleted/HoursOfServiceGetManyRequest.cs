﻿using System.ComponentModel;

namespace eDMS.Core.Model
{
    public class HoursOfServiceGetManyRequest
    {
        [DefaultValue(null)]
        public int EmployeeId { get; set; } 
        public int? START_INDEX { get; set; } = null;
        public int? PAGE_SIZE { get; set; } = null;
    }
}