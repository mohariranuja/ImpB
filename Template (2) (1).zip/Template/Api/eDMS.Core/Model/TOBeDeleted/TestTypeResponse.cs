﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class TestTypeResponse
    {
        [Key]
        public int TestTypeId { get; set; }
        public string TestTypeName { get; set; }
        public int? TestCategoryId { get; set; }
        public string TestCategoryName { get; set; }
        public string FieldValue { get; set; }
        public bool IsActive { get; set; }
    }
}