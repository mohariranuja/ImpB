﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class MDMManagerAccessResult
    {
        [Key]
        public int EmpId { get; set; }
        [DisplayName("Person Number")]
        public string? EmplId { get; set; }
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Middle Name")]
        public string? MiddleName { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        [DisplayName("Hire Country")]
        public string HireCountry { get; set; }
        [DisplayName("Qualified Driver")]
        public string QualifiedDriver { get; set; }
        [DisplayName("Manager Number")]
        public string ManagerCode { get; set; }
        [DisplayName("Manager Name")]
        public string? ManagerName { get; set; }      
       
        [DisplayName("Driver Type")]
        public string DriverType { get; set; }
       
    }
}