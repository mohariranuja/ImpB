﻿namespace eDMS.Core.Model
{
    public class DrugAlcoholTestResponse
    {
        public int DOTDrug_AlcoholTestId { get; set; }
        public int EmployeeId { get; set; }
        public string EmpId { get; set; }
        public string TestCategory { get; set; }
        public DateTime? TestDate { get; set; }
        public string TestType { get; set; }
        public string TestTypeName { get; set; }
        public string Agency { get; set; }
        public string SampleType { get; set; }
        public string SampleTypeName { get; set; }
        public string PhysicianName { get; set; }
        public string TestResult { get; set; }
        public string TestResultName { get; set; }
        public string TestNumber { get; set; }
        public string Description { get; set; }
        public string Disposition {  get; set; }
        public string DispositionName { get; set; }
        public string Amphetamine { get; set; }
        public string Cocaine { get; set; }
        public string Marijuana { get; set; }
        public string Opiates { get; set; }
        public string Phencyclidine { get; set; }
        public string Other { get; set; }
    }
}