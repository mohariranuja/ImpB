﻿namespace eDMS.Core.Model
{
    public class TestTypeResponseList
    {
        public List<TestTypeResponse> testTypeResponseList { get; set; }
        public int TotalCount { get; set; }
    }
}