﻿namespace eDMS.Core.Model
{
    public class HoursOfServiceSaveRequest
    {
        public int HoursOfServiceId { get; set; }
        public string EmpId { get; set; }
        public int EmployeeId { get; set; }
        public DateTime? Date1 { get; set; }
        public DateTime? DLUploadDate { get; set; }
        public string MonthXLAT { get; set; }
        public string YearCD { get; set; }
        public string Submitted { get; set; }
        public string GovtAudited { get; set; }
        public string MajorViolation { get; set; }
        public int RiskIndexId { get; set; }
        public int IncidentTypeId { get; set; }
        public int IncidentValueId { get; set; }
        public string? EDotDesc { get; set; }
        public string? DescLongNotes { get; set; }
        public string? Comments { get; set; }
        public int LoginUserId { get; set; }
    }
}