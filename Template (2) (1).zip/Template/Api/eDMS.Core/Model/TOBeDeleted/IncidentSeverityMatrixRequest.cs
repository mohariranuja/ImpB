﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class IncidentSeverityMatrixRequest
    {
        public int? START_INDEX { get; set; } = null;
        [DefaultValue(null)]
        public int? PAGE_SIZE { get; set; } = null;
    }
}
