﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class GenericMasterResult
    {
        [Key]
        public int EmpId { get; set; }
        public int? BusinessUnitId { get; set; }
        public string? BusinessUnit { get; set; }
       // public string? BusinessUnitDescription { get; set; }
        public string? Devision { get; set; }
        public string? DevisionDescription { get; set; }
        public string? Region { get; set; }
        public string? RegionCode { get; set; }
        public int ProductLineId { get; set; }
        public string? ProductLineCode { get; set; }
        public string? SubProductLineDescription { get; set; }
        public int SubProductLineId { get; set; }
        public string? SubProductLineCode { get; set; }
        public string? ProductLineDescription { get; set; }
        public string? DepartmentId { get; set; }
        public string? DepartmentDescription { get; set; }
        public int CountryId { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public int LegalEntityId { get; set; }
        public string LegalEntityName { get; set; }
        public string? LegalEntityDescription { get; set; }
    }
}

