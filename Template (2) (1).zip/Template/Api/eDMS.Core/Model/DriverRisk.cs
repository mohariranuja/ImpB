﻿using System.ComponentModel.DataAnnotations;

namespace eDMS.Core.Model
{
    public class DriverRiskList
    {
        [Key]
        public int DriverRiskId { get; set; }
        public int DriverLicId { get; set; }
        public string DriverType { get; set; }
        public string RiskType { get; set; }
        public string RiskIndex { get; set; }

        public int RiskTypeId { get; set; }
        public int RiskIndexValueId { get; set; }

        public int CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }

        public bool? IsActive { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public DateTime CreatedOn { get; set; }


    }
}