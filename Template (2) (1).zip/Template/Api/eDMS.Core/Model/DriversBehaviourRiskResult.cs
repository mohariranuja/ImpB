﻿namespace eDMS.Core.Model
{
    public class DriversBehaviourRiskResult
    {
        public List<DriverBehaviourRiskResult> driverBehaviourRiskResult { get; set; }
        public int? TotalCount { get; set; }
    }
}