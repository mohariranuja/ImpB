﻿using System.ComponentModel;

namespace eDMS.Core.Model
{
    public class EmployeeSearchRequest
    {   
        [DefaultValue(null)]
        public int? START_INDEX { get; set; } = null;
        [DefaultValue(null)]
        public int? PAGE_SIZE { get; set; } = null;
        public List<FilterDetails> filterDetails { get; set; } = null;
    }
}