﻿using System.ComponentModel;

namespace eDMS.Core.Model
{
    public class DriverBehaviourRiskRequest
    {
        public int EmployeeId { get; set; }
        public bool IsCommendationType { get; set; }
        [DefaultValue(null)]
        public int? START_INDEX { get; set; } = null;
        [DefaultValue(null)]
        public int? PAGE_SIZE { get; set; } = null;
    }
}