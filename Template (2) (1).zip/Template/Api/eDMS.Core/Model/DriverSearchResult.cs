﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace eDMS.Core.Model
{
    public class DriverSearchResult
    {
        [Key]

        public int EmpId { get; set; }
        public string? EmplId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string? MiddleName { get; set; }
        public string? SecondLastName { get; set; }
        public string? AlternateName { get; set; }
      //  public int ManagerId { get; set; }

        public string? ManagerName { get; set; }
       // public int LocationId { get; set; }
        public string? LocationDescription { get; set; }
       // public int PositionId { get; set; }
        public string? PositionDescription { get; set; }
      //  public int DriverTypeId { get; set; }
        public string DriverType { get; set; }
        //public int CountryId { get; set; }
      //  public string CountryName { get; set; }
        public string QualifiedDriver { get; set; }
        public string? HRStatus { get; set; }
        public string? DriverEvaluator { get; set; }

        public string? Location { get; set; }
        public string ManagerCode { get; set; }
       // public bool IsGlobalAccess { get; set; }
    }
}
