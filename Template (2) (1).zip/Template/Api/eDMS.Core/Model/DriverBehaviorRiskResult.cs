﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Core.Model
{
    public class DriverBehaviorRiskResult
    {
        [Key]
        public int EmpId { get; set; }
        public string EmplId { get; set; }
        public string BehaviorRisk { get; set; }
        public int BehaviorRiskId { get; set; } 

    }
}
