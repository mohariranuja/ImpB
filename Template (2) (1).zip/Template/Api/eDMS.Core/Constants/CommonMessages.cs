﻿namespace eDMS.Core.Constants
{
    public static class CommonMessages
    {
        public const string AddErrorMessage = "Error while adding the record.";
        public const string InvalidModelMessage = "Invalid model.";
        public const string UpdateErrorMessage = "Error while updating the record.";
        public const string GetErrorMessage = "Records not found. Try again.";
        public const string InputIDErrorMessage = "Id can not be null.";
        public const string AddSuccessMessage = "Record added successfully.";
        public const string UpdateSuccessMessage = "Record updated successfully.";
        public const string DeletedSuccessMessage = "Record deleted successfully.";
        public const string DeleteErrorMessage = "Error while deleting the record.";
        public const string RecordExistsMessage = "Record already exists.";
        public const string FieldValueExistsMessage = "Field Value already exists.";
    }
}