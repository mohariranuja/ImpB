﻿namespace eDMS.Core
{
    public static class eDMSConstant
    {
        public const string dateFormat = "MM/dd/yyyy";
        public const string abstractRisk = "ABSTRACT_RISK";
        public const string hosRiskType = "HOS_RISK";
        public const string vopeRisk = "VOPE_RISK";
        public const string behaviorRiskType = "BEHV_RISK";
        public const string OverallRisk = "OVERALL_RISK";
        public const string defaultIncidentValue = "NA";
        public const string defaultRiskIndex = "NA";
        public const string defaultViolationValue = "NA";
        public const string defaultShortNA = "N";
        //public const string baseURI = "http://localhost:22907/api/";
        public const string logFolder = "log";
        //public const string emailLogFileName = "emailLog.txt";
        //public const string approvalEmailTemplateUS = "Dear Colleague,\r\n\r\nThis is to inform you that the following employee’s overall risk index has moved into a medium or high category. This has changed due to one or more areas: a driving incident, Hours of Service violation(s), or during annual review of the Motor Vehicle Record. Please review the assessed risk ratings by reviewing the driver’s EDMS file.\r\n\r\nIf an increase in risk rating is a result of the annual review of the Motor Vehicle Record, the US Fleet Safety Department will contact the manager within 2 business days. Please be advised that as a result, you must obtain approval for this employee to continue to drive a company vehicle or a personal vehicle on company business.\r\n\r\nMedium Risk Drivers are not eligible to drive for Weatherford without written approval from the applicable General Area Manager.\r\n\r\nHigh Risk Drivers are not eligible to drive for Weatherford without written approval from the Regional Vice President (VP)\r\n\r\nIf an increase in risk rating is due to a driving incident or Hours of Service violation(s) no further approval is required. Please review the violation or incident record in the driver’s EDMS file and make comments or corrective action. \r\n\r\n                                                                              \r\n\r\nEmployee ID: #EmployeeID\r\n\r\nEmployee Name: #EmployeeName\r\n\r\nOld Risk Index: #OldRiskIndex\r\n\r\nNew Risk Index: #NewRiskIndex\r\n\r\nManager: #ManagerName\r\n\r\nButton Name - #ApproveAction - #RejectAction\r\n\r\n\r\n\r\nThank you for your prompt action to ensure full compliance with company policy, and legislative requirements.\r\n\r\nRegards,\r\n\r\nWeatherford Fleet Safety\r\n";
        //public const string approvalEmailTemplateNonUS = "Dear Colleague,\r\n\r\nThis is to inform you that the following employee’s overall risk index has moved into a medium or high category. This has been changed due to a driving incident, Hours of Service violation or during annual review.\r\n\r\nPlease be advised that as a result of this, you must obtain approval for this employee to continue to drive a company vehicle or to drive a personal vehicle on company business.\r\n\r\nMedium Risk Drivers are not eligible to drive for Weatherford without written approval from the applicable Regional Business Unit Manager\r\n\r\nHigh Risk Drivers are not eligible to drive for Weatherford without written approval from the Regional Vice President (VP)\r\n\r\n                                                                              \r\n\r\nEmployee ID: #EmployeeID\r\n\r\nEmployee Name: #EmployeeName\r\n\r\nOld Risk Index: #OldRiskIndex\r\n\r\nNew Risk Index: #NewRiskIndex\r\n\r\nManager: #ManagerName\r\n\r\nButton Name - #ApproveAction - #RejectAction\r\n\r\n\r\nThank you for your prompt action to ensure full compliance with company policy, and legislative requirements.\r\n\r\nRegards,\r\n\r\nWeatherford Fleet Safety\r\n\r\nOn Approver Action:\r\n";
        //public const string approvalEmailTitle = "Risk Index change - Approver Response Received for (#EmployeeName)";
        public const string eMailRegx = @"^[\w-_]+(\.[\w!#$%'*+\/=?\^`{|}]+)*@((([\-\w]+\.)+[a-zA-Z]{2,20})|(([0-9]{1,3}\.){3}[0-9]{1,3}))$", ErrorMessage = "Invalid email address.";
        //public const string actionURL = "http://localhost:#PortNo/api/ApprovalHistory/GetApproval?id=#HistoryId&isApproved=#IsApproved";
        //public const string portNo = "22907";
        public const int overAllRiskIndexNA = 9;
        public const int lowRiskIndex = 3;
        public const int mediumRiskIndex = 2;
        public const int highRiskIndex = 1;
        public const string regionUSA = "8USAR";
        public const string regionCAN = "2CANR";
        public const string highRisk = "High";
        public const string mediumRisk = "Medium";
        public const string lowRisk = "Low";
        public const string usaConstant = "USA";
        public const string CanadaConstant = "CAN";
        public const string approveEmailTemplate = "Dear Colleague,\r\n\r\nThis is to inform you that the following employee’s overall risk index has been Approved. \r\n\r\n                                                                            \r\n\r\nEmployee ID:#EmployeeID\r\n\r\nEmployee Name:#EmployeeName\r\n\r\n \r\n\r\nThank you for your prompt action to ensure full compliance with company policy, and legislative requirements.\r\n\r\n \r\n\r\nRegards,\r\n\r\nHSE Compliance\r\n\r\n";
        public const string rejectEmailTemplate = "Dear Colleague,\r\n\r\nThis is to inform you that the following employee’s overall risk index has been Rejected. \r\n\r\n                                                                            \r\n\r\nEmployee ID:#EmployeeID\r\n\r\nEmployee Name:#EmployeeName\r\n\r\n \r\n\r\nThank you for your prompt action to ensure full compliance with company policy, and legislative requirements.\r\n\r\n \r\n\r\nRegards,\r\n\r\nHSE Compliance\r\n\r\n";
        public const string approvalResponseTitle = "Risk Change Approval for #EmployeeID - Approved / Rejected\r\n";
        public const string drvMVRRCD = "DRV_MVRRCD";
        public const string anlrevFRM = "ANLREV_FRM";
        public const string abstrPROD = "ABSTR_PROD";
        public const string driverTypeDOT = "DOT";
        public const string driverTypeNDOT = "NDOT";
        public const string yes = "Y";
        public const string no = "N";
        public const string documentCategoryCDL = "_CDL";
        public const string documentCategoryNONCDL = "_NONCDL";
        public const string documentCategoryNONDOT = "NON_DOT";
        public const string vopeEVAL = "VOPE_EVAL";
        public const string canadaCode = "CA";
        public const string usCode = "US";
        public const string systemUser = "GeoTab / Nightly Job";
    }
}