﻿namespace eDMS.Application.Dto.UserProfile
{
    public class UserProfileDto
    {
        public string? DisplayName { get; set; }
        public int EmpId { get; set; }
        public string? EmplId { get; set; }
        public string? EmailId { get; set; }
        public string? PreferredLanguage { get; set; }
        public string? Role { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set;}
        public string? Country { get; set; }
        public bool IsRegionManager { get; set; }
    }
}