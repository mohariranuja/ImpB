﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System.Linq.Expressions;

namespace eDMS.Application.Interfaces
{
    public interface IManagerSearchRepository : IFilterRepository<ManagersSearchResult>
    {
        public Task<ManagersSearchResult> GetManyAsync(
        Expression<Func<EmployeeMaster, bool>> filter = null,
       Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       int? top = null,
       int? skip = null,
       params string[] includeProperties);

        public Task<ManagersSearchResult> GetManyApproversAsync(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties);

        //public Task<GenericMastersSearchResult> GetManyBusinessUnitAsync(
        //Expression<Func<EmployeeMaster, bool>> filter = null,
        //Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        //int? top = null,
        //int? skip = null,
        //params string[] includeProperties);
    }
}
