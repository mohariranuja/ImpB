﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IGenericPopupSearchRepository : IFilterRepository<GenericMastersSearchResult>
    {
       
       public Task<GenericMastersSearchResult> GetManyAsync(
       Expression<Func<MDMRegion, bool>> filter = null,
       Func<IQueryable<MDMRegion>, IOrderedQueryable<MDMRegion>> orderBy = null,
       int? top = null,
       int? skip = null,
       params string[] includeProperties);

        public Task<GenericMastersSearchResult> GetManyDivisionAsync(
         Expression<Func<EmployeeMaster, bool>> filter = null,
         Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
         int? top = null,
         int? skip = null,
         params string[] includeProperties);
       // public Task<GenericMastersSearchResult> GetManyProductlineAsync(
       // Expression<Func<EmployeeMaster, bool>> filter = null,
       // Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       // int? top = null,
       // int? skip = null,
       // params string[] includeProperties);

       // public  Task<GenericMastersSearchResult> GetManySubProductlineAsync(
       //Expression<Func<EmployeeMaster, bool>> filter = null,
       //Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       //int? top = null,
       //int? skip = null,
       //params string[] includeProperties);
       // public Task<GenericMastersSearchResult> GetManyDepartAsync(
       //Expression<Func<EmployeeMaster, bool>> filter = null,
       //Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       //int? top = null,
       //int? skip = null,
       //params string[] includeProperties);
    }
}
