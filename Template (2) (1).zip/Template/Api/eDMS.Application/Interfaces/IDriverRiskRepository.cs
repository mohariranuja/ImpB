﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDriverRiskRepository : IRepository<DriverRisks>
    {
        Task<DriverRisks?> GetByDLRiskTypeAsync(int driverLicenseId, int riskTypeId);
    }
}