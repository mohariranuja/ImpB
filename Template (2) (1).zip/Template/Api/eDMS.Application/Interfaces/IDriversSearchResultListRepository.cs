﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IDriversSearchResultListRepository : IFilterRepository<DriversSearchResult>
    {
     public Task<DriversSearchResult> GetManyAsync(
    Expression<Func<EmployeeMaster, bool>> filter = null,
    Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
    int? top = null,
    int? skip = null,
    params string[] includeProperties);

    public Task<IReadOnlyList<DriverSearchResult>> GetManyAsync(DriverSearchRequest request);
    public Task<DriversSearchResult> GetManyAsyncResult(DriverSearchRequest request);

    }
}
