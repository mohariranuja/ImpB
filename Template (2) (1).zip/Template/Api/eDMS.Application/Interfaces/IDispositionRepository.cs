﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDispositionRepository : IRepository<Disposition>
    {
    }
}