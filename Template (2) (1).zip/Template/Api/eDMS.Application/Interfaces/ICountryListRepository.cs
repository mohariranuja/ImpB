﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System.Linq.Expressions;

namespace eDMS.Application.Interfaces
{
    public interface ICountryListRepository : IFilterRepository<CountryList>
    {
        public Task<IReadOnlyList<CountryList>> GetManyAsync(CountryRequest request);
        //  public  Task<List<Country>> GetAsync<T>(Expression<Func<Country, bool>> predicate);
        public  Task<GenericMastersSearchResult> GetManyAsync1(
          Expression<Func<Country, bool>> filter = null,
          Func<IQueryable<Country>, IOrderedQueryable<Country>> orderBy = null,
          int? top = null,
          int? skip = null,
          params string[] includeProperties);
    }
}
