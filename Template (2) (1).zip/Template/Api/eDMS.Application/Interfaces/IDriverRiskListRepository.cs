﻿using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IDriverRiskListRepository : IFilterRepository<DriverRiskList>
    {
        public Task<IReadOnlyList<DriverRiskList>> GetManyAsync(int id);
       
    }
}