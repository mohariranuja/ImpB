﻿

namespace eDMS.Application.Interfaces
{
    public interface IRepositoryExtended<T> where T : class
    {
        Task<IReadOnlyList<T>> GetByIDMultipleRecord(string id);
    }
}
