﻿namespace eDMS.Application.Interfaces
{
    public interface IFilterRepository<T> where T : class
    {
        // Task<IReadOnlyList<T>> GetManyAsync(T entity);
    }
}