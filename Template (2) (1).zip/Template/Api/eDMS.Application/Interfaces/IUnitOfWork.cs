﻿using eDMS.Application.Interfaces.TOBEDeleted;

namespace eDMS.Application.Interfaces
{
    public interface IUnitOfWork
    {
        ICountryRepository Countries { get; }
        IDriverLicenseRepository DriverLicenses { get; }
        ICountryListRepository CountryList { get; }
        IDriversSearchResultListRepository DriversSearchResultList { get; }
        IDriverBehaviourRiskViewRepository DriverBehaviourRiskViews { get; }
        
        IDriversBehaviourRiskRepository DriversBehaviourRisks { get; }
        ILocationSearchRepository LocationsSearchResultList { get; }
        IBusinessUnitSearchRepository BusinessUnitsSearchResultList { get; }
        IDriverRiskRepository DriverRisks { get; }
       
    }
}