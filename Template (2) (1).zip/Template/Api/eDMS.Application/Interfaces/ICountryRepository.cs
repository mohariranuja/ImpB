﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface ICountryRepository : IRepository<Country>
    {
    }
}