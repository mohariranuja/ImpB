﻿using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IDriversBehaviourRiskRepository : IFilterRepository<DriversBehaviourRiskResult>
    {
        public Task<DriversBehaviourRiskResult> GetManyAsync(bool isCommendationType, int employeeId, int? top = null, int? skip = null,
            params string[] includeProperties);
        public  Task<string> GetBehaviorAsyncResult(string emplId, string regionId);
        public Task<string> GetBehaviorConsoleAsyncResult(string emplId);
    }
}