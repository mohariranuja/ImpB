﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IBusinessUnitSearchRepository : IFilterRepository<GenericMastersSearchResult>
    {
        public Task<GenericMastersSearchResult> GetManyBusinessUnitAsync(
       Expression<Func<BusinessUnit, bool>> filter = null,
       Func<IQueryable<BusinessUnit>, IOrderedQueryable<BusinessUnit>> orderBy = null,
       int? top = null,
       int? skip = null,
       params string[] includeProperties);

    }
   
}
