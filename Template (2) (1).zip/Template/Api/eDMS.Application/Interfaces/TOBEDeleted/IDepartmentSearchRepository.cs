﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IDepartmentSearchRepository : IFilterRepository<GenericMastersSearchResult>
    {
        public  Task<GenericMastersSearchResult> GetManyDepartAsync(
       Expression<Func<Department, bool>> filter = null,
       Func<IQueryable<Department>, IOrderedQueryable<Department>> orderBy = null,
       int? top = null,
       int? skip = null,
       params string[] includeProperties);


    }
}
