﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IDrugAlcoholTestRepository : IRepository<DOTDrug_AlcoholTest>, IFilterRepository<DrugTestGetResponse>
    {
        public Task<DrugTestGetResponse> GetManyAsync(int employeeId, int? top = null, int? skip = null,
            params string[] includeProperties);
    }
}