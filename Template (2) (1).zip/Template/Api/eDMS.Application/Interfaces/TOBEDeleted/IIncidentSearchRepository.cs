﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System.Linq.Expressions;

namespace eDMS.Application.Interfaces
{
    public interface IIncidentSearchRepository : IFilterRepository<IncidentSearchRequest>
    {
        public Task<IncidentsSearchResponce> GetManyAsync(
      Expression<Func<MDMIncidentValue, bool>> filter = null,
      Func<IQueryable<MDMIncidentValue>, IOrderedQueryable<MDMIncidentValue>> orderBy = null,
      int? id = null, int? top = null, int? skip = null, params string[] includeProperties);
    }
}