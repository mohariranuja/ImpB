﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IMdmRoleRepository
    {
        Task<MdmRole?> GetMdmRoleByIdAsync(int id);
        Task<IReadOnlyList<MdmRole>> GetAllAsync();
    }
}
