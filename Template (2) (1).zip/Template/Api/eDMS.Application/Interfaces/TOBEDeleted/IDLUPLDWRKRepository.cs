﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDLUPLDWRKRepository : IRepository<DLUPLDWRK>
    {
        Task<DLUPLDWRK> GetWrkForEmployeeAsync(int id, string docCategory, string dlDocType);
        Task<DLUPLDWRK> GetDetailToSave(DLUPLDWRK entity);
    }
}