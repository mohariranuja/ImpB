﻿using EverestVPS.Core.Entities;

namespace EverestVPS.Application.Interfaces
{
    public interface IRateTemplateProductLineRepository 
    {
        Task<IReadOnlyList<RateTemplateProductLine>> GetAllAsync();
        Task<RateTemplateProductLine> GetByIdAsync(int id);
    }
}
