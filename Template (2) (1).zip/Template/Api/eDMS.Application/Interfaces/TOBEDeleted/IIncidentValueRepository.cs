﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IIncidentValueRepository : IRepository<MDMIncidentValue>
    {
        public Task<List<MDMIncidentValue>> GetByIncidentTypeIdAsync(int incidentTypeId);
    }
}