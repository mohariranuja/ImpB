﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDriverLicenseRepository : IRepository<DriverLicense>, IRepositoryExtended<DriverLicense>
    {
        Task<int> UpdateDriverInfoAsync(DriverLicense entity);
        Task<DriverLicense> GetByEmployeeID(int id);
    }
}