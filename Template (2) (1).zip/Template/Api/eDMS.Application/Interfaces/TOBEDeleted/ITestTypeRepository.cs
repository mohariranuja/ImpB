﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface ITestTypeRepository : IRepository<TestType>
    {
        Task<TestTypeResponseList> GetAllWithPaginationAsync(int? top, int? skip);
    }
}