﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface ITestCategoryRepository : IRepository<TestCategory>
    {
        public Task<TestCategoryResponse> GetAllWithPaginationAsync(int? top = null, int? skip = null);
    }
}
