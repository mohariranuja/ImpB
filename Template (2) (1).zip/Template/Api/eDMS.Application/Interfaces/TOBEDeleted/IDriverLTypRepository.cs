﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDriverLTypRepository : IRepository<DriverLTyp>
    {
        Task<int> DeleteForEmployeeAsync(int id);
        Task<IReadOnlyList<DriverLTyp>> GetAllForEmployeeIdAsync(int id);
        Task<int> UpdateDLTypes(DriverLTyp dltypes, List<string> typelists);
    }
}