﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IEmployeesMasterTeamsRepository: IFilterRepository<EmployeeMasterTeamsRequest>
    {
        //public Task<EmployeesMasterTeamsResult> GetManyAsync(int managerId, int? top = null, int? skip = null,
        //   params string[] includeProperties);
        public Task<EmployeesMasterTeamsResult> GetManyAsync(
    //Expression<Func<EmployeeMaster, bool>> filter = null,
    Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
    string managerCode = null, int? top = null, int? skip = null, params string[] includeProperties);
    }
}
