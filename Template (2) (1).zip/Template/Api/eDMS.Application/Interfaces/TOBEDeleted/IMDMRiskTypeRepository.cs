﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IMDMRiskTypeRepository : IRepository<MDMRiskType>
    {
        Task<MDMRiskType> GetByTypeAsync(string riskType);
    }
}