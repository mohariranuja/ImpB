﻿using eDMS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IEmailRepository
    {
        Task<int> sendEmailNotification(EmailEntity email);
        Task SendAsync(string from, string subject, string body, IEnumerable<string> to, List<Attachment> fileAttachments,
           IEnumerable<string> cc = null, IEnumerable<string> bcc = null);
    }

}
