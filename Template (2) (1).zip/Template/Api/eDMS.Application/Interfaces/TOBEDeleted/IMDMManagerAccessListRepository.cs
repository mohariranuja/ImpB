﻿using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IMDMManagerAccessListRepository : IFilterRepository<MDMManagerAccess>
    {
        public Task<IReadOnlyList<MDMManagerCountryAccess>> GetManyAsync(int emplID);
        public Task<MDMManagerAccessSearchResult> GetMananagerAccessList(int userId, string? CountryIds, int? top = null, 
            int? skip = null);
    }
}