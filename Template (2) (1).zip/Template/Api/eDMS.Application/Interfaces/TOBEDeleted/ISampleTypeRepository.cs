﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface ISampleTypeRepository : IRepository<SampleType>
    {
        public Task<SampleTypeResponseList> GetAllWithPaginationAsync(int? top, int? skip);
    }
}