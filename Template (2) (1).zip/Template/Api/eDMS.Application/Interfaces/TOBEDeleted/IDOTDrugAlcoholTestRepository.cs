﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDOTDrugAlcoholTestRepository : IRepository<DOTDrug_AlcoholTest>
    {
    }
}