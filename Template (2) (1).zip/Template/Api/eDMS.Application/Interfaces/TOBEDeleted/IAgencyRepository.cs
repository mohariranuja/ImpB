﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IAgencyRepository : IRepository<Agency>
    {
        public Task<AgencyResponseList> GetAllWithPaginationAsync(int? top, int? skip);
    }
}