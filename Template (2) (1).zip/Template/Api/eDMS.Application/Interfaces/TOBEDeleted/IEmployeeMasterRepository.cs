﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System.Linq.Expressions;

namespace eDMS.Application.Interfaces
{
    public interface IEmployeeMasterRepository : IRepository<EmployeeMaster>
    {
        Task<EmployeeMaster?> GetEmployeeByEmailAsync(string email);
        Task<ApprovalResultList> GetAllUserPendingRequestsAsync(int id, int? top = null, int? skip = null);
        Task<ExpirationsReportSearchResult> GetManyAsyncResult(ExpirationReportSearchRequest request);
        Task<ViolationsReportResult> GetValidationReportResult(ExpirationReportSearchRequest request);
        Task<DocumentUploadsReportResult> GetDocumentUploadReportResult(DocumentUploadReportRequest request);
        Task<EmployeeMaster?> GetByCodeAsync(string code);
        Task<ManagersSearchResult> GetEmployeeSearchList(Expression<Func<EmployeeMaster, bool>> filter = null,
        Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        int? top = null, int? skip = null, params string[] includeProperties);
        Task<EmployeeData> GetByIdWithDriverTypeDescAsync(int id);
    }
}