﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface ITestResultRepository : IRepository<TestResult>
    {
        public Task<TestResultResponseList> GetAllWithPaginationAsync(int? top, int? skip);
    }
}