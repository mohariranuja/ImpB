﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IIncidentSeverityMatrixByPageRepository: IFilterRepository<IncidentSeverityMatrixRequest>
    {
        public Task<IncidentsSeverityMatrixResult> GetManyAsync(
   //Expression<Func<EmployeeMaster, bool>> filter = null,
   Func<IQueryable<IncidentSeverityMatrix>, IOrderedQueryable<IncidentSeverityMatrix>> orderBy = null,
    int? top = null, int? skip = null, params string[] includeProperties);
        public  Task<IncidentsSeverityMatrixResult> GetManyAsyncFilter(
         Expression<Func<IncidentSeverityMatrix, bool>> filter = null,
         Func<IQueryable<IncidentSeverityMatrix>, IOrderedQueryable<IncidentSeverityMatrix>> orderBy = null,
         int? top = null,
         int? skip = null,
         params string[] includeProperties);

    }
}
