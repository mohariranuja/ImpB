﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IDocumentTypeRepository : IRepository<DocType>
    {
        //Task<TestTypeResponseList> GetAllWithPaginationAsync(int? top, int? skip);
    }
}