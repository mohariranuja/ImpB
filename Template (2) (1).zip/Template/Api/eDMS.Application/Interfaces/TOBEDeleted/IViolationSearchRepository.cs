﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using System.Linq.Expressions;

namespace eDMS.Application.Interfaces
{
    public interface IViolationSearchRepository : IFilterRepository<ViolationValueSearchRequest>
    {
        public Task<ViolationValuesSearchResponce> GetManyAsync(
     Expression<Func<MDMViolationSeverityMatrix, bool>> filter = null,
     Func<IQueryable<MDMViolationSeverityMatrix>, IOrderedQueryable<MDMViolationSeverityMatrix>> orderBy = null,
     int? id = null, int? top = null, int? skip = null, params string[] includeProperties);

        public Task<ViolationValuesSearchResponce> GetAllWithPaginationAsync(int? top = null, int? skip = null);
    }
}