﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IApprovalHistoryRepository : IRepository<ApprovalHistory>
    {
    }
}