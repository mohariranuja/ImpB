﻿using eDMS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Application.Interfaces
{
    public interface IMDMRegionRepository : IRepository<MDMRegion>
    {
       
    }
}
