﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IDriverRisksHistoryRepository : IRepository<DriverRisksHistory>
    {
        Task<DriverRisksHistory?> GetByDLRiskTypeAsync(int driverLicenseId, int riskTypeId);
        Task<IReadOnlyList<DriverRisksHistory>> GetAllDLRiskTypeAsync(int driverLicenseId, int riskTypeId);
        Task<AuditReportResponses> GetDriverAuditListAsync(int driverLicId, int? top = null, int? skip = null);
    }
}