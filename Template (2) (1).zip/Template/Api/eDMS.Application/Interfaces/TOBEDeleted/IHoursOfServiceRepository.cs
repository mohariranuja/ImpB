﻿using eDMS.Core.Entities;
using eDMS.Core.Model;

namespace eDMS.Application.Interfaces
{
    public interface IHoursOfServiceRepository:IRepository<HoursOfService>
    {
        //public Task<HoursOfServiceGetManyResponse> GetManyAsync(int employeeId, int? top = null, int? skip = null,
        //    params string[] includeProperties);

        public Task<HoursOfServiceGetManyResponse> GetManyAsync(int employeeId, int? top = null, int? skip = null);
        public Task<string> GetHosAsyncResult(string emplId, string regionId);
        public Task<string> GetHosRiskAsyncResult(string emplId);
        
    }
}