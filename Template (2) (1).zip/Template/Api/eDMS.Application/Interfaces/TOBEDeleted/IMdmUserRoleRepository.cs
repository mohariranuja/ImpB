﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IMdmUserRoleRepository
    {
        Task<MdmUserRole?> GetMdmUserRoleByUserIdAsync(int userId);
    }
}
