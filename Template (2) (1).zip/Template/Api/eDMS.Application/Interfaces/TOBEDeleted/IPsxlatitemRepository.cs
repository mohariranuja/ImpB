﻿using eDMS.Core.Entities;

namespace eDMS.Application.Interfaces
{
    public interface IPsxlatitemRepository : IRepository<Psxlatitem>
    {
    }
}