﻿//using eDMS.Api.Controllers.ToBeDeleted;using eDMS.Api.Middleware;using eDMS.Api.Models;using eDMS.Application.Interfaces;using eDMS.Core;using eDMS.Core.Constants;using eDMS.Core.Entities;using eDMS.Core.Model;using eDMS.Infrastructure.Persistence;using Microsoft.AspNetCore.Mvc;using System.Linq.Expressions;namespace eDMS.Api.Controllers{    [Route("api/[controller]")]    [ApiController]    public class DriverLicenseController : BaseApiController    {        #region ===[ Private Members ]=============================================================        private readonly IUnitOfWork _unitOfWork;        #endregion        #region ===[ Constructor ]=================================================================        /// <summary>        /// Initialize VPTypeController by injecting an object type of IUnitOfWork        /// </summary>        public DriverLicenseController(IUnitOfWork unitOfWork)        {            this._unitOfWork = unitOfWork;        }        #endregion        #region ===[ Public Methods ]==============================================================        [HttpGet]        public async Task<ApiResponse<List<DriverLicense>>> GetAll()        {            var apiResponse = new ApiResponse<List<DriverLicense>>();            var data = await _unitOfWork.DriverLicenses.GetAllAsync();            apiResponse.Success = true;            apiResponse.Result = data.ToList();            if (apiResponse.Result.Count == 0)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }        [HttpGet("GetByIDMultipleRecord/{emplId}")]        public async Task<ApiResponse<List<DriverLicense>>> GetByIDMultipleRecord(string emplId)        {            var apiResponse = new ApiResponse<List<DriverLicense>>();            var data = await _unitOfWork.DriverLicenses.GetByIDMultipleRecord(emplId);            apiResponse.Success = true;            apiResponse.Result = data.ToList();            if (apiResponse.Result.Count == 0)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }        [HttpGet("GetLatestDLByEmpID/{emplId}")]        public async Task<ApiResponse<DriverLicense>> GetLatestDLByEmpID(string emplId)        {            var apiResponse = new ApiResponse<DriverLicense>();            var data = await _unitOfWork.DriverLicenses.GetByIDMultipleRecord(emplId);            apiResponse.Success = true;            apiResponse.Result = data.FirstOrDefault();            if (apiResponse.Result == null)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }        [HttpGet("{id}")]        public async Task<ApiResponse<DriverLicense>> GetById(int id)        {            if (id <= 0)            {                throw new DMSException(CommonMessages.InputIDErrorMessage);            }            var apiResponse = new ApiResponse<DriverLicense>();            var data = await _unitOfWork.DriverLicenses.GetByIdAsync(id);            apiResponse.Success = true;            apiResponse.Result = data;            if (apiResponse.Result == null)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }

        //[HttpGet("GetAllById/{id}")]
        //public async Task<ApiResponse<DriverLicense>> GetAllById(int id, bool multipleDrivingLic=true)
        //{
        //    if (id <= 0)
        //    {
        //        throw new DMSException(CommonMessages.InputIDErrorMessage);
        //    }
        //    var apiResponse = new ApiResponse<DriverLicense>();
        //    var data = await _unitOfWork.DriverLicenses.GetByIdAsync(id);
        //    apiResponse.Success = true;
        //    apiResponse.Result = data;

        //    if (apiResponse.Result == null)
        //        throw new DMSException(CommonMessages.GetErrorMessage);

        //    return apiResponse;
        //}
        //[HttpGet("{id}")]
        //public async Task<ApiResponse<RisksRequest>> GetDriverRisk(int id)
        //{
        //    if (id <= 0)
        //    {
        //        throw new DMSException(CommonMessages.InputIDErrorMessage);
        //    }
        //    var apiEmployee = await _unitOfWork.EmployeeMasters.GetByIdAsync(id);
        //    var driverLicense = await _unitOfWork.DriverLicenses.GetByIdAsync(id);
        //    var risksRequest = new RisksRequest();
        //    risksRequest.EmplId = apiEmployee.EmplId;
        //    risksRequest.DriverId = id;
        //    risksRequest.inputScope = null;
        //    risksRequest.DriverRiskId = 0;
        //    risksRequest.DriverLicenseId = 0;
        //    risksRequest.Region = apiEmployee.Region;

        //    var apiResponse = new ApiResponse<DriverLicense>();
        //    apiResponse.Success = true;
        //    //apiResponse.Result = data;

        //    if (apiResponse.Result == null)
        //        throw new DMSException(CommonMessages.GetErrorMessage);

        //    return null;// apiResponse;
        //}

        ////[HttpPost("SaveEmployeeDLRisk")]        ////public async Task<ApiResponse<int>> Add(EmployeeDLRiskSaveRequest saveRequest)        ////{        ////    ApplicationDBContext _context = new ApplicationDBContext();        ////    var apiResponse = new ApiResponse<int>();        ////    if (saveRequest == null)        ////        throw new DMSException(CommonMessages.InvalidModelMessage);

        ////    // To get Employee info
        ////    EmployeeMaster employee = _context.EmployeeMasters.Where(r=>r.EmpId== saveRequest.EmployeeId).FirstOrDefault()
        ////            ?? throw new DMSException(CommonMessages.InvalidModelMessage);

        ////    // To update Employee IsQualifiedDriver.
        ////    employee.IsQualifiedDriver = saveRequest.IsQualifiedDriver;
        ////    //make change
        ////    employee.ModifiedBy = saveRequest.LoginEmpId.ToString();
        ////    employee.ModifiedOn= DateTime.Now;
        ////    _context.EmployeeMasters.Update(employee);
        ////    _context.SaveChanges();

        ////    // Driver License Object creation.
        ////    var driverLicenese = await _unitOfWork.DriverLicenses.GetByEmployeeID(saveRequest.EmployeeId)
        ////            ?? throw new DMSException(CommonMessages.InvalidModelMessage);        ////    driverLicenese.EMPLId = saveRequest.EmplId;        ////    driverLicenese.EmployeeId = saveRequest.EmployeeId;

        ////    if (driverLicenese != null)        ////        saveRequest.Region = driverLicenese.Country;

        ////    driverLicenese.Permission = saveRequest.Permission;
        ////    if (saveRequest.Region.Contains("US"))        ////    {        ////        driverLicenese.PR_EMP_DG_TST = saveRequest.PR_EMP_DG_TST;        ////        driverLicenese.PRE_EMPLMNT_TYPE = saveRequest.PRE_EMPLMNT_TYPE;        ////        driverLicenese.EXPIRATN_DT = saveRequest.EXPIRATN_DT;        ////        driverLicenese.CDL_LICENSE = saveRequest.CDL_LICENSE;        ////        driverLicenese.ExpirationDate = saveRequest.ExpirationDate;        ////        driverLicenese.DOT_ASSOC_NO = saveRequest.DOT_ASSOC_NO;
        ////    }        ////    if (saveRequest.Region.Contains("CA"))        ////        driverLicenese.SERV_PERMIT = saveRequest.SERV_PERMIT;

        ////    //make change
        ////    driverLicenese.ModifiedBy = saveRequest.LoginEmpId;        ////    driverLicenese.ModifiedOn = DateTime.Now;
        ////    // Driver License update.
        ////    _context.DriverLicenses.Update(driverLicenese);

        ////    //get driving license types for driver
        ////    var driverLicenseTypes = _context.DriverLTyps.Where(x => x.EmployeeId == saveRequest.EmployeeId).ToList();        ////    foreach (var licenceType in driverLicenseTypes)        ////    {        ////        licenceType.IsActive = false;
        ////        //make change
        ////        licenceType.ModifiedBy = saveRequest.LoginEmpId;        ////        licenceType.ModifiedOn = DateTime.Now;        ////    }

        ////    // foreach loop for to update driverLType info.
        ////    foreach (var licenseType in saveRequest.LicenseType)        ////    {        ////        var existingLicenseType = driverLicenseTypes.Where(x => x.LicenseType == licenseType).FirstOrDefault();        ////        if (existingLicenseType != null)        ////        {        ////            existingLicenseType.IsActive = true;
        ////            //make change
        ////            existingLicenseType.ModifiedBy = saveRequest.LoginEmpId;        ////            existingLicenseType.ModifiedOn = DateTime.Now;        ////        }        ////        else        ////        {        ////            var driverLType = new DriverLTyp()        ////            {        ////                EmployeeId = driverLicenese.EmployeeId,        ////                EmpId = driverLicenese.EMPLId,        ////                DriversLicNBR = driverLicenese.DriverLicenseNumber,        ////                LicenseType = licenseType,        ////                IsActive = true,
        ////                //make change
        ////                CreatedBy = saveRequest.LoginEmpId,        ////                CreatedOn = DateTime.Now,        ////            };        ////            _context.DriverLTyps.Add(driverLType);        ////        }        ////    }
        ////    // For US and Canada
        ////    //if (saveRequest.Region == eDMSConstant.regionCAN || saveRequest.Region == eDMSConstant.regionUSA)
        ////    if (saveRequest.Region.Contains("CA") || saveRequest.Region.Contains("US"))        ////    {        ////        var maxSEQNUM = driverLicenese.SEQNUM;        ////        string driverType = (driverLicenese?.DriverType != null) ? driverLicenese?.DriverType : string.Empty;        ////        string cdlLicense = (driverLicenese?.CDL_LICENSE != null) ? driverLicenese?.CDL_LICENSE : string.Empty;        ////        string documentCategory = string.Empty;

        ////        //if (driverType == "DOT" && cdlLicense == "Y")
        ////        //    documentCategory = driverType + "_CDL";
        ////        //else if (driverType == "DOT" && cdlLicense == "N")
        ////        //    documentCategory = driverType + "_NONCDL";
        ////        //if (driverType == "NDOT")
        ////        //    documentCategory = "NON_DOT";
                
        ////        //documentCategory = GetDocumentCategory(driverType, cdlLicense);
        ////        CommonMethods common = new CommonMethods();        ////        documentCategory = common.GetDocumentCategory(driverType, cdlLicense);

        ////        var riskIndexDE = await _unitOfWork.RiskIndexes.GetByIdAsync(saveRequest.DERiskIndexId);        ////        var riskIndexMV = await _unitOfWork.RiskIndexes.GetByIdAsync(saveRequest.MVRiskIndexId);

        ////        var riskType_DE = await _unitOfWork.RiskTypes.GetByTypeAsync(eDMSConstant.vopeRisk);
        ////        int riskTypeId_DE = riskType_DE.RiskTypeId;
        ////        var driverRisk_DE = await _unitOfWork.DriverRisks.GetByDLRiskTypeAsync(driverLicenese.DriverLicId, riskTypeId_DE);        ////        if (driverRisk_DE != null)        ////        {        ////            var driverRiskDE = new DriverRisks        ////            {        ////                DriverRiskId = driverRisk_DE.DriverRiskId,        ////                DriverLicenseId = driverLicenese.DriverLicId,        ////                RiskTypeId = riskTypeId_DE,        ////                RiskIndexValueId = saveRequest.DERiskIndexId,        ////                CreatedBy = driverRisk_DE.CreatedBy,        ////                IsActive = true,        ////                CreatedOn = driverRisk_DE.CreatedOn,
        ////                //make change
        ////                ModifiedBy = saveRequest.LoginEmpId,        ////                ModifiedOn = DateTime.Now        ////            };        ////            _context.DriversRisk.Update(driverRiskDE);        ////        }        ////        var riskType_MV = await _unitOfWork.RiskTypes.GetByTypeAsync(eDMSConstant.abstractRisk);
        ////        int RiskTypeId_MV = riskType_MV.RiskTypeId;
        ////        var driverRisk_MV = await _unitOfWork.DriverRisks.GetByDLRiskTypeAsync(driverLicenese.DriverLicId, RiskTypeId_MV);        ////        if (driverRisk_MV != null)        ////        {        ////            var driverRiskMV = new DriverRisks        ////            {        ////                DriverRiskId = driverRisk_MV.DriverRiskId,        ////                DriverLicenseId = driverLicenese.DriverLicId,        ////                RiskTypeId = RiskTypeId_MV,        ////                RiskIndexValueId = saveRequest.MVRiskIndexId,        ////                CreatedBy = driverRisk_MV.CreatedBy,        ////                CreatedOn = DateTime.Now,        ////                IsActive = true,
        ////                //make change
        ////                ModifiedBy = saveRequest.LoginEmpId,
        ////                ModifiedOn = DateTime.Now        ////            };        ////            _context.DriversRisk.Update(driverRiskMV);        ////        }
        ////        // initialise dlUpldWrk object for Driver Evaluation.
        ////        var dlUpldWrkDE = new DLUPLDWRK        ////        {        ////            EMPLId = saveRequest.EmplId,        ////            EmployeeId = saveRequest.EmployeeId,        ////            DLUpldDate = DateTime.Now,        ////            ValidFromDate = DateTime.Now,        ////            ValidToDate = DateTime.Now,        ////            RiskIndexId = saveRequest.DERiskIndexId,        ////            RiskIndex = riskIndexDE.RiskIndex.Substring(0, 1),        ////            MandatoryItem = eDMSConstant.yes,        ////            IsActive = true,        ////            DocCategory = documentCategory,        ////            DLDocType = eDMSConstant.vopeEVAL        ////        };        ////        var dlUpldWrk_DE = await _unitOfWork.DLUPLDWRKs.GetDetailToSave(dlUpldWrkDE);        ////        if (dlUpldWrk_DE != null)        ////        {
        ////            dlUpldWrkDE.DL_UPLD_WRK_Id = dlUpldWrk_DE.DL_UPLD_WRK_Id;
        ////            dlUpldWrkDE.CreatedBy = dlUpldWrk_DE.CreatedBy;
        ////            dlUpldWrkDE.CreatedOn = dlUpldWrk_DE.CreatedOn;
        ////            //make change
        ////            dlUpldWrkDE.ModifiedBy = saveRequest.LoginEmpId;
        ////            dlUpldWrkDE.ModifiedOn = DateTime.Now;
        ////            dlUpldWrkDE.UploadStatus = dlUpldWrk_DE.UploadStatus == null ? "" : dlUpldWrk_DE.UploadStatus;        ////            dlUpldWrkDE.DLUpldDate = dlUpldWrk_DE.DLUpldDate;
        ////            _context.DLUPLDWRKs.Update(dlUpldWrkDE);        ////            _context.SaveChanges();        ////        }
        ////        else
        ////        {
        ////            //make change
        ////            dlUpldWrkDE.CreatedBy = saveRequest.LoginEmpId;
        ////            dlUpldWrkDE.CreatedOn = DateTime.Now;
        ////            dlUpldWrkDE.UploadStatus = "";        ////           // dlUpldWrkDE.DLUpldDate = dlUpldWrkDE.DLUpldDate;
        ////            _context.DLUPLDWRKs.Add(dlUpldWrkDE);        ////            _context.SaveChanges();        ////        }

        ////        // initialise dlUpldWrkMV object.
        ////        var dlUpldWrkMV = new DLUPLDWRK        ////        {        ////            EMPLId = saveRequest.EmplId,        ////            EmployeeId = saveRequest.EmployeeId,        ////            DLUpldDate = DateTime.Now,        ////            ValidFromDate = DateTime.Now,        ////            ValidToDate = DateTime.Now,        ////            RiskIndex = riskIndexMV.RiskIndex.Substring(0, 1),        ////            RiskIndexId = saveRequest.MVRiskIndexId,        ////            MandatoryItem = eDMSConstant.yes,        ////            IsActive = true,        ////            DocCategory = documentCategory        ////        };

        ////        //if (saveRequest.Region == eDMSConstant.regionCAN)
        ////        //    if (saveRequest.Region.Contains("CA"))
        ////        //        dlUpldWrkMV.DLDocType = "ABSTR_PROD";
        ////        //    //else if (saveRequest.Region == eDMSConstant.regionUSA)
        ////        //    else if (saveRequest.Region.Contains("US"))
        ////        //    {
        ////        //        if (driverType == "DOT")
        ////        //            dlUpldWrkMV.DLDocType = "ANLREV_FRM";

        ////        //        else if (driverType == "NDOT")
        ////        //            dlUpldWrkMV.DLDocType = "DRV_MVRRCD";
        ////        //    }
        ////        //    else
        ////        //        dlUpldWrkMV.DLDocType = "DRV_MVRRCD";

        ////        //dlUpldWrkMV.DLDocType = GetDocType(saveRequest.Region, driverType);
        ////        dlUpldWrkMV.DLDocType = common.GetDocType(saveRequest.Region, driverType);
        ////        var dlUpldWrk_MV = await _unitOfWork.DLUPLDWRKs.GetDetailToSave(dlUpldWrkMV);

        ////        if (dlUpldWrk_MV != null)        ////        {
        ////            dlUpldWrkMV.DL_UPLD_WRK_Id = dlUpldWrk_MV.DL_UPLD_WRK_Id;
        ////            dlUpldWrkMV.CreatedBy = dlUpldWrk_MV.CreatedBy;
        ////            dlUpldWrkMV.CreatedOn = dlUpldWrk_MV.CreatedOn;
        ////            //make change
        ////            dlUpldWrkMV.ModifiedBy = saveRequest.LoginEmpId;
        ////            dlUpldWrkMV.ModifiedOn = DateTime.Now;
        ////            dlUpldWrkMV.UploadStatus = dlUpldWrk_MV.UploadStatus == null ? "" : dlUpldWrk_MV.UploadStatus;        ////            dlUpldWrkMV.DLUpldDate = dlUpldWrk_MV.DLUpldDate;
        ////            _context.DLUPLDWRKs.Update(dlUpldWrkMV);        ////            _context.SaveChanges();        ////        }        ////        else
        ////        {
        ////            //make change
        ////            dlUpldWrkMV.CreatedBy = saveRequest.LoginEmpId;
        ////            dlUpldWrkMV.CreatedOn = DateTime.Now;
        ////            dlUpldWrkMV.UploadStatus = "";
        ////            _context.DLUPLDWRKs.Add(dlUpldWrkMV);
        ////            _context.SaveChanges();
        ////        }

        ////        try        ////        {
        ////            // Risk calculation API call.
        ////            //RisksRequest riskRequest = new RisksRequest();        ////            //riskRequest.DriverRiskId = 0;        ////            //riskRequest.DriverLicenseId = 0;        ////            //riskRequest.DriverId = saveRequest.EmployeeId;        ////            //riskRequest.EmplId = saveRequest.EmplId;        ////            //riskRequest.inputScope = null;//transactionScope;                    
        ////            //riskRequest.Region = "";

        ////            RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);        ////            List<DriverRiskList> driverRisks = null;
        ////            if (driverLicenese != null)
        ////            {
        ////                var result = await rskController.GetOverAllRisk(((int)(driverLicenese?.DriverLicId)));
        ////                driverRisks = result.Result;
        ////                UpdateOverAllRisks(driverRisks, saveRequest.LoginEmpId);
        ////            }
        ////            // var riskResponse = await rskController.Post(riskRequest);
        ////        }        ////        catch (Exception ex)
        ////        {        ////            Console.WriteLine(ex.Message);        ////            Console.WriteLine(ex.InnerException);        ////        }        ////    }        ////    else        ////    {
        ////        // For other than US and Canada.
        ////        var driverRiskOA = await _unitOfWork.DriverRisks.GetByDLRiskTypeAsync(driverLicenese.DriverLicId, 5);        ////        driverRiskOA.RiskIndexValueId = (saveRequest.OARiskIndexId == 0) ? 9 : saveRequest.OARiskIndexId;
        ////        //make change
        ////        driverRiskOA.ModifiedBy = saveRequest.LoginEmpId;
        ////        driverRiskOA.ModifiedOn = DateTime.Now;        ////        driverRiskOA.IsActive = true;        ////        _context.DriversRisk.Update(driverRiskOA);        ////    }        ////    _context.SaveChanges();        ////    apiResponse.Result = 1;
        ////    apiResponse.Success = true;
        ////    return apiResponse;        ////}

        private void UpdateOverAllRisks(List<DriverRiskList> driverRisks, int loginEmpId)
        {
            int driverRisksResult = 1;
            var overAllRisk = driverRisks.Where(x => x.RiskType == eDMSConstant.OverallRisk).SingleOrDefault<DriverRiskList>();
            int overAllRiskIndexValueId = eDMSConstant.overAllRiskIndexNA;//9;
            bool removeOverAllRisk = driverRisks.Remove(overAllRisk);
            bool IsHighExist = driverRisks.Any(n => n.RiskIndex == eDMSConstant.highRisk);//"High"
            if (!IsHighExist)
            {
                bool IsMediumExist = driverRisks.Any(n => n.RiskIndex == eDMSConstant.mediumRisk);//"Medium"
                if (!IsMediumExist)
                {
                    bool IsLowExist = driverRisks.Any(n => n.RiskIndex == eDMSConstant.lowRisk);//"Low"
                    if (IsLowExist)
                        overAllRiskIndexValueId = eDMSConstant.lowRiskIndex; //3;
                }
                else
                    overAllRiskIndexValueId = eDMSConstant.mediumRiskIndex; ;
            }
            else
                overAllRiskIndexValueId = eDMSConstant.highRiskIndex; ;
            if (overAllRisk != null)
            {
                // if (overAllRiskIndexValueId != eDMSConstant.overAllRiskIndexNA)
                //{
                overAllRisk.RiskIndexValueId = overAllRiskIndexValueId;
                driverRisks.Add(overAllRisk);
                DriverRisks objOverAll = new DriverRisks()
                {
                    DriverRiskId = overAllRisk.DriverRiskId,
                    DriverLicenseId = overAllRisk.DriverLicId,
                    RiskTypeId = overAllRisk.RiskTypeId,
                    RiskIndexValueId = overAllRiskIndexValueId,
                    ModifiedBy = loginEmpId,
                    ModifiedOn = DateTime.Now,
                    IsActive = overAllRisk.IsActive,
                    CreatedBy = overAllRisk.CreatedBy
                };
                //  driverRisksResult = await _unitOfWork.DriverRisks.SaveAsync(objOverAll);
                ApplicationDBContext objContext = new ApplicationDBContext();
                objContext.DriversRisk.Update(objOverAll);
                objContext.SaveChanges();
                //}
            }
        }

        [HttpPost]        public async Task<ApiResponse<int>> Add(DriverLicense driverLicense)        {            var apiResponse = new ApiResponse<int>();            if (driverLicense == null)                throw new DMSException(CommonMessages.InvalidModelMessage);            var data = await _unitOfWork.DriverLicenses.SaveAsync(driverLicense);            apiResponse.Success = true;            apiResponse.Result = data;            apiResponse.Message = CommonMessages.AddSuccessMessage;            if (apiResponse.Result == 0)                throw new DMSException(CommonMessages.AddErrorMessage);            return apiResponse;        }        [HttpPut]        public async Task<ApiResponse<int>> Update(DriverLicense country)        {            var apiResponse = new ApiResponse<int>();            if (country == null)                throw new DMSException(CommonMessages.InvalidModelMessage);            var data = await _unitOfWork.DriverLicenses.SaveAsync(country);            apiResponse.Success = true;            apiResponse.Result = data;            apiResponse.Message = CommonMessages.UpdateSuccessMessage;            if (apiResponse.Result == 0)                throw new DMSException(CommonMessages.UpdateErrorMessage);            return apiResponse;        }        [HttpDelete]        public async Task<ApiResponse<int>> Delete(int id)        {            if (id <= 0)                throw new DMSException(CommonMessages.InputIDErrorMessage);            var apiResponse = new ApiResponse<int>();            var data = await _unitOfWork.DriverLicenses.DeleteAsync(id);            apiResponse.Success = true;            apiResponse.Result = data;            apiResponse.Message = CommonMessages.DeletedSuccessMessage;            if (apiResponse.Result == 0)                throw new DMSException(CommonMessages.DeleteErrorMessage);            return apiResponse;        }        [HttpPost("getMany")]        public async Task<ApiResponse<DriversSearchResult>> Get(DriverSearchRequest request)        {            var apiResponse = new ApiResponse<DriversSearchResult>();            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)            {                request.START_INDEX = null;                request.PAGE_SIZE = null;            }            //var data = await _unitOfWork.DriversSearchResultList.GetManyAsync(request);            var data = await _unitOfWork.DriversSearchResultList.GetManyAsyncResult(request);            apiResponse.Result = data;            apiResponse.Success = true;            // apiResponse.Result = new DriversSearchResult();            // apiResponse.Result.driverSearchResultList = new List<DriverSearchResult> ();            // apiResponse.Result.driverSearchResultList = (List<DriverSearchResult>)data;            if (apiResponse.Result.driverSearchResultList.Count == 0)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }        ////[HttpPost("getManagers")]        ////public async Task<ApiResponse<ManagersSearchResult>> GetManagers(ManagerSearchRequest request)        ////{        ////    int? top = null;        ////    int? skip = null;        ////    var apiResponse = new ApiResponse<ManagersSearchResult>();        ////    Expression<Func<EmployeeMaster, bool>> filterData = getFilterData(request)!;        ////    if (request.START_INDEX == 0)        ////    {        ////        top = null;        ////        skip = null;        ////    }        ////    if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)        ////    {        ////        top = null;        ////        skip = null;        ////    }        ////    else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)        ////    {        ////        top = request.PAGE_SIZE;        ////        skip = null;        ////    }        ////    else        ////    {        ////        top = request.PAGE_SIZE;        ////        skip = (request.START_INDEX - 1) * request.PAGE_SIZE;        ////    }        ////    var data = await _unitOfWork.ManagersSearchResultList.GetManyAsync(filterData, null, null, null);        ////    data.managerSearchResult = data.managerSearchResult.GroupBy(x => x.ManagerCode).Select(g => g.First()).ToList();        ////    data.TotalCount = data.managerSearchResult.Count;        ////    List<ManagerSearchResult> distinctRows = null;        ////    if (request.filterDetails.Count > 0)        ////    {        ////        if (request.filterDetails[0].FilterColumnName == "ManagerName")        ////        {        ////            distinctRows = data.managerSearchResult.GroupBy(x => x.ManagerName).Select(g => g.First()).ToList();        ////        }        ////        if (request.filterDetails[0].FilterColumnName == "ManagerCode")        ////        {        ////            if (distinctRows == null)        ////                distinctRows = data.managerSearchResult.GroupBy(x => x.ManagerCode).Select(g => g.First()).ToList();        ////            else        ////                distinctRows = distinctRows.GroupBy(x => x.ManagerCode).Select(g => g.First()).ToList();        ////        }        ////        data.TotalCount = distinctRows.Count;        ////    }        ////    else 
        ////    {
        ////        if (top > 0 && skip > 0)
        ////        {
        ////            data.managerSearchResult = data.managerSearchResult.Skip(skip.GetValueOrDefault()).Take(top.GetValueOrDefault()).ToList();
        ////        }
        ////        else if (top > 0 && (skip == 0 || skip == null))
        ////        {
        ////            data.managerSearchResult = data.managerSearchResult.Take(top.GetValueOrDefault()).ToList();
        ////        }        ////    }        ////    if (distinctRows != null && distinctRows.Count > 0)        ////    {        ////        if (top > 0 && skip > 0)
        ////        {  
        ////            distinctRows = distinctRows.Skip(skip.GetValueOrDefault()).Take(top.GetValueOrDefault()).ToList();
        ////        }        ////        else if (top > 0 && (skip == 0 || skip == null)) {
        ////            distinctRows = distinctRows.Take(top.GetValueOrDefault()).ToList();
        ////        }
        ////    }
        ////    if(distinctRows!=null)
        ////        data.managerSearchResult = distinctRows;                        ////    //}        ////    // var data = await _unitOfWork.ManagersSearchResultList.GetManyAsync();        ////    apiResponse.Result = data;        ////    apiResponse.Success = true;        ////    if (apiResponse.Result.managerSearchResult.Count == 0)        ////        throw new DMSException(CommonMessages.GetErrorMessage);        ////    return apiResponse;        ////}        [HttpPost("getLocations")]        public async Task<ApiResponse<LocationsSearchResult>> GetLocations(SearchPagingRequest request)        {            var apiResponse = new ApiResponse<LocationsSearchResult>();            Expression<Func<MDMLocation, bool>> filterData = getLocationFilterData(request)!;            int? top = null;            int? skip = null;            if (request.START_INDEX == 0)            {                top = null;                skip = null;            }            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)            {                top = null;                skip = null;            }            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)            {                top = request.PAGE_SIZE;                skip = null;            }            else            {                top = request.PAGE_SIZE;                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;            }            var data = await _unitOfWork.LocationsSearchResultList.GetManyAsync(filterData, null, top, skip);            apiResponse.Result = data;            apiResponse.Success = true;            if (apiResponse.Result.locationSearchResult.Count == 0)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }

        [HttpPost("getBusinessUnitFilterData")]        public async Task<ApiResponse<GenericMastersSearchResult>> GetBusinessUnitFilterData(SearchPagingRequest request)        {            var apiResponse = new ApiResponse<GenericMastersSearchResult>();            Expression<Func<BusinessUnit, bool>> filterData = getBusinessUnitFilterResult(request)!;            int? top = null;            int? skip = null;            if (request.START_INDEX == 0)            {                top = null;                skip = null;            }            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)            {                top = null;                skip = null;            }            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)            {                top = request.PAGE_SIZE;                skip = null;            }            else            {                top = request.PAGE_SIZE;                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;            }            var data = await _unitOfWork.BusinessUnitsSearchResultList.GetManyBusinessUnitAsync(filterData, null, top, skip);            apiResponse.Result = data;            apiResponse.Success = true;            if (apiResponse.Result.genericMasterResultList.Count == 0)                throw new DMSException(CommonMessages.GetErrorMessage);            return apiResponse;        }        [NonAction]        internal Expression<Func<EmployeeMaster, bool>>? getFilterData(ManagerSearchRequest request)        {            if (request.filterDetails != null && request.filterDetails.Count > 0)            {                List<Expression<Func<EmployeeMaster, bool>>> obList = new List<Expression<Func<EmployeeMaster, bool>>>();                foreach (var kvp in request.filterDetails)                {                    obList.Add(FilterHelper<EmployeeMaster>.getFilter(kvp));                }                var combinedFilter = FilterHelper<EmployeeMaster>.CombineFilters(obList);                return combinedFilter;            }            return null;        }

        [NonAction]        internal Expression<Func<EmployeeMaster, bool>>? getFilterResult(SearchPagingRequest request)        {            if (request.filterDetails != null && request.filterDetails.Count > 0)            {                List<Expression<Func<EmployeeMaster, bool>>> obList = new List<Expression<Func<EmployeeMaster, bool>>>();                foreach (var kvp in request.filterDetails)                {                    obList.Add(FilterHelper<EmployeeMaster>.getFilter(kvp));                }                var combinedFilter = FilterHelper<EmployeeMaster>.CombineFilters(obList);                return combinedFilter;            }            return null;        }
                [NonAction]        internal Expression<Func<BusinessUnit, bool>>? getBusinessUnitFilterResult(SearchPagingRequest request)        {            if (request.filterDetails != null && request.filterDetails.Count > 0)            {                List<Expression<Func<BusinessUnit, bool>>> obList = new List<Expression<Func<BusinessUnit, bool>>>();                foreach (var kvp in request.filterDetails)                {                    obList.Add(FilterHelper<BusinessUnit>.getFilter(kvp));                }                var combinedFilter = FilterHelper<BusinessUnit>.CombineFilters(obList);                return combinedFilter;            }            return null;        }        [NonAction]        internal Expression<Func<MDMLocation, bool>>? getLocationFilterData(SearchPagingRequest request)        {            if (request.filterDetails != null && request.filterDetails.Count > 0)            {                List<Expression<Func<MDMLocation, bool>>> obList = new List<Expression<Func<MDMLocation, bool>>>();                foreach (var kvp in request.filterDetails)                {                    obList.Add(FilterHelper<MDMLocation>.getFilter(kvp));                }                var combinedFilter = FilterHelper<MDMLocation>.CombineFilters(obList);                return combinedFilter;            }            return null;        }        //private string GetDocType(string region, string driverType)
        //{
        //    string docType = string.Empty;
        //    if (region.Contains("CA"))
        //        docType = eDMSConstant.abstrPROD; //"ABSTR_PROD";
        //    else if (region.Contains("US"))
        //    {
        //        if (driverType == "DOT")
        //            docType = eDMSConstant.anlrevFRM; //"ANLREV_FRM";

        //        else if (driverType == "NDOT")
        //            docType = eDMSConstant.drvMVRRCD; //"DRV_MVRRCD";
        //    }
        //    else
        //        docType = eDMSConstant.drvMVRRCD; //"DRV_MVRRCD";

        //    return docType;
        //}

        //private string GetDocumentCategory(string driverType, string cdlLicense)
        //{
        //    string documentCategory = string.Empty;
        //    if (driverType == eDMSConstant.driverTypeDOT && cdlLicense == eDMSConstant.yes)
        //        documentCategory = driverType + eDMSConstant.documentCategoryCDL;
        //    else if (driverType == eDMSConstant.driverTypeDOT && cdlLicense == eDMSConstant.no)
        //        documentCategory = driverType + eDMSConstant.documentCategoryNONCDL;
        //    if (driverType == eDMSConstant.driverTypeNDOT)
        //        documentCategory = eDMSConstant.documentCategoryNONDOT;
        //    return documentCategory;
        //}
        #endregion    }}