﻿using Azure.Core;
//using eDMS.Api.Controllers.ToBeDeleted;
using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.RiskCalculations.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage;
using System.Transactions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriverBehaviourRiskViewController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _configuration;
        Uri baseAddress;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public DriverBehaviourRiskViewController(IUnitOfWork unitOfWork, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _configuration = configuration; 
            baseAddress = new Uri(GetKeyValue(_configuration, "appConfigurations:baseURI"));//new Uri(eDMSConstant.baseURI);
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<DriverBehaviourRiskView>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<DriverBehaviourRiskView>>();
            var data = await _unitOfWork.DriverBehaviourRiskViews.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<DriverBehaviourRiskView>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DriverBehaviourRiskView>();
            var data = await _unitOfWork.DriverBehaviourRiskViews.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        //[HttpPost("SaveIncident")]
        //public async Task<ApiResponse<int>> Add(DriverIncidentRequest driverIncidentRequest)
        //{
        //    ApplicationDBContext _context = new ApplicationDBContext();
        //    var apiResponse = new ApiResponse<int>();
        //    if (driverIncidentRequest == null)
        //        throw new DMSException(CommonMessages.InvalidModelMessage);

        //    // Get IncidentType based on IncidentTypeId
        //  //  var incidentTypeResponse = null;//await _unitOfWork.IncidentTypes.GetByIdAsync(driverIncidentRequest.IncidentTypeId);

        //    // Get IncidentValue based on IncidentValueId
        //  //  var incidentResponse = null;// await _unitOfWork.IncidentValues.GetByIdAsync(driverIncidentRequest.IncidentValueId);

        //    // Get RiskIndex based on RiskIndexId
        // //   var riskIndexResponse = null;// await _unitOfWork.RiskIndexes.GetByIdAsync(driverIncidentRequest.RiskIndexId);

        //    var driverBehaviourRiskView = new DriverBehaviourRiskView
        //    {
        //        DriverBehaviourId = driverIncidentRequest.DriverBehaviourId,
        //        Date1 = driverIncidentRequest.Date1,
        //        Time_Entered = driverIncidentRequest.Time_Entered,
        //        IncidentTypeId = driverIncidentRequest.IncidentTypeId,
        //        IncidentType = incidentTypeResponse.IncidentType,
        //        IncidentValueId = driverIncidentRequest.IncidentValueId,
        //        IncidentValue = incidentResponse.IncidentValue,
        //        ViolationValueId = driverIncidentRequest.ViolationSeverityMatrixId,
        //        //ViolationValue = violationValueResponse.Result.ViolationDescription,
        //        RiskIndex = riskIndexResponse.RiskIndex.Substring(0, 1),
        //        RiskIndexId = driverIncidentRequest.RiskIndexId,
        //        Descr200 = driverIncidentRequest.Descr200,
        //        DescrLong_Notes = driverIncidentRequest.DescrLong_Notes,
        //        Date2 = driverIncidentRequest.Date2,
        //        Time_Recorded = driverIncidentRequest.Time_Recorded,
        //        EFFDate = driverIncidentRequest.EFFDate,
        //        Time_Edit = driverIncidentRequest.Time_Edit,
        //        DOT_Test_date = driverIncidentRequest.DOT_Test_date,
        //        DOT_Recordable = driverIncidentRequest.DOT_Recordable
        //    };

        //    if (driverBehaviourRiskView?.ViolationValueId == 0 || driverBehaviourRiskView?.ViolationValueId == null)
        //    {
        //        HttpResponseMessage voilationByDesc = await new HttpClient().GetAsync(baseAddress + "ViolationSeverityMatrix/GetByDescription/" + eDMSConstant.defaultViolationValue);
        //        var voilationByDescResponse = await voilationByDesc.Content.ReadFromJsonAsync<ApiResponse<MDMViolationSeverityMatrix>>();

        //        driverBehaviourRiskView.ViolationValue = voilationByDescResponse.Result.ViolationValue.ToString(); //eDMSConstant.defaultViolationValue;
        //        driverBehaviourRiskView.ViolationValueId = voilationByDescResponse.Result.ViolationSeverityMatrixId;
        //    }
        //    else
        //    {
        //        HttpResponseMessage violationValue = await new HttpClient().GetAsync(baseAddress + "ViolationSeverityMatrix/GetById/" + driverIncidentRequest.ViolationSeverityMatrixId);
        //        var violationValueResponse = await violationValue.Content.ReadFromJsonAsync<ApiResponse<MDMViolationSeverityMatrix>>();

        //        driverBehaviourRiskView.ViolationValueId = violationValueResponse.Result.ViolationSeverityMatrixId;
        //        driverBehaviourRiskView.ViolationValue = violationValueResponse.Result.ViolationValue.ToString();
        //    }
            
        //    var employeeSeq = _context.DriverBehaviourRiskViews.Where(r => r.EmployeeId == driverIncidentRequest.EmployeeId).
        //                    OrderByDescending(r => r.SeqNo).FirstOrDefault();
        //    int seqNo = (employeeSeq?.SeqNo != null) ? employeeSeq.SeqNo + 1 : 1;

        //    if (driverIncidentRequest.DriverBehaviourId == 0)
        //    {
        //        driverBehaviourRiskView.EmpId = driverIncidentRequest.EmpId;
        //        driverBehaviourRiskView.EmployeeId = driverIncidentRequest.EmployeeId;
        //        driverBehaviourRiskView.IsActive = true;
        //        driverBehaviourRiskView.SeqNo = seqNo;

        //        driverBehaviourRiskView.CreatedBy = driverIncidentRequest.LoginEmpId;
        //        driverBehaviourRiskView.CreatedOn = DateTime.Now;
        //        driverBehaviourRiskView.ModifiedBy = null;
        //        driverBehaviourRiskView.ModifiedOn = null;
        //    }
        //    else
        //    {
        //        HttpResponseMessage driveRiskBehaviour = await new HttpClient().GetAsync(baseAddress + "DriverBehaviourRiskView/" + driverIncidentRequest.DriverBehaviourId);
        //        var commendationResponse = await driveRiskBehaviour.Content.ReadFromJsonAsync<ApiResponse<DriverBehaviourRiskView>>();
        //        if (commendationResponse != null && commendationResponse.Result != null && commendationResponse.Success)
        //        {
        //            driverBehaviourRiskView.EmpId = commendationResponse.Result.EmpId;
        //            driverBehaviourRiskView.EmployeeId = commendationResponse.Result.EmployeeId;
        //            driverBehaviourRiskView.IsActive = commendationResponse.Result.IsActive;
                    
        //            driverBehaviourRiskView.CreatedBy = commendationResponse.Result.EmployeeId;
        //            driverBehaviourRiskView.CreatedOn = commendationResponse.Result.CreatedOn;
        //            driverBehaviourRiskView.ModifiedBy = driverIncidentRequest.LoginEmpId;
        //            driverBehaviourRiskView.ModifiedOn = DateTime.Now;
        //        }
        //    }
        //    // TransactionScope transactionScope = new TransactionScope();
        //    IDbContextTransaction trans = _context.Database.BeginTransaction();
        //    //using (ApplicationDBContext _contextRisk = new ApplicationDBContext())
        //    //{
        //    //    using (var trans =_contextRisk.Database.BeginTransaction())
        //    //    {
        //    try
        //    //  using (var transactionScope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
        //    {
        //        var data = await _unitOfWork.DriverBehaviourRiskViews.SaveAsync(driverBehaviourRiskView);
        //        apiResponse.Success = true;
        //        apiResponse.Result = data;
        //        apiResponse.Message = CommonMessages.AddSuccessMessage;

        //        if (apiResponse.Result == 0)
        //            throw new DMSException(CommonMessages.AddErrorMessage);
        //        else
        //        {
        //            // Risk calculation API call.
        //            ////RisksRequest riskRequest = new RisksRequest();
        //            ////riskRequest.DriverRiskId = 0;
        //            ////riskRequest.DriverLicenseId = 0;
        //            ////riskRequest.DriverId = driverBehaviourRiskView.EmployeeId;
        //            ////riskRequest.EmplId = driverBehaviourRiskView.EmpId;
        //            ////riskRequest.inputScope = null;//transactionScope;                    
        //            ////riskRequest.Region = "";
        //            ////riskRequest.inputTransaction = trans;

        //            ////RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);
        //            ////var riskResponse = await rskController.Post(riskRequest);
        //            /////RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);
        //           //// var riskResponse = await rskController.GetBehavior(driverBehaviourRiskView.EmpId, driverIncidentRequest.LoginEmpId);

        //            //DriverLicenseController dlController = new DriverLicenseController(_unitOfWork);
        //            //var dLicense = await dlController.GetLatestDLByEmpID(driverIncidentRequest.EmpId);
                    
        //            //RiskTypeController rtController = new RiskTypeController(_unitOfWork);
        //            //var overAllRiskType = rtController.GetByType(eDMSConstant.OverallRisk);

        //            //DriverRiskController drController = new DriverRiskController(_unitOfWork);
        //            //var overAllRisk = drController.GetById(dLicense.Result.DriverLicId, overAllRiskType.Result.Result.RiskTypeId);

        //            //DriverRisks objOverAll = new DriverRisks()
        //            //{
        //            //    DriverRiskId = overAllRisk.Result.Result.DriverRiskId,
        //            //    DriverLicenseId = overAllRisk.Result.Result.DriverLicenseId,
        //            //    RiskTypeId = overAllRisk.Result.Result.RiskTypeId,
        //            //    RiskIndexValueId = overAllRisk.Result.Result.RiskIndexValueId,
        //            //    ModifiedBy = driverIncidentRequest.LoginEmpId,
        //            //    ModifiedOn = DateTime.Now,
        //            //    IsActive = overAllRisk.Result.Result.IsActive,
        //            //    CreatedBy = overAllRisk.Result.Result.CreatedBy
        //            //};
        //            //ApplicationDBContext objContext = new ApplicationDBContext();
        //            //objContext.DriversRisk.Update(objOverAll);
        //            //objContext.SaveChanges();

        //            var resulrBehav = trans.CommitAsync();
        //            //  if (transactionScope != null && riskRequest.inputScope==null)
        //            //     transactionScope.Complete();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        if (trans != null)
        //        {
        //            trans.Rollback();
        //        }
        //    }
        //    finally
        //    {
        //        if (trans != null)
        //        {
        //            trans.Dispose();
        //        }

        //    }
        //    return apiResponse;
        //}

        [HttpPost("SaveCommendation")]
        public async Task<ApiResponse<int>> Add(DriverCommendationRequest driverCommendationRequest)
        {
            ApplicationDBContext _context = new ApplicationDBContext();
            var apiResponse = new ApiResponse<int>();
            if (driverCommendationRequest == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            // Get default value for IncidentValue
            HttpResponseMessage incidentValues = await new HttpClient().GetAsync(baseAddress + "IncidentValues/GetByType/" + eDMSConstant.defaultIncidentValue);
            var incidentResponse = await incidentValues.Content.ReadFromJsonAsync<ApiResponse<MDMIncidentValue>>();

            // Get default value for RiskIndex
            HttpResponseMessage riskIndex = await new HttpClient().GetAsync(baseAddress + "RiskIndex/GetByType/" + eDMSConstant.defaultRiskIndex);
            var riskResponse = await riskIndex.Content.ReadFromJsonAsync<ApiResponse<MDMRiskIndex>>();

            // Get default value for ViolationValue
            HttpResponseMessage violationValue = await new HttpClient().GetAsync(baseAddress + "ViolationSeverityMatrix/GetByDescription/" + eDMSConstant.defaultViolationValue);
            var violationResponse = await violationValue.Content.ReadFromJsonAsync<ApiResponse<MDMViolationSeverityMatrix>>();

            // Get IncidentType based on IncidentTypeId
            HttpResponseMessage incidentType = await new HttpClient().GetAsync(baseAddress + "IncidentType/" + driverCommendationRequest.IncidentTypeId);
            var incidentTypeResponse = await incidentType.Content.ReadFromJsonAsync<ApiResponse<MDMIncidentType>>();

            //initiate table entity from request model
            var driverBehaviourRiskView = new DriverBehaviourRiskView
            {
                DriverBehaviourId = driverCommendationRequest.DriverBehaviourId,
                Date1 = driverCommendationRequest.Date1,
                Time_Entered = driverCommendationRequest.Time_Entered,
                IncidentTypeId = driverCommendationRequest.IncidentTypeId,
                IncidentType = incidentTypeResponse.Result.IncidentType,
                Descr200 = driverCommendationRequest.Descr200,
            };

            var employeeSeq = _context.DriverBehaviourRiskViews.Where(r => r.EmployeeId == driverCommendationRequest.EmployeeId).
                            OrderByDescending(r => r.SeqNo).FirstOrDefault();
            int seqNo = (employeeSeq?.SeqNo != null) ? employeeSeq.SeqNo + 1 : 1;

            if (driverCommendationRequest.DriverBehaviourId == 0)
            {
                driverBehaviourRiskView.EmpId = driverCommendationRequest.EmpId;
                driverBehaviourRiskView.EmployeeId = driverCommendationRequest.EmployeeId;
                driverBehaviourRiskView.DOT_Recordable = "N";
                driverBehaviourRiskView.DOT_Test_date = string.Empty;
                driverBehaviourRiskView.SeqNo = seqNo;

                //DFefault values for RiskIndex, IncidentValue and ViolationValue fields
                driverBehaviourRiskView.RiskIndex = eDMSConstant.defaultRiskIndex;
                driverBehaviourRiskView.RiskIndexId = riskResponse.Result.RiskIndexId;
                driverBehaviourRiskView.IncidentValue = eDMSConstant.defaultIncidentValue;
                driverBehaviourRiskView.IncidentValueId = incidentResponse.Result.IncidentValueId;
                driverBehaviourRiskView.ViolationValue = eDMSConstant.defaultViolationValue;
                driverBehaviourRiskView.ViolationValueId = violationResponse.Result.ViolationSeverityMatrixId;

                driverBehaviourRiskView.IsActive = true;
                driverBehaviourRiskView.CreatedBy = driverCommendationRequest.EmployeeId;
                driverBehaviourRiskView.CreatedOn = DateTime.Now;
                driverBehaviourRiskView.ModifiedBy = null;
                driverBehaviourRiskView.ModifiedOn = null;
            }
            else
            {
                // Get driveRiskBehaviour based on driveRiskBehaviourId
                HttpResponseMessage driveRiskBehaviour = await new HttpClient().GetAsync(baseAddress + "DriverBehaviourRiskView/" + driverCommendationRequest.DriverBehaviourId);
                var driveIncidentResponse = await driveRiskBehaviour.Content.ReadFromJsonAsync<ApiResponse<DriverBehaviourRiskView>>();
                //DriverBehaviourRiskView driveIncidentResponse = await _unitOfWork.DriverBehaviourRiskViews.GetByIdAsync(driverCommendationRequest.DriverBehaviourId);

                if (driveIncidentResponse != null)
                {
                    driverBehaviourRiskView.EmpId = driveIncidentResponse.Result.EmpId;
                    driverBehaviourRiskView.EmployeeId = driveIncidentResponse.Result.EmployeeId;
                    driverBehaviourRiskView.DOT_Recordable = driveIncidentResponse.Result.DOT_Recordable;
                    driverBehaviourRiskView.DOT_Test_date = driveIncidentResponse.Result.DOT_Test_date;

                    //DFefault values for RiskIndex, IncidentValue and ViolationValue fields
                    driverBehaviourRiskView.RiskIndex = driveIncidentResponse.Result.RiskIndex;
                    driverBehaviourRiskView.RiskIndexId = driveIncidentResponse.Result.RiskIndexId;
                    driverBehaviourRiskView.IncidentValue = driveIncidentResponse.Result.IncidentValue;
                    driverBehaviourRiskView.IncidentValueId = driveIncidentResponse.Result.IncidentValueId;
                    driverBehaviourRiskView.ViolationValue = driveIncidentResponse.Result.ViolationValue;
                    driverBehaviourRiskView.ViolationValueId = driveIncidentResponse.Result.ViolationValueId;

                    driverBehaviourRiskView.CreatedBy = driveIncidentResponse.Result.CreatedBy;
                    driverBehaviourRiskView.CreatedOn = driveIncidentResponse.Result.CreatedOn;
                }
                driverBehaviourRiskView.IsActive = true;
                driverBehaviourRiskView.ModifiedBy = driverCommendationRequest.EmployeeId;
                driverBehaviourRiskView.ModifiedOn = DateTime.Now;
            }

            var data = await _unitOfWork.DriverBehaviourRiskViews.SaveAsync(driverBehaviourRiskView);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);
            
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(DriverBehaviourRiskView driverBehaviourRiskView)
        {
            var apiResponse = new ApiResponse<int>();
            if (driverBehaviourRiskView == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DriverBehaviourRiskViews.SaveAsync(driverBehaviourRiskView);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id, int LoginEmpId)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();

            ApplicationDBContext _context = new ApplicationDBContext();
            IDbContextTransaction trans = _context.Database.BeginTransaction();
            try
            {
               // using (var transactionScope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
               // {
                    var data = await _unitOfWork.DriverBehaviourRiskViews.DeleteAsync(id);
                    apiResponse.Success = true;
                    apiResponse.Result = data;
                    apiResponse.Message = CommonMessages.DeletedSuccessMessage;

                    if (apiResponse.Result == 0)
                        throw new DMSException(CommonMessages.DeleteErrorMessage);
                    else
                    {
                        // Risk calculation API call.
                        var hosData = await _unitOfWork.DriverBehaviourRiskViews.GetByIdAsync(id);

                        RisksRequest riskRequest = new RisksRequest();
                        riskRequest.DriverRiskId = 0;
                        riskRequest.DriverLicenseId = 0;
                        riskRequest.DriverId = hosData.EmployeeId;
                        riskRequest.EmplId = hosData.EmpId;
                        riskRequest.inputScope = null;
                        riskRequest.Region = null;
                        riskRequest.inputTransaction = trans;

                      //  RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);
                      //  var riskResponse = await rskController.GetBehavior(hosData.EmpId, LoginEmpId);
                        //var riskResponse = await rskController.Post(riskRequest);
                        var resulrBehav = trans.CommitAsync();

                        //if (transactionScope != null)
                        //    transactionScope.Complete();
                    }
              //  }
            }
            catch (Exception ex)
            {
                if (trans != null)
                {
                    trans.Rollback();
                }
            }
            finally
            {
                if (trans != null)
                {
                    trans.Dispose();
                }
            }
            return apiResponse;
        }

        [HttpPost("getIncidents")]
        public async Task<ApiResponse<DriversBehaviourRiskResult>> GetIncidents(DriverBehaviourRiskRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<DriversBehaviourRiskResult>();

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.DriversBehaviourRisks.GetManyAsync(request.IsCommendationType, request.EmployeeId, top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.driverBehaviourRiskResult.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        private string GetKeyValue(IConfiguration configuration, string keyName)
        {
            return configuration[keyName].ToString().ToUpper();
        }
        #endregion
    }
}