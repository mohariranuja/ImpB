﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    public class CountryController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;


        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public CountryController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;          
          
        }

        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<Country>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<Country>>();           
            var data = await _unitOfWork.Countries.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();           

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<Country>> GetById(int id)
        {
            if(id<=0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<Country>();            
            var data = await _unitOfWork.Countries.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(Country country)
        {
            var apiResponse = new ApiResponse<int>();
            if (country == null)            
                throw new DMSException(CommonMessages.InvalidModelMessage);            

            var data = await _unitOfWork.Countries.SaveAsync(country);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(Country country)
        {
            var apiResponse = new ApiResponse<int>();
            if (country == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);
            
                var data = await _unitOfWork.Countries.SaveAsync(country);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.UpdateErrorMessage);
                return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <=0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>(); 
            var data = await _unitOfWork.Countries.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getMany")]
        public async Task<ApiResponse<List<CountryList>>> Get(CountryRequest request)
        {
            var apiResponse = new ApiResponse<List<CountryList>>();

            var data = await _unitOfWork.CountryList.GetManyAsync(request);
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        //[HttpPost("getSearchData")]
        //public async Task<ApiResponse<List<Country>>> GetSearchData(CountryRequests request)
        //{
        //    var apiResponse = new ApiResponse<List<Country>>();
        //   // StringBuilder searchCriteria = new StringBuilder();
        //    Expression<Func<Country, bool>> combinedFilter = null;
        //   // Func<IQueryable<Country>, IOrderedQueryable<Country>> sortCondition = null;
        //    if (request.filterDetails != null && request.filterDetails.Count > 0)
        //    {
        //        List<Expression<Func<Country, bool>>> obList = new List<Expression<Func<Country, bool>>>();
        //        foreach (var kvp in request.filterDetails)
        //        {                    
        //            obList.Add(getFilter(kvp));
        //        }
        //        combinedFilter = FilterHelper<Country>.CombineFilters(obList);
        //    }

        //    //if (request.sortDetails != null && request.sortDetails.Count > 0)
        //    //{
                
        //    //}
        //    if (request.START_INDEX == 0)
        //    {
        //        request.START_INDEX = null;
        //        request.PAGE_SIZE = null;
        //    }
        //  //  IEnumerable<Country> data=null;
        //   // if (request.sortDetails != null && request.sortDetails.Count == 0)
        //     var data = await _unitOfWork.CountryList.GetManyAsync1(combinedFilter, null, request.START_INDEX, request.PAGE_SIZE);
        //   //else if (request.sortDetails != null && request.sortDetails.Count > 0 && request.sortDetails[0].SORT_COLUMN_DIRECTION.ToUpper() == "ASC")
        //    //else    
        //    //    data = await _unitOfWork.CountryList.GetManyAsync1(combinedFilter, orderBy: q => q.OrderBy(request.sortDetails[0].SORT_COLUMN_NAME), request.START_INDEX, request.PAGE_SIZE);
        //   // else if(request.sortDetails != null && request.sortDetails.Count > 0 && request.sortDetails[0].SORT_COLUMN_DIRECTION.ToUpper()=="DESC")
        //     //   data = await _unitOfWork.CountryList.GetManyAsync1(combinedFilter, orderBy: q => q.OrderByDescending(request.sortDetails[0].SORT_COLUMN_NAME), request.START_INDEX, request.PAGE_SIZE);


        //    apiResponse.Success = true;
        //    apiResponse.Result = data.ToList();

        //    if (apiResponse.Result.Count == 0)
        //        throw new DMSException(CommonMessages.GetErrorMessage);
        //    return apiResponse;
        //}

        [NonAction]
        public static Expression<Func<Country, bool>> getFilter(FilterDetails? objList)
        {
            ParameterExpression parameter = Expression.Parameter(typeof(Country), "e");
            MemberExpression property = Expression.Property(parameter, objList!.FilterColumnName);
            MethodCallExpression? startsWithA=null;
            if (property.Type.Name == "String")
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            else if (property.Type.Name == "Int32")
            {              

                startsWithA = Expression.Call(property, typeof(Int32).GetMethod(objList.FilterColumnOperator, [typeof(Int32)])!, Expression.Constant(Convert.ToInt32(objList.FilterColumnValue)));
            }
            else
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            Expression<Func<Country, bool>> lambdaExpression = Expression.Lambda<Func<Country, bool>>(startsWithA, parameter);
            return lambdaExpression;

        }

       /// <summary>
       /// This is generic method used for search & pagenation
       /// </summary>
       /// <param name="request"></param>
       /// <returns></returns>
       /// <exception cref="DMSException"></exception>

        [HttpPost("getCountrySearchData")]
        public async Task <ApiResponse<GenericMastersSearchResult>> GetCountrySearchData(CountryRequests request)
        {
            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<Country, bool>> filterData = getFilterData(request)!;
            int? top = null;
            int? skip = null;
            if (request.StartIndex == 0)
            {
                top = null;
                skip = null;
            }
            if (request.StartIndex == 0 && request.PageSize == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.StartIndex == 0 && request.PageSize > 0)
            {
                top = request.PageSize;
                skip = null;
            }
            else
            {
                top = request.PageSize;
                skip = (request.StartIndex - 1) * request.PageSize;
            }

            var data = await _unitOfWork.CountryList.GetManyAsync1(filterData, null, top, skip);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [NonAction]
        public Expression<Func<Country, bool>>? getFilterData(CountryRequests request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<Country, bool>>> obList = new List<Expression<Func<Country, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(getFilter(kvp));
                }

                var combinedFilter = FilterHelper<Country>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }
        #endregion
    }
}
