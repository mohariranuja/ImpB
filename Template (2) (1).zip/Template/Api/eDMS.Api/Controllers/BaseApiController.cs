using eDMS.Api.Filter;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
  //  [TypeFilter(typeof(AuthorizationFilterAttribute))]
    [ApiController]
    public class BaseApiController : ControllerBase
    {
    }
}