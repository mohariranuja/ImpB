﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    public class DriverRiskController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public DriverRiskController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;          
        }
        #endregion

        #region ===[ Public Methods ]==============================================================

        //[HttpGet("{id}")]
        //public async Task<ApiResponse<List<DriverRiskList>>> Get(int id)
        //{
        //    var apiResponse = new ApiResponse<List<DriverRiskList>>();

        //    var data = null;//await _unitOfWork.DriverRiskList.GetManyAsync(id);
        //    apiResponse.Success = true;
        //    apiResponse.Result = data.ToList();

        //    if (apiResponse.Result.Count == 0)
        //        throw new DMSException(CommonMessages.GetErrorMessage);
        //    return apiResponse;
        //}

        //[HttpPut]
        //public async Task<ApiResponse<int>> Update(DriverRisk driverRisk)
        //{
        //    var apiResponse = new ApiResponse<int>();
        //    if (driverRisk == null)
        //        throw new DMSException(CommonMessages.InvalidModelMessage);

        // //   var data = await _unitOfWork.DriverRiskList.SaveAsync(driverRisk);
        //    apiResponse.Success = true;
        // //   apiResponse.Result = data;
        //    apiResponse.Message = CommonMessages.UpdateSuccessMessage;
        //    if (apiResponse.Result == 0)
        //        throw new DMSException(CommonMessages.UpdateErrorMessage);
        //    return apiResponse;

        //}
        #endregion
        #region ===[ Public Methods ]==============================================================

        [HttpGet]
        public async Task<ApiResponse<List<DriverRisks>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<DriverRisks>>();
            var data = await _unitOfWork.DriverRisks.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetDriverRiskById{id}")]
        public async Task<ApiResponse<DriverRisks>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DriverRisks>();
            var data = await _unitOfWork.DriverRisks.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetDriverRisk")]
        public async Task<ApiResponse<DriverRisks>> GetById(int driverLicenseId, int riskTypeId)
        {            
            if (driverLicenseId <= 0 || riskTypeId <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DriverRisks>();
            var data = await _unitOfWork.DriverRisks.GetByDLRiskTypeAsync(driverLicenseId, riskTypeId);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(DriverRisks driverRisks)
        {
            var apiResponse = new ApiResponse<int>();
            if (driverRisks == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);


            var data = await _unitOfWork.DriverRisks.SaveAsync(driverRisks);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(DriverRisks driverRisks)
        {
            var apiResponse = new ApiResponse<int>();
            if (driverRisks == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DriverRisks.SaveAsync(driverRisks);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;

        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.DriverRisks.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        #endregion
    }
}