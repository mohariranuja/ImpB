﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestResultController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public TestResultController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<TestResult>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<TestResult>>();
            var data = await _unitOfWork.TestResults.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<TestResult>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<TestResult>();
            var data = await _unitOfWork.TestResults.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByTestCategory_Type/{testCategory}/{testTypeId}")]
        public async Task<ApiResponse<List<TestResult>>> GetByTestCategory(string testCategory, int testTypeId)
        {
            var apiResponse = new ApiResponse<List<TestResult>>();
            var data = await _unitOfWork.TestResults.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive == true && r.TestTypeId == testTypeId &&
            r.TestCategoryName.ToLower() == testCategory.ToLower()).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(TestResultSaveRequest testResultSaveRequest)
        {
            var apiResponse = new ApiResponse<int>();
            if (testResultSaveRequest == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            ApplicationDBContext _context = new ApplicationDBContext();
            var allTestResults = _context.TestResults;
            bool recordExists = false;
            bool fieldValueExists = false;

            if (testResultSaveRequest.TestResultId > 0)
            {
                recordExists = allTestResults.Where(r => r.TestResultName.ToLower() == testResultSaveRequest.TestResultName.ToLower()
                && r.TestCategoryId == testResultSaveRequest.TestCategoryId && r.TestTypeId == testResultSaveRequest.TestTypeId
                && r.TestResultId != testResultSaveRequest.TestResultId).Count() > 0;

                fieldValueExists = allTestResults.Where(r => r.FieldValue.ToLower() == testResultSaveRequest.FieldValue.ToLower()
                && r.TestCategoryId == testResultSaveRequest.TestCategoryId && r.TestTypeId == testResultSaveRequest.TestTypeId
                && r.TestResultId != testResultSaveRequest.TestResultId).Count() > 0;
            }
            else
            {
                recordExists = allTestResults.Where(r => r.TestResultName.ToLower() == testResultSaveRequest.TestResultName
                && r.TestCategoryId == testResultSaveRequest.TestCategoryId && r.TestTypeId == testResultSaveRequest.TestTypeId)
                    .Count() > 0;

                fieldValueExists = allTestResults.Where(r => r.FieldValue.ToLower() == testResultSaveRequest.FieldValue.ToLower()
                && r.TestCategoryId == testResultSaveRequest.TestCategoryId && r.TestTypeId == testResultSaveRequest.TestTypeId)
                    .Count() > 0;
            }

            if (recordExists || fieldValueExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;
                apiResponse.Message = (recordExists == true) ? CommonMessages.RecordExistsMessage
                        : CommonMessages.FieldValueExistsMessage;
            }
            else
            {
                var testCategory = await _unitOfWork.TestCategories.GetByIdAsync(testResultSaveRequest.TestCategoryId)
                    ?? throw new DMSException(CommonMessages.InvalidModelMessage);

                var testType = await _unitOfWork.TestTypes.GetByIdAsync(testResultSaveRequest.TestTypeId)
                    ?? throw new DMSException(CommonMessages.InvalidModelMessage);

                TestResult testResult = new TestResult()
                {
                    TestResultId = testResultSaveRequest.TestResultId,
                    TestResultName = testResultSaveRequest.TestResultName,
                    TestCategoryId = testResultSaveRequest.TestCategoryId,
                    TestCategoryName = testCategory.TestCategoryName,
                    TestTypeId = testResultSaveRequest.TestTypeId,
                    TestTypeName = testType.TestTypeName,
                    FieldValue = testResultSaveRequest.FieldValue,
                    IsActive = testResultSaveRequest.IsActive,
                    CreatedBy = testResultSaveRequest.CreatedBy
                };

                var data = await _unitOfWork.TestResults.SaveAsync(testResult);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(TestResult testResult)
        {
            var apiResponse = new ApiResponse<int>();
            if (testResult == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.TestResults.SaveAsync(testResult);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.TestResults.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getTestResultList")]
        public async Task<ApiResponse<TestResultResponseList>> getTestResultList(GridPagination gridPagination)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<TestResultResponseList>();
            if (gridPagination.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE > 0)
            {
                top = gridPagination.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = gridPagination.PAGE_SIZE;
                skip = (gridPagination.START_INDEX - 1) * gridPagination.PAGE_SIZE;
            }

            var data = await _unitOfWork.TestResults.GetAllWithPaginationAsync(top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.testResultResponseList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}