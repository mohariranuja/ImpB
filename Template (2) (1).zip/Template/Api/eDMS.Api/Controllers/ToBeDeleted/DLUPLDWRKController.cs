﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DLUPLDWRKController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public DLUPLDWRKController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<DLUPLDWRK>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<DLUPLDWRK>>();
            var data = await _unitOfWork.DLUPLDWRKs.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive == true).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<DLUPLDWRK>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DLUPLDWRK>();
            var data = await _unitOfWork.DLUPLDWRKs.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(DLUPLDWRK entity)
        {
            var apiResponse = new ApiResponse<int>();
            if (entity == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DLUPLDWRKs.SaveAsync(entity);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(DLUPLDWRK entity)
        {
            var apiResponse = new ApiResponse<int>();
            if (entity == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DLUPLDWRKs.SaveAsync(entity);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.DLUPLDWRKs.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetWrkForEmployeeAsync")]
        public async Task<ApiResponse<DLUpdWorkRisk>> GetWrkForEmployeeAsync(int empID)
        {
            var apiResponse = new ApiResponse<DLUpdWorkRisk>();

            // Driver License Object creation.
            var driverLicenese = await _unitOfWork.DriverLicenses.GetByEmployeeID(empID)
                    ?? throw new DMSException(CommonMessages.InvalidModelMessage);
            string driverType = (driverLicenese?.DriverType != null) ? driverLicenese?.DriverType : string.Empty;
            string cdlLicense = (driverLicenese?.CDL_LICENSE != null) ? driverLicenese?.CDL_LICENSE : string.Empty;
            string region = (driverLicenese?.Country != null) ? driverLicenese?.Country : string.Empty;
            
            CommonMethods common = new CommonMethods();
            string documentCategory = common.GetDocumentCategory(driverType, cdlLicense);
            string documentType = common.GetDocType(region,driverType);

            //var data = await _unitOfWork.DLUPLDWRKs.GetWrkForEmployeeAsync(empID, documentCategory, documentType);
            //data = data.ToList().Where(r => r.IsActive == true).ToList();
            //apiResponse.Success = true;
            var dataABSTR = await _unitOfWork.DLUPLDWRKs.GetWrkForEmployeeAsync(empID, documentCategory, documentType);
            var dataVOPEEVAL = await _unitOfWork.DLUPLDWRKs.GetWrkForEmployeeAsync(empID, documentCategory,
                eDMSConstant.vopeEVAL);

            if (dataABSTR == null)
            {
                dataABSTR = new DLUPLDWRK();
                dataABSTR.RiskIndex = "NA";
                dataABSTR.RiskIndexId = 9;
            }
            if (dataVOPEEVAL == null)
            {
                dataVOPEEVAL = new DLUPLDWRK();
                dataVOPEEVAL.RiskIndex = "NA";
                dataVOPEEVAL.RiskIndexId = 9;
            }
            //throw new DMSException(CommonMessages.GetErrorMessage);

            var empData = await _unitOfWork.EmployeeMasters.GetByIdAsync(empID);
            //string region = empData?.Region;

            var dlUpdWorkRisk = new DLUpdWorkRisk()
            {
                MVRiskIndex = dataABSTR.RiskIndex,
                MVRiskIndexId = dataABSTR.RiskIndexId,
                DERiskIndex = dataVOPEEVAL.RiskIndex,
                DERiskIndexId = dataVOPEEVAL.RiskIndexId
            };
            apiResponse.Success = true;
            apiResponse.Result = dlUpdWorkRisk;

            return apiResponse;
        }
        #endregion
    }
}