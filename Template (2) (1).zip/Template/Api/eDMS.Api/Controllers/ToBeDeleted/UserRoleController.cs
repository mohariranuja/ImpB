﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRoleController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;


        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize UserRoleController by injecting an object type of IUnitOfWork
        /// </summary>
        public UserRoleController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;

        }

        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet("{id}")]
        public async Task<ApiResponse<UserRoleList>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<UserRoleList>();
            var data = await _unitOfWork.UserRolesRepositories.GetMDMUserRoleByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }
        [HttpPost]
        public async Task<ApiResponse<int>> Add(MdmUserRole userRole)
        {
            var apiResponse = new ApiResponse<int>();
            if (userRole == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);


            var data = await _unitOfWork.UserRolesRepositories.SaveAsync(userRole);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        //[HttpPost("getUserRolesOld")]
        //public async Task<ApiResponse<UserRolesSearchResult>> GetUserRolesold(SearchPagingRequest request)
        //{
        //    //Role filter needs to be applied separately
        //    string[] additionalProperties = null;
        //    var result = request.filterDetails.Where(x => x.FilterColumnName == "RoleName").ToList();
        //    if(result!=null && result.Count() >0)
        //    {
        //         additionalProperties= new string[result.Count()];
        //        additionalProperties[0] = result[0].FilterColumnValue;
        //     }

        //    var apiResponse = new ApiResponse<UserRolesSearchResult>();
        //    Expression<Func<EmployeeMaster, bool>> filterData = getEmployeeMasterFilterDataOld(request)!;
        //    int? top = null;
        //    int? skip = null;
        //    if (request.START_INDEX == 0)
        //    {
        //        top = null;
        //        skip = null;
        //    }
        //    if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
        //    {
        //        top = null;
        //        skip = null;
        //    }
        //    else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
        //    {
        //        top = request.PAGE_SIZE;
        //        skip = null;
        //    }
        //    else
        //    {
        //        top = request.PAGE_SIZE;
        //        skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
        //    }

        //    var data = await _unitOfWork.UserRolesSearchResultList.GetManyAsyncOld(filterData, null, top, skip, additionalProperties);



        //    apiResponse.Result = data;
        //    apiResponse.Success = true;


        //    if (apiResponse.Result.userRoleSearchResultList.Count == 0)
        //        throw new DMSException(CommonMessages.GetErrorMessage);
        //    return apiResponse;

        //}
        [HttpPost("getUserRoles")]
        public async Task<ApiResponse<UserRolesSearchResult>> GetUserRoles(SearchPagingRequest request)
        {
            

            var apiResponse = new ApiResponse<UserRolesSearchResult>();
            Expression<Func<EmployeeMasterRole, bool>> filterData = getEmployeeMasterFilterData(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.UserRolesSearchResultList.GetManyAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.userRoleSearchResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }

        #endregion




        //[NonAction]
        //internal Expression<Func<EmployeeMaster, bool>>? getEmployeeMasterFilterDataOld(SearchPagingRequest request)
        //{
        //    if (request.filterDetails != null && request.filterDetails.Count > 0)
        //    {
        //       var result= request.filterDetails.Where(x => x.FilterColumnName == "RoleName");
        //        if(result.Count() > 0)
        //        {
        //            request.filterDetails.Remove(result.First());
        //        }
        //        List<Expression<Func<EmployeeMaster, bool>>> obList = new List<Expression<Func<EmployeeMaster, bool>>>();

        //        foreach (var kvp in request.filterDetails)
        //        {
        //            obList.Add(FilterHelper<EmployeeMaster>.getFilter(kvp));
        //        }

        //        var combinedFilter = FilterHelper<EmployeeMaster>.CombineFilters(obList);
        //        return combinedFilter;
        //    }
        //    return null;
        //}
        [NonAction]
        internal Expression<Func<EmployeeMasterRole, bool>>? getEmployeeMasterFilterData(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                
                List<Expression<Func<EmployeeMasterRole, bool>>> obList = new List<Expression<Func<EmployeeMasterRole, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<EmployeeMasterRole>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<EmployeeMasterRole>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }
    }
}
