﻿using Azure.Core;
using DocumentFormat.OpenXml.Office2016.Excel;
using eDMS.Api.Controllers.ToBeDeleted;
using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.RiskCalculations.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Linq.Expressions;
using System.Transactions;

namespace eDMS.Api.Controllers
{
    public class HoursOfServiceController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _configuration;
        Uri baseAddress;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public HoursOfServiceController(IUnitOfWork unitOfWork, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _configuration = configuration;
            baseAddress = new Uri(GetKeyValue(_configuration, "appConfigurations:baseURI"));
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<HoursOfService>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<HoursOfService>>();
            var data = await _unitOfWork.HoursOfServices.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<HoursOfService>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<HoursOfService>();
            var data = await _unitOfWork.HoursOfServices.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(HoursOfServiceSaveRequest request)
        {
            ApplicationDBContext _context = new ApplicationDBContext();
            var apiResponse = new ApiResponse<int>();
            if (request == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            // Get IncidentType based on IncidentTypeId
            var incidentTypeResponse = await _unitOfWork.IncidentTypes.GetByIdAsync(request.IncidentTypeId);

            // Get IncidentValue based on IncidentValueId
            var incidentResponse = await _unitOfWork.IncidentValues.GetByIdAsync(request.IncidentValueId);

            // Get RiskIndex based on RiskIndexId
            var riskIndexResponse = await _unitOfWork.RiskIndexes.GetByIdAsync(request.RiskIndexId);

            var hoursOfService = new HoursOfService
            {
                HoursOfServiceId = request.HoursOfServiceId,
                EmpId = request.EmpId,
                EmployeeId = request.EmployeeId,
                Date1 = request.Date1,
                DLUploadDate = request.DLUploadDate,
                MonthXLAT = request.MonthXLAT,
                YearCD = request.YearCD,
                Submitted = request.Submitted,
                GovtAudited = request.GovtAudited,
                MajorViolation = request.MajorViolation,
                RiskIndexId = request.RiskIndexId,
                RiskIndex = riskIndexResponse.RiskIndex.Substring(0, 1),
                IncidentTypeId = request.IncidentTypeId,
                IncidentType = incidentTypeResponse.IncidentType,
                IncidentValueId = request.IncidentValueId,
                IncidentValue = incidentResponse.IncidentValue,
                EDotDesc = request.EDotDesc,
                DescLongNotes = request.DescLongNotes,
                Comments = request.Comments,
            };

            var hosEmployee = _context.HoursOfServices.Where(r => r.EmployeeId == request.EmployeeId).
                OrderByDescending(r => r.SequenceNo).FirstOrDefault();
            decimal seqNo = (hosEmployee?.SequenceNo != null) ? hosEmployee.SequenceNo + 1 : 1;
            if (hoursOfService.HoursOfServiceId == 0)
            {
                // Get Employee Country
                var employeeResponse = await _unitOfWork.EmployeeMasters.GetByIdAsync(request.EmployeeId);

                // Get Country based on CountryId

                var dlResponse = await _unitOfWork.DriverLicenses.GetByEmployeeID(employeeResponse.EmpId);
                var countryResponse = await _unitOfWork.Countries.GetByIdAsync(dlResponse.CountryId);
                var regionResponse = await _unitOfWork.MdmRegions.GetByIdAsync(countryResponse.RegionId);

                hoursOfService.EmpId = request.EmpId;
                hoursOfService.EmployeeId = request.EmployeeId;
                hoursOfService.DocumentType = string.Empty;
                hoursOfService.CountryId = countryResponse.CountryId;
                hoursOfService.Country = countryResponse.CountryName;
                hoursOfService.RegionId = countryResponse.RegionId;
                hoursOfService.Region = regionResponse.RegionCode;
                hoursOfService.DocOrgName = string.Empty;
                hoursOfService.DocServerName = string.Empty;
                hoursOfService.LastUpdOprId = string.Empty;
                hoursOfService.ServerPath = string.Empty;
                hoursOfService.UploadStatus = string.Empty;
                hoursOfService.ServerRoot = string.Empty;
                hoursOfService.MinorViolation = string.Empty;
                hoursOfService.DocViewDownload = string.Empty;
                hoursOfService.DocModify = string.Empty;

                hoursOfService.SequenceNo = seqNo;
                hoursOfService.IsActive = true;
                hoursOfService.CreatedBy = request.LoginUserId;
                hoursOfService.CreatedOn = DateTime.Now;
                hoursOfService.ModifiedBy = null;
                hoursOfService.ModifiedOn = null;
            }
            else
            {
                HttpResponseMessage hosJsonResponse = await new HttpClient().GetAsync(baseAddress + "HoursOfService/" + request.HoursOfServiceId);
                var hosResponse = await hosJsonResponse.Content.ReadFromJsonAsync<ApiResponse<HoursOfService>>();
                if (hosResponse != null)
                {
                    hoursOfService.EmpId = hosResponse.Result.EmpId;
                    hoursOfService.EmployeeId = hosResponse.Result.EmployeeId;
                    hoursOfService.DocumentType = hosResponse.Result.DocumentType;
                    hoursOfService.CountryId = hosResponse.Result.CountryId;
                    hoursOfService.Country = hosResponse.Result.Country;
                    hoursOfService.RegionId = hosResponse.Result.RegionId;
                    hoursOfService.Region = hosResponse.Result.Region;
                    hoursOfService.SequenceNo = hosResponse.Result.SequenceNo;
                    hoursOfService.DocOrgName = hosResponse.Result.DocOrgName;
                    hoursOfService.DocServerName = hosResponse.Result.DocServerName;
                    hoursOfService.LastUpdOprId = hosResponse.Result.LastUpdOprId;
                    hoursOfService.ServerPath = hosResponse.Result.ServerPath;
                    hoursOfService.UploadStatus = hosResponse.Result.UploadStatus;
                    hoursOfService.ServerRoot = hosResponse.Result.ServerRoot;
                    hoursOfService.MinorViolation = hosResponse.Result.MinorViolation;
                    hoursOfService.DocViewDownload = hosResponse.Result.DocViewDownload;
                    hoursOfService.DocModify = hosResponse.Result.DocModify;

                    hoursOfService.EmpId = hosResponse.Result.EmpId;
                    hoursOfService.EmployeeId = hosResponse.Result.EmployeeId;
                    hoursOfService.DocumentType = hosResponse.Result.DocumentType;
                    hoursOfService.CountryId = hosResponse.Result.CountryId;
                    hoursOfService.Country = hosResponse.Result.Country;
                    hoursOfService.RegionId = hosResponse.Result.RegionId;
                    hoursOfService.Region = hosResponse.Result.Region;

                    hoursOfService.DocOrgName = hosResponse.Result.DocOrgName;
                    hoursOfService.DocServerName = hosResponse.Result.DocServerName;
                    hoursOfService.LastUpdOprId = hosResponse.Result.LastUpdOprId;
                    hoursOfService.ServerPath = hosResponse.Result.ServerPath;
                    hoursOfService.UploadStatus = hosResponse.Result.UploadStatus;
                    hoursOfService.ServerRoot = hosResponse.Result.ServerRoot;
                    hoursOfService.MinorViolation = hosResponse.Result.MinorViolation;
                    hoursOfService.DocViewDownload = hosResponse.Result.DocViewDownload;
                    hoursOfService.DocModify = hosResponse.Result.DocModify;
                    hoursOfService.LastUpdDtTm = hosResponse.Result.LastUpdDtTm;

                    hoursOfService.IsActive = hosResponse.Result.IsActive;
                    hoursOfService.CreatedBy = hosResponse.Result.EmployeeId;
                    hoursOfService.CreatedOn = hosResponse.Result.CreatedOn;
                    hoursOfService.ModifiedBy = (request.LoginUserId == 0) ? -1 : request.LoginUserId;
                    hoursOfService.ModifiedOn = DateTime.Now;
                }
            }
            IDbContextTransaction trans = _context.Database.BeginTransaction();
            try
            {
                // using (var transactionScope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                // {
                var data = await _unitOfWork.HoursOfServices.SaveAsync(hoursOfService);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
                else
                {
                    // Risk calculation API call.
                    //RisksRequest riskRequest = new RisksRequest();
                    //riskRequest.DriverRiskId = 0;
                    //riskRequest.DriverLicenseId = 0;
                    //riskRequest.DriverId = hoursOfService.EmployeeId;
                    //riskRequest.EmplId = hoursOfService.EmpId;
                    //riskRequest.inputScope = null;//transactionScope;
                    //riskRequest.Region = null;//8USAR";
                    //riskRequest.inputTransaction = trans;

                    //RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);
                    //var riskResponse = await rskController.Post(riskRequest);
                    RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);
                    var riskResponse = await rskController.GetHos(hoursOfService.EmpId, request.LoginUserId);
                    var resulrBehav = trans.CommitAsync();
                    //  if (transactionScope != null && riskRequest.inputScope == null)
                    //     transactionScope.Complete();
                }
            }
            catch (Exception ex)
            {
                if (trans != null)
                {
                    trans.Rollback();
                }
            }
            finally
            {
                if (trans != null)
                {
                    trans.Dispose();
                }
            }
            //}
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(HoursOfService request)
        {
            var apiResponse = new ApiResponse<int>();
            if (request == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.HoursOfServices.SaveAsync(request);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id, int LoginUserId)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            ApplicationDBContext _context = new ApplicationDBContext();
            IDbContextTransaction trans = _context.Database.BeginTransaction();
            try
            {
               // using (var transactionScope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
               // {
                    var data = await _unitOfWork.HoursOfServices.DeleteAsync(id);
                    apiResponse.Success = true;
                    apiResponse.Result = data;
                    apiResponse.Message = CommonMessages.DeletedSuccessMessage;

                    if (apiResponse.Result == 0)
                        throw new DMSException(CommonMessages.DeleteErrorMessage);
                    else
                    {
                        // Risk calculation API call.
                        var hosData = await _unitOfWork.HoursOfServices.GetByIdAsync(id);

                        RisksRequest riskRequest = new RisksRequest();
                        riskRequest.DriverRiskId = 0;
                        riskRequest.DriverLicenseId = 0;
                        riskRequest.DriverId = hosData.EmployeeId;
                        riskRequest.EmplId = hosData.EmpId;
                        riskRequest.inputScope = null;
                        riskRequest.Region = null;
                        riskRequest.inputTransaction = trans;

                        RiskCalculationsController rskController = new RiskCalculationsController(_unitOfWork);
                        var riskResponse = await rskController.GetHos(hosData.EmpId, LoginUserId);
                        var resulrBehav = trans.CommitAsync();

                        //if (transactionScope != null)
                        //    transactionScope.Complete();
                    }
              //  }
            }
            catch (Exception ex)
            {
                if (trans != null)
                {
                    trans.Rollback();
                }
            }
            finally
            {
                if (trans != null)
                {
                    trans.Dispose();
                }
            }
            return apiResponse;
        }


        #endregion

        [HttpPost("getMany")]
        public async Task<ApiResponse<HoursOfServiceGetManyResponse>> Get(HoursOfServiceGetManyRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<HoursOfServiceGetManyResponse>();

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.HoursOfServices.GetManyAsync(request.EmployeeId, top, skip);

            data.HoursOfServices.ForEach(x => { if (x.RiskIndex == "V") { x.RiskIndex = "Very Low"; } });
            data.HoursOfServices.ForEach(x => { if (x.RiskIndex == "L") { x.RiskIndex = "Low"; } });
            data.HoursOfServices.ForEach(x => { if (x.RiskIndex == "M") { x.RiskIndex = "Medium"; } });
            data.HoursOfServices.ForEach(x => { if (x.RiskIndex == "H") { x.RiskIndex = "High"; } });
            
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.HoursOfServices.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [NonAction]
        public static Expression<Func<Country, bool>> getFilter(FilterDetails? objList)
        {
            ParameterExpression parameter = Expression.Parameter(typeof(Country), "e");
            MemberExpression property = Expression.Property(parameter, objList!.FilterColumnName);
            MethodCallExpression? startsWithA = null;
            if (property.Type.Name == "String")
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            else if (property.Type.Name == "Int32")
            {

                startsWithA = Expression.Call(property, typeof(Int32).GetMethod(objList.FilterColumnOperator, [typeof(Int32)])!, Expression.Constant(Convert.ToInt32(objList.FilterColumnValue)));
            }
            else
                startsWithA = Expression.Call(property, typeof(string).GetMethod(objList.FilterColumnOperator, [typeof(string)])!, Expression.Constant(objList.FilterColumnValue));
            Expression<Func<Country, bool>> lambdaExpression = Expression.Lambda<Func<Country, bool>>(startsWithA, parameter);
            return lambdaExpression;
        }

        private string GetKeyValue(IConfiguration configuration, string keyName)
        {
            return configuration[keyName].ToString().ToUpper();
        }
    }
}
