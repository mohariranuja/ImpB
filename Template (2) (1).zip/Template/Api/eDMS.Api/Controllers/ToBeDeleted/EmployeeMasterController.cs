﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Dto.UserProfile;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Extension;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeMasterController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public EmployeeMasterController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<EmployeeMaster>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<EmployeeMaster>>();
            var data = await _unitOfWork.EmployeeMasters.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost("GetAllApprovals")]
        public async Task<ApiResponse<ApprovalResultList>> GetAllApprovals(ApprovalRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<ApprovalResultList>();
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }
            
            var data = await _unitOfWork.EmployeeMasters.GetAllUserPendingRequestsAsync(request.id, top, skip);            
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result.approvalResult.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
   
        [HttpGet("{id}")]
        public async Task<ApiResponse<EmployeeMaster>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<EmployeeMaster>();
            var data = await _unitOfWork.EmployeeMasters.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetEmployeeByID/{id}")]
        public async Task<ApiResponse<EmployeeData>> GetByIdWithDriverTypeDesc(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<EmployeeData>();
            var data = await _unitOfWork.EmployeeMasters.GetByIdWithDriverTypeDescAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetByCode/{code}")]
        public async Task<ApiResponse<EmployeeMaster>> GetByCode(string code)
        {
            if (code.IsNullOrEmpty())
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<EmployeeMaster>();
            var data = await _unitOfWork.EmployeeMasters.GetByCodeAsync(code);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetEmpDriverTypeById/{id}")]
        public async Task<string> GetEmpDriverTypeById(int id)
        {
            string returnValue = string.Empty;
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
           // EmployeeMasterWithDriverType employeeMasterWithDriverType = new EmployeeMasterWithDriverType();

           // var apiResponse = new ApiResponse<EmployeeMasterWithDriverType>();
          //  var data = await _unitOfWork.EmployeeMasters.GetByIdAsync(id);
          //  if (data != null)
          //  {
                //employeeMasterWithDriverType =GetEmployeeMasterWithDriverType(data);
                var driverlicense= await _unitOfWork.DriverLicenses.GetByEmployeeID(id);
                if(driverlicense!=null && driverlicense.DriverTypeId.HasValue)
                {
                    int drivertyid = (int)driverlicense.DriverTypeId;

                      var driverTypeDetails=  await _unitOfWork.DriverTypes.GetByIdAsync(drivertyid);
                    if (driverTypeDetails != null)
                    {
                        //employeeMasterWithDriverType.DriverTypeId= drivertyid;
                        returnValue = driverTypeDetails.DriverTypeDescription;
                    }
                }
           // }
           

            return returnValue;
        }

        private EmployeeMasterWithDriverType GetEmployeeMasterWithDriverType(EmployeeMaster data)
        {
            EmployeeMasterWithDriverType employeeMasterWithDriverType = new EmployeeMasterWithDriverType();
            employeeMasterWithDriverType.EmpId = data.EmpId;
            employeeMasterWithDriverType.EmplId=data.EmplId;
            employeeMasterWithDriverType.EmailId = data.EmailId;
            employeeMasterWithDriverType.EmpStatus = data.EmpStatus;
            employeeMasterWithDriverType.EmpType= data.EmpType;
            employeeMasterWithDriverType.Action = data.Action;
            employeeMasterWithDriverType.ActionReason = data.ActionReason;
            employeeMasterWithDriverType.IsHRActive = data.IsHRActive;
            employeeMasterWithDriverType.IsQualifiedDriver = data.IsQualifiedDriver;
            employeeMasterWithDriverType.HRName = data.HRName;
            employeeMasterWithDriverType.JobCode = data.JobCode;
            employeeMasterWithDriverType.JobCodeDescription = data.JobCodeDescription;
            employeeMasterWithDriverType.BusinessUnit = data.BusinessUnit;
            employeeMasterWithDriverType.BusinessUnitDescription  = data.BusinessUnitDescription;
            employeeMasterWithDriverType.CountryOfBirth = data.CountryOfBirth;
            employeeMasterWithDriverType.Country = data.Country;
            employeeMasterWithDriverType.CountryId = data.CountryId;
            employeeMasterWithDriverType.CommercialDriverLicense = data.CommercialDriverLicense;
            employeeMasterWithDriverType.CompanySanctionedDriver = data.CompanySanctionedDriver;
            employeeMasterWithDriverType.CostCenter = data.CostCenter;
            employeeMasterWithDriverType.CreatedBy = data.CreatedBy;
            employeeMasterWithDriverType.CreatedOn = data.CreatedOn;
            employeeMasterWithDriverType.DateOfBirth = data.DateOfBirth;
            employeeMasterWithDriverType.HireDate = data.HireDate;
            employeeMasterWithDriverType.TerminationDate = data.TerminationDate;
            employeeMasterWithDriverType.State = data.State;
            employeeMasterWithDriverType.AlternateName = data.AlternateName;
            employeeMasterWithDriverType.Devision = data.Devision;
            employeeMasterWithDriverType.DevisionDescription = data.DevisionDescription;
            employeeMasterWithDriverType.DepartmentId = data.DepartmentId;
            employeeMasterWithDriverType.DepartmentDescription = data.DepartmentDescription;
            employeeMasterWithDriverType.PositionDescription = data.PositionDescription;
            employeeMasterWithDriverType.PositionId = data.PositionId;
            employeeMasterWithDriverType.ModifiedOn = data.ModifiedOn;
            employeeMasterWithDriverType.ModifiedBy = data.ModifiedBy;
            employeeMasterWithDriverType.Region = data.Region;
            employeeMasterWithDriverType.ReportsTo = data.ReportsTo;
            employeeMasterWithDriverType.Sex = data.Sex;
            employeeMasterWithDriverType.DriverType = data.DriverType;
            employeeMasterWithDriverType.FullTimePartTime = data.FullTimePartTime;
            //employeeMasterWithDriverType.Country = data.Country;
            //employeeMasterWithDriverType.Country = data.Country;
            //employeeMasterWithDriverType.Country = data.Country;
            return employeeMasterWithDriverType;

        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(EmployeeMaster employeeMaster)
        {
            var apiResponse = new ApiResponse<int>();
            if (employeeMaster == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.EmployeeMasters.SaveAsync(employeeMaster);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(EmployeeMaster employeeMaster)
        {
            var apiResponse = new ApiResponse<int>();
            if (employeeMaster == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.EmployeeMasters.SaveAsync(employeeMaster);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.EmployeeMasters.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }
        
        [HttpPost("getTeamsByManagerCode")]
        public async Task<ApiResponse<EmployeesMasterTeamsResult>> GetTeamsByManagerCode(EmployeeMasterTeamsRequest employeeMasterTeamsRequest)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<EmployeesMasterTeamsResult>();
            //Expression<Func<EmployeeMaster, bool>> filterData = getIncidentFilterData(employeeMasterTeamsRequest)!;
            if (employeeMasterTeamsRequest.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (employeeMasterTeamsRequest.START_INDEX == 0 && employeeMasterTeamsRequest.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (employeeMasterTeamsRequest.START_INDEX == 0 && employeeMasterTeamsRequest.PAGE_SIZE > 0)
            {
                top = employeeMasterTeamsRequest.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = employeeMasterTeamsRequest.PAGE_SIZE;
                skip = (employeeMasterTeamsRequest.START_INDEX - 1) * employeeMasterTeamsRequest.PAGE_SIZE;
            }

            var data = await _unitOfWork.EmployeesMasterTeams.GetManyAsync(null, employeeMasterTeamsRequest.ManagerCode, top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.employeesMasterTeamsResults.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        //get employee by email id
        [HttpGet("getEmployeeByEmail/{email}")]
        public async Task<ApiResponse<EmployeeMaster?>> GetEmployeeByEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var data = await _unitOfWork.EmployeeMasters.GetEmployeeByEmailAsync(email);

            return data == null
                ? throw new DMSException(CommonMessages.GetErrorMessage)
                : new ApiResponse<EmployeeMaster?>
                {
                    Success = true,
                    Result = data
                };
        }

        //get employee by email id
        [HttpGet("getEmployeeByEmail/{email}/userprofile")]
        public async Task<ApiResponse<UserProfileDto?>> GetEmployeeUserProfileByEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var employee = await _unitOfWork.EmployeeMasters.GetEmployeeByEmailAsync(email)
                ?? throw new DMSException(CommonMessages.GetErrorMessage);

            //get user roles
            var userRole = await _unitOfWork.MdmUserRoles.GetMdmUserRoleByUserIdAsync(employee.EmpId);

            string? roleName = null;

            if (userRole != null)
            {
                var role = await _unitOfWork.MdmRoles.GetMdmRoleByIdAsync(userRole.RoleId);
                roleName = role?.RoleName;
            }

            return new ApiResponse<UserProfileDto?>
            {
                Success = true,
                Result = new UserProfileDto
                {
                    EmpId = employee.EmpId,
                    EmplId = employee.EmplId,
                    PreferredLanguage = employee.PreferredLanguage,
                    DisplayName = employee.DisplayName,
                    Role = roleName,
                    FirstName = employee.FirstName,
                    LastName = employee.LastName,
                    Country = employee.Country,
                    IsRegionManager = userRole.IsRegionManager
                }
            };
        }

        [HttpPost("getAllApprovers")]
        public async Task<ApiResponse<ManagersSearchResult>> GetAll(ManagerSearchRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<ManagersSearchResult>();
            Expression<Func<EmployeeMaster, bool>> filterData = getFilterData(request)!;

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.ManagersSearchResultList.GetManyApproversAsync(filterData, top, skip);

            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.managerSearchResult.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [NonAction]
        internal Expression<Func<EmployeeMaster, bool>>? getFilterData(ManagerSearchRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<EmployeeMaster, bool>>> obList = new List<Expression<Func<EmployeeMaster, bool>>>();
                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<EmployeeMaster>.getFilter(kvp));
                }
                var combinedFilter = FilterHelper<EmployeeMaster>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        //[NonAction]
        //internal Expression<Func<ApprovalResult, bool>>? getApprovalFilterData(ApprovalRequest request)
        //{
        //    if (request.filterDetails != null && request.filterDetails.Count > 0)
        //    {
        //        List<Expression<Func<ApprovalResult, bool>>> obList = new List<Expression<Func<ApprovalResult, bool>>>();
        //        foreach (var kvp in request.filterDetails)
        //        {
        //            obList.Add(FilterHelper<ApprovalResult>.getFilter(kvp));
        //        }
        //        var combinedFilter = FilterHelper<ApprovalResult>.CombineFilters(obList);
        //        return combinedFilter;
        //    }
        //    return null;
        //}

        //[NonAction]
        //internal Expression<Func<EmployeeMaster, bool>>? getIncidentFilterData(EmployeeMasterTeamsRequest employeeMasterTeamsRequest)
        //{
        //    if (employeeMasterTeamsRequest.filterDetails != null && employeeMasterTeamsRequest.filterDetails.Count > 0)
        //    {
        //        List<Expression<Func<EmployeeMaster, bool>>> obList = new List<Expression<Func<EmployeeMaster, bool>>>();
        //        foreach (var kvp in employeeMasterTeamsRequest.filterDetails)
        //        {
        //            obList.Add(FilterHelper<EmployeeMaster>.getFilter(kvp));
        //        }
        //        var combinedFilter = FilterHelper<EmployeeMaster>.CombineFilters(obList);
        //        return combinedFilter;
        //    }
        //    return null;
        //}

        [HttpPost("getEmployees")]
        public async Task<ApiResponse<ManagersSearchResult>> getEmployees(ManagerSearchRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<ManagersSearchResult>();
            Expression<Func<EmployeeMaster, bool>> filterData = getFilterData(request)!;

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.EmployeeMasters.GetEmployeeSearchList(filterData, null, null, null);
            data.managerSearchResult = data.managerSearchResult.GroupBy(x => x.EmplId).Select(g => g.First()).ToList();
            data.TotalCount = data.managerSearchResult.Count;
            List<ManagerSearchResult> distinctRows = null;
            if (request.filterDetails.Count > 0)
            {
                if (request.filterDetails[0].FilterColumnName == "EmplId")
                {
                    distinctRows = data.managerSearchResult.GroupBy(x => x.EmplId).Select(g => g.First()).ToList();
                }
                if (request.filterDetails[0].FilterColumnName == "FirstName")
                {
                    if (distinctRows == null)
                        distinctRows = data.managerSearchResult.GroupBy(x => x.FirstName).Select(g => g.First()).ToList();
                    else
                        distinctRows = distinctRows.GroupBy(x => x.LastName).Select(g => g.First()).ToList();
                }
                data.TotalCount = distinctRows.Count;
            }
            else
            {
                if (top > 0 && skip > 0)
                {
                    data.managerSearchResult = data.managerSearchResult.Skip(skip.GetValueOrDefault()).Take(top.GetValueOrDefault()).ToList();
                }
                else if (top > 0 && (skip == 0 || skip == null))
                {
                    data.managerSearchResult = data.managerSearchResult.Take(top.GetValueOrDefault()).ToList();
                }
            }
            if (distinctRows != null && distinctRows.Count > 0)
            {
                if (top > 0 && skip > 0)
                {
                    distinctRows = distinctRows.Skip(skip.GetValueOrDefault()).Take(top.GetValueOrDefault()).ToList();
                }
                else if (top > 0 && (skip == 0 || skip == null))
                {
                    distinctRows = distinctRows.Take(top.GetValueOrDefault()).ToList();
                }
            }
            if (distinctRows != null)
                data.managerSearchResult = distinctRows;
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.managerSearchResult.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}