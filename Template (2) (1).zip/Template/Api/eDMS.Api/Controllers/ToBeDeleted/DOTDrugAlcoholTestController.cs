﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DOTDrugAlcoholTestController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _configuration;
        Uri baseAddress;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public DOTDrugAlcoholTestController(IUnitOfWork unitOfWork, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _configuration = configuration;
            baseAddress = new Uri(GetKeyValue(_configuration, "appConfigurations:baseURI"));//new Uri(eDMSConstant.baseURI);
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<DOTDrug_AlcoholTest>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<DOTDrug_AlcoholTest>>();
            var data = await _unitOfWork.DOTDrugAlcoholTests.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<DOTDrug_AlcoholTest>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DOTDrug_AlcoholTest>();
            var data = await _unitOfWork.DOTDrugAlcoholTests.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("DrugTestById{id}")]
        public async Task<ApiResponse<DrugAlcoholTestResponse>> DrugTestById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DrugAlcoholTestResponse>();
            var data = await _unitOfWork.DOTDrugAlcoholTests.GetByIdAsync(id);
            
            if (data == null)
                throw new DMSException(CommonMessages.GetErrorMessage);
            else
            {
                List<DOTDrug_AlcoholTest> drugTest = new List<DOTDrug_AlcoholTest>();
                drugTest.Add(data);
                var testType = await _unitOfWork.TestTypes.GetAllAsync();
                testType = testType.ToList().Where(w => w.FieldValue == data.ExamType).ToList();

                var sampleType = await _unitOfWork.SampleTypes.GetAllAsync();
                sampleType = sampleType.ToList().Where(w => w.FieldValue == data.SampleType).ToList();

                var disposition = await _unitOfWork.Dispositions.GetAllAsync();
                disposition = disposition.ToList().Where(w => w.FieldValue == data.Disposition).ToList();

                var testResult = await _unitOfWork.TestResults.GetAllAsync();
                testResult = testResult.ToList().Where(w => w.FieldValue == data.TestResultDrug).ToList();

                var response = (from dt in drugTest
                                join tt in testType on dt.ExamType.ToLower() equals tt.FieldValue.ToLower()
                                join st in sampleType on dt.SampleType.ToLower() equals st.FieldValue.ToLower()
                                join d in disposition on dt.Disposition.ToLower() equals d.FieldValue.ToLower()
                                join tr in testResult on dt.TestResultDrug.ToLower() equals tr.FieldValue.ToLower()
                                select new
                                {
                                    DOTDrug_AlcoholTestId = dt.DOTDrug_AlcoholTestId,
                                    EmployeeId = dt.EmployeeId,
                                    EmpId = dt.EmpId,
                                    TestDate = dt.ExamDate,
                                    TestCategory = dt.ExamCategory,
                                    TestType = dt.ExamType,
                                    TestTypeName = tt.TestTypeName,
                                    Agency = dt.Agency,
                                    SampleType = dt.SampleType,
                                    SampleTypeName = st.SampleTypeName,
                                    TestNumber = dt.TestNumber,
                                    PhysicianName = dt.PhysicianName,
                                    TestResult = dt.TestResultDrug,
                                    TestResultName = tr.TestResultName,
                                    Disposition = dt.Disposition,
                                    DispositionName = d.DispositionName,
                                    Description = dt.Description,
                                    Amphetamine = dt.Amphetamine,
                                    Cocaine = dt.Cocaine,
                                    Marijuana = dt.Marijuana,
                                    Opiates = dt.Opiates,
                                    Phencyclidine = dt.Phencyclidine,
                                    Other = dt.Other
                                }).FirstOrDefault();

                var drugResponse = new DrugAlcoholTestResponse();
                drugResponse.DOTDrug_AlcoholTestId = response.DOTDrug_AlcoholTestId;
                drugResponse.EmployeeId = response.EmployeeId;
                drugResponse.EmpId = response.EmpId;
                drugResponse.TestDate = response.TestDate;
                drugResponse.TestCategory = response.TestCategory;
                drugResponse.TestType = response.TestType;
                drugResponse.TestTypeName = response.TestTypeName;
                drugResponse.Agency = response.Agency;
                drugResponse.SampleType = response.SampleType;
                drugResponse.SampleTypeName = response.SampleTypeName;
                drugResponse.TestNumber = response.TestNumber;
                drugResponse.PhysicianName = response.PhysicianName;
                drugResponse.TestResult = response.TestResult;
                drugResponse.TestResultName = response.TestResultName;
                drugResponse.Disposition = response.Disposition;
                drugResponse.DispositionName = response.DispositionName;
                drugResponse.Description = response.Description;
                drugResponse.Amphetamine = response.Amphetamine;
                drugResponse.Cocaine = response.Cocaine;
                drugResponse.Marijuana = response.Marijuana;
                drugResponse.Opiates = response.Opiates;
                drugResponse.Phencyclidine = response.Phencyclidine;
                drugResponse.Other = response.Other;
                apiResponse.Result = drugResponse;

                apiResponse.Success = true;
                apiResponse.Result = drugResponse;
                return apiResponse;
            }
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(DrugAlcoholTestRequest drugAlcoholTestRequest)
        {
            HttpResponseMessage drugTestRequest = null;
            ApiResponse<DriverBehaviourRiskView>? commendationResponse = null;

            //if (drugAlcoholTestRequest.DOTDrug_AlcoholTestId > 0)
            //{
            //     drugTestRequest = await new HttpClient().GetAsync(baseAddress +
            //        "DriverBehaviourRiskView/" + drugAlcoholTestRequest.DOTDrug_AlcoholTestId);
            //    commendationResponse = await drugTestRequest.Content.ReadFromJsonAsync<ApiResponse<DriverBehaviourRiskView>>();
            //}                

            var apiResponse = new ApiResponse<int>();
            if (drugAlcoholTestRequest == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            //DriverBehaviourRiskView driveIncidentResponse = await _unitOfWork.DriverBehaviourRiskViews.GetByIdAsync(driverCommendationRequest.DriverBehaviourId);
            ApplicationDBContext _context = new ApplicationDBContext();
            var allEmpDOTs = _context.DOTDrug_AlcoholTest.Where(r => r.EmployeeId == drugAlcoholTestRequest.EmployeeId);
            bool recordExists = false;
            if (drugAlcoholTestRequest.DOTDrug_AlcoholTestId > 0)
                recordExists = allEmpDOTs.Where(r => r.ExamCategory.ToLower() == drugAlcoholTestRequest.ExamCategory.ToLower()
                && r.ExamDate == drugAlcoholTestRequest.ExamDate
                && r.DOTDrug_AlcoholTestId != drugAlcoholTestRequest.DOTDrug_AlcoholTestId).Count() > 0;
            else
                recordExists = allEmpDOTs.Where(r => r.ExamCategory.ToLower() == drugAlcoholTestRequest.ExamCategory.ToLower()
             && r.ExamDate == drugAlcoholTestRequest.ExamDate).Count() > 0;

            if (recordExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;
                apiResponse.Message = CommonMessages.RecordExistsMessage;
            }
            else
            {
                var dotDrugAlcoholTest = new DOTDrug_AlcoholTest
                {
                    DOTDrug_AlcoholTestId = drugAlcoholTestRequest.DOTDrug_AlcoholTestId,
                    EmployeeId = drugAlcoholTestRequest.EmployeeId,
                    EmpId = drugAlcoholTestRequest.EmpId,
                    TestCategoryId = drugAlcoholTestRequest.TestCategoryId,
                    ExamCategory = drugAlcoholTestRequest.ExamCategory,
                    ExamDate = drugAlcoholTestRequest.ExamDate,
                    ExamType = drugAlcoholTestRequest.ExamType,
                    Agency = drugAlcoholTestRequest.Agency,
                    SampleType = drugAlcoholTestRequest.SampleType,
                    PhysicianId = drugAlcoholTestRequest.PhysicianId,
                    PhysicianName = drugAlcoholTestRequest.PhysicianName,
                    TestResultDrug = drugAlcoholTestRequest.TestResultDrug,
                    TestNumber = drugAlcoholTestRequest.TestNumber,
                    Description = drugAlcoholTestRequest.Description,
                    Disposition = drugAlcoholTestRequest.Disposition,
                    Amphetamine = drugAlcoholTestRequest.Amphetamine,
                    Cocaine = drugAlcoholTestRequest.Cocaine,
                    Marijuana = drugAlcoholTestRequest.Marijuana,
                    Opiates = drugAlcoholTestRequest.Opiates,
                    Phencyclidine = drugAlcoholTestRequest.Phencyclidine,
                    Other = drugAlcoholTestRequest.Other,
                    Comments = drugAlcoholTestRequest.Comments,
                    IsActive = true
                };

                if (drugAlcoholTestRequest.DOTDrug_AlcoholTestId == 0)
                {
                    dotDrugAlcoholTest.CreatedBy = drugAlcoholTestRequest.EmployeeId;
                    dotDrugAlcoholTest.CreatedOn = DateTime.Now;
                    dotDrugAlcoholTest.ModifiedBy = null;
                    dotDrugAlcoholTest.ModifiedOn = null;
                }
                else
                {
                    HttpResponseMessage drugTestRequestById = await new HttpClient().GetAsync(baseAddress + "DOTDrugAlcoholTest/" + drugAlcoholTestRequest.DOTDrug_AlcoholTestId);
                    var drugTestResponseById = await drugTestRequestById.Content.ReadFromJsonAsync<ApiResponse<DriverBehaviourRiskView>>();
                    if (drugTestRequestById != null)
                    {
                        dotDrugAlcoholTest.CreatedBy = drugTestResponseById.Result.EmployeeId;
                        dotDrugAlcoholTest.CreatedOn = drugTestResponseById.Result.CreatedOn;
                        dotDrugAlcoholTest.ModifiedBy = drugAlcoholTestRequest.EmployeeId;
                        dotDrugAlcoholTest.ModifiedOn = DateTime.Now;
                    }
                }

                var data = await _unitOfWork.DOTDrugAlcoholTests.SaveAsync(dotDrugAlcoholTest);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(DOTDrug_AlcoholTest DOTDrugAlcoholTest)
        {
            var apiResponse = new ApiResponse<int>();
            if (DOTDrugAlcoholTest == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DOTDrugAlcoholTests.SaveAsync(DOTDrugAlcoholTest);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.DOTDrugAlcoholTests.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getDrugAlcoholTestResults")]
        public async Task<ApiResponse<DrugTestGetResponse>> getDrugAlcoholTestResults(DrugTestGetRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<DrugTestGetResponse>();

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.DOTDrugAlcoholTests.GetManyAsync(request.EmployeeId, top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.DrugAlcoholTest.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion

        private string GetKeyValue(IConfiguration configuration, string keyName)
        {
            return configuration[keyName].ToString().ToUpper();
        }
    }
}