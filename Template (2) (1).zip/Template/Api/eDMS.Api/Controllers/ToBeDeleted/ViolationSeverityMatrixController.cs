﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ViolationSeverityMatrixController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize ViolationSeverityMatrixController by injecting an object type of IUnitOfWork
        /// </summary>
        public ViolationSeverityMatrixController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpGet]
        public async Task<ApiResponse<List<MDMViolationSeverityMatrix>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<MDMViolationSeverityMatrix>>();
            var data = await _unitOfWork.ViolationSeverityMatrix.GetAllAsync();
            data = data.Where(x => x.IsActiveViolationSeverityMatrix == true).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetById/{id}")]
        public async Task<ApiResponse<MDMViolationSeverityMatrix>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<MDMViolationSeverityMatrix>();
            var data = await _unitOfWork.ViolationSeverityMatrix.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByDescription/{desc}")]
        public async Task<ApiResponse<MDMViolationSeverityMatrix>> GetByType(string desc)
        {
            if (string.IsNullOrEmpty(desc))
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<MDMViolationSeverityMatrix>();
            var data = await _unitOfWork.ViolationSeverityMatrix.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = desc == eDMSConstant.defaultIncidentValue ? data.Where(w => w.ViolationDescription == desc).FirstOrDefault()
                : data.Where(w => w.ViolationDescription == desc && w.IsActiveViolationSeverityMatrix == true).FirstOrDefault();

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost("getViolationValue")]
        public async Task<ApiResponse<ViolationValuesSearchResponce>> GetIncident(ViolationValueSearchRequest violationValueSearchRequest)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<ViolationValuesSearchResponce>();
            Expression<Func<MDMViolationSeverityMatrix, bool>> filterData = getViolationFilterData(violationValueSearchRequest)!;
            if (violationValueSearchRequest.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (violationValueSearchRequest.START_INDEX == 0 && violationValueSearchRequest.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (violationValueSearchRequest.START_INDEX == 0 && violationValueSearchRequest.PAGE_SIZE > 0)
            {
                top = violationValueSearchRequest.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = violationValueSearchRequest.PAGE_SIZE;
                skip = (violationValueSearchRequest.START_INDEX - 1) * violationValueSearchRequest.PAGE_SIZE;
            }
            
            var data = await _unitOfWork.ViolationSearchList.GetManyAsync(filterData, null, 
                violationValueSearchRequest.IncidentValue, top, skip);

            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.violationValueSearchResponceList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        
        [NonAction]
        internal Expression<Func<MDMViolationSeverityMatrix, bool>>? getViolationFilterData(ViolationValueSearchRequest violationValueSearchRequest)
        {
            if (violationValueSearchRequest.filterDetails != null && violationValueSearchRequest.filterDetails.Count > 0)
            {
                List<Expression<Func<MDMViolationSeverityMatrix, bool>>> obList = new List<Expression<Func<MDMViolationSeverityMatrix, bool>>>();
                foreach (var kvp in violationValueSearchRequest.filterDetails)
                {
                    obList.Add(FilterHelper<MDMViolationSeverityMatrix>.getFilter(kvp));
                }
                var combinedFilter = FilterHelper<MDMViolationSeverityMatrix>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(ViolationSeverityMatrixRequest violationSeverityMatrix)
        {
            var apiResponse = new ApiResponse<int>();
            if (violationSeverityMatrix == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var violationSeverity = await _unitOfWork.ViolationSeverityMatrix.GetAllAsync();
            bool recordExists = false;

            if (violationSeverityMatrix.ViolationSeverityMatrixId > 0)
            {
                recordExists = violationSeverity.Where(r => r.IncidentValue == violationSeverityMatrix.IncidentValue
                && r.ViolationValue == violationSeverityMatrix.ViolationValue 
                && r.ViolationSeverityMatrixId != violationSeverityMatrix.ViolationSeverityMatrixId).Count() > 0;
            }
            else
            {
                recordExists = violationSeverity.Where(r => r.IncidentValue == violationSeverityMatrix.IncidentValue
                && r.ViolationValue == violationSeverityMatrix.ViolationValue).Count() > 0;
            }

            if (recordExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;
                apiResponse.Message = CommonMessages.RecordExistsMessage;
            }
            else
            {
                MDMViolationSeverityMatrix request = new MDMViolationSeverityMatrix();
                if (violationSeverityMatrix.ViolationSeverityMatrixId > 0)
                {
                    request = await _unitOfWork.ViolationSeverityMatrix.GetByIdAsync(violationSeverityMatrix.ViolationSeverityMatrixId);
                    request.ModifiedBy = violationSeverityMatrix.CreatedBy;
                    request.ModifiedOn = DateTime.Now;
                }
                else
                {
                    request.CreatedBy = violationSeverityMatrix.CreatedBy;
                    request.CreatedOn = DateTime.Now;
                }

                request.ViolationSeverityMatrixId = violationSeverityMatrix.ViolationSeverityMatrixId;
                request.IncidentValue = violationSeverityMatrix.IncidentValue;
                request.ViolationValue = violationSeverityMatrix.ViolationValue;
                request.ViolationDescription = violationSeverityMatrix.ViolationDescription;
                request.IsActiveViolationSeverityMatrix = violationSeverityMatrix.IsActiveViolationSeverityMatrix;

                var data = await _unitOfWork.ViolationSeverityMatrix.SaveAsync(request);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }

        //[HttpPut]
        //public async Task<ApiResponse<int>> Update(MDMViolationSeverityMatrix mDMViolationSeverityMatrix)
        //{
        //    var apiResponse = new ApiResponse<int>();
        //    if (mDMViolationSeverityMatrix == null)
        //        throw new DMSException(CommonMessages.InvalidModelMessage);

        //    var data = await _unitOfWork.ViolationSeverityMatrix.SaveAsync(mDMViolationSeverityMatrix);
        //    apiResponse.Success = true;
        //    apiResponse.Result = data;
        //    apiResponse.Message = CommonMessages.UpdateSuccessMessage;
        //    if (apiResponse.Result == 0)
        //        throw new DMSException(CommonMessages.UpdateErrorMessage);
        //    return apiResponse;
        //}

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.ViolationSeverityMatrix.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getViolationValueList")]
        public async Task<ApiResponse<ViolationValuesSearchResponce>> GetIncident(GridPagination gridPagination)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<ViolationValuesSearchResponce>();
            if (gridPagination.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE > 0)
            {
                top = gridPagination.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = gridPagination.PAGE_SIZE;
                skip = (gridPagination.START_INDEX - 1) * gridPagination.PAGE_SIZE;
            }

            var data = await _unitOfWork.ViolationSearchList.GetAllWithPaginationAsync(top, skip);

            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.violationValueSearchResponceList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}