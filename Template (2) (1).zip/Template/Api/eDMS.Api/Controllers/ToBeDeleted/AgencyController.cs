﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AgencyController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public AgencyController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<Agency>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<Agency>>();
            var data = await _unitOfWork.Agencies.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<Agency>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<Agency>();
            var data = await _unitOfWork.Agencies.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(AgencySaveRequest request)
        {
            var apiResponse = new ApiResponse<int>();
            if (request == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            ApplicationDBContext _context = new ApplicationDBContext();
            var allAgencies = _context.Agencies;
            bool recordExists = false;
            bool fieldValueExists = false;
            if (request.AgencyId > 0)
            {
                recordExists = allAgencies.Where(r => r.AgencyName.ToLower() == request.AgencyName.ToLower()
                && r.CountryId == request.CountryId && r.AgencyId != request.AgencyId).Count() > 0;

                fieldValueExists = allAgencies.Where(r => r.FieldValue.ToLower() == request.FieldValue.ToLower()
                && r.CountryId == request.CountryId && r.AgencyId != request.AgencyId).Count() > 0;
            }
            else
            {
                recordExists = allAgencies.Where(r => r.AgencyName.ToLower() == request.AgencyName.ToLower()
                && r.CountryId == request.CountryId).Count() > 0;

                fieldValueExists = allAgencies.Where(r => r.FieldValue.ToLower() == request.FieldValue.ToLower()
                && r.CountryId == request.CountryId).Count() > 0;
            }

            if (recordExists || fieldValueExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;
                apiResponse.Message = (recordExists == true) ? CommonMessages.RecordExistsMessage
                        : CommonMessages.FieldValueExistsMessage;
            }
            else
            {
                Agency agency = new Agency()
                {
                    AgencyId = request.AgencyId,
                    AgencyName = request.AgencyName,
                    CountryId = request.CountryId,
                    RegionId = request.RegionId,
                    FieldValue = request.FieldValue,
                    CreatedBy = request.CreatedBy,
                    IsActive = request.IsActive
                };

                var data = await _unitOfWork.Agencies.SaveAsync(agency);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(Agency agency)
        {
            var apiResponse = new ApiResponse<int>();
            if (agency == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.Agencies.SaveAsync(agency);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.Agencies.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getAgencyList")]
        public async Task<ApiResponse<AgencyResponseList>> getAgencyList(GridPagination gridPagination)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<AgencyResponseList>();
            if (gridPagination.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE > 0)
            {
                top = gridPagination.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = gridPagination.PAGE_SIZE;
                skip = (gridPagination.START_INDEX - 1) * gridPagination.PAGE_SIZE;
            }

            var data = await _unitOfWork.Agencies.GetAllWithPaginationAsync(top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.agencyResponseList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}