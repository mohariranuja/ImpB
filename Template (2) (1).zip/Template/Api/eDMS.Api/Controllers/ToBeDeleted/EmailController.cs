﻿using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;
using System.Net.Mail;
using System.Text;

namespace eDMS.Api.Controllers
{
    public class EmailController : Controller
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        private readonly IEmailRepository _emailRepository;
        private readonly IConfiguration _configuration;
        #endregion

        #region ===[ Constructor ]=================================================================
        public EmailController(IEmailRepository emailRepository, IConfiguration configuration,
            IUnitOfWork unitOfWork)
        {
            _emailRepository = emailRepository;
            _configuration = configuration;
            _unitOfWork = unitOfWork;
        }
        #endregion

        //#region ===[ Public Methods ]=================================================================
        //[HttpPost("Emailnotification")]
        //public async Task sendEMailNotification(EmailEntity emailEntity)
        //{
        //    List<Attachment> fileAttachment = new List<Attachment>();

        //    var toAddress = new List<string>(new string[] { emailEntity.To.ToString() });
        //    var cc = new List<string>(new string[] { string.Empty });
        //    var bcc = new List<string>(new string[] { string.Empty });

        //    if (emailEntity.Attachment != null && emailEntity.Attachment.Length > 0)
        //    {
        //        string fileName = Path.GetFileName(emailEntity.Attachment.FileName);
        //        fileAttachment.Add(new Attachment(emailEntity.Attachment.OpenReadStream(), fileName));
        //    }

        //    string isSMTPFlag = GetKeyValue(_configuration, "appConfigurations:isSMTPOn");
        //    if (isSMTPFlag == "YES")
        //        await _emailRepository.SendAsync(emailEntity.From, emailEntity.Subject, emailEntity.Body, toAddress, fileAttachment);
        //    else
        //    {
        //        //Email testing scenario when SMTP is not enabled/ configured on the server.
        //        string fullPath = Environment.CurrentDirectory + "//" + eDMSConstant.logFolder;
        //        string fullFilePath = fullPath + "//" + eDMSConstant.emailLogFileName;

        //        CreateCloseFile(fullPath, fullFilePath);

        //        StringBuilder email = new StringBuilder();
        //        email.Append("From: " + "\t" + "\t" + emailEntity.From);
        //        email.Append("\nTo: " + "\t" + "\t" + emailEntity.To);
        //        email.Append("\nSubject: " + "\t" + emailEntity.Subject);
        //        email.Append("\nbody: " + "\t" + "\t" + emailEntity.Body);
        //        if (emailEntity.Attachment != null)
        //        {
        //            using (StreamReader inputStreamReader = new StreamReader(emailEntity.Attachment.OpenReadStream()))
        //            {
        //                string fullAttchmentPath = fullPath + "//" + emailEntity.Attachment.FileName;
        //                string content = inputStreamReader.ReadToEnd();
        //                using (StreamWriter writeAttachment = new StreamWriter(fullAttchmentPath))
        //                {
        //                    writeAttachment.WriteLine(content);
        //                }
        //            }
        //        }
        //        using (StreamWriter writer = new StreamWriter(fullFilePath))
        //        {
        //            writer.WriteLine(email);
        //        }
        //    }
        //}

        //[HttpPost("api/ApprovalRequestEmail")]
        //public async Task ApprovalEmail([FromBody]ApprovalEmail approvalEmail)
        //{
        //    List<Attachment> fileAttachment = new List<Attachment>();
        //    var loginUser = await _unitOfWork.EmployeeMasters.GetByIdAsync(approvalEmail.LoginUserId);
        //    var driver = await _unitOfWork.EmployeeMasters.GetByIdAsync(approvalEmail.DriverEmployeeId);
        //    var approver = await _unitOfWork.EmployeeMasters.GetByIdAsync(approvalEmail.ApproverEmployeeId);

        //    var toAddress = new List<string>(new string[] { approver.EmailId });
        //    var fromEmail = loginUser.EmailId;//new List<string>(new string[] { string.Empty });
        //    var cc = new List<string>(new string[] { string.Empty });
        //    var bcc = new List<string>(new string[] { string.Empty });
        //    string emailSubject = eDMSConstant.approvalEmailTitle;
        //    StringBuilder emailBody = new StringBuilder();
        //    if (approvalEmail.isUSEmail)
        //        emailBody.Append(eDMSConstant.approvalEmailTemplateUS);
        //    else
        //        emailBody.Append(eDMSConstant.approvalEmailTemplateNonUS);

        //    string portNo = GetKeyValue(_configuration, "appConfigurations:portNo");
        //    string actionUrl = GetKeyValue(_configuration, "appConfigurations:actionURL");
        //    actionUrl = actionUrl.Replace("#PortNo", portNo);

        //    string approveAction = "<a href='" + actionUrl + "'>Approve</a>";
        //    approveAction = approveAction.Replace("#IsApproved", "true");
        //    string rejectAction = "<a href='" + actionUrl + "'>Reject</a>";
        //    rejectAction = rejectAction.Replace("#IsApproved", "false");
        //    emailBody = emailBody.Replace("#EmployeeID", approvalEmail.DriverEmployeeId.ToString());
        //    emailBody = emailBody.Replace("#EmployeeName", driver.FirstName + " " + driver.LastName);
        //    emailBody = emailBody.Replace("#OldRiskIndex", approvalEmail.OldRiskIndex.ToString());
        //    emailBody = emailBody.Replace("#NewRiskIndex", approvalEmail.NewRiskIndex.ToString());
        //    emailBody = emailBody.Replace("#ManagerName", approver.FirstName + " " + approver.LastName);
        //    emailBody = emailBody.Replace("#Action", "Approved");
        //    emailBody = emailBody.Replace("#ApproveAction", approveAction);
        //    emailBody = emailBody.Replace("#RejectAction", rejectAction);
        //    emailSubject = emailSubject.Replace("#EmployeeName", driver.FirstName + " " + driver.LastName);

        //    string isSMTPFlag = GetKeyValue(_configuration, "appConfigurations:isSMTPOn");

        //    // Create entry in History table.
        //    ApprovalHistory approvalHistory = new ApprovalHistory()
        //    {
        //        ApproverEmployeeId = approver.EmpId,
        //        LoginUserId = loginUser.EmpId,
        //        DriverEmployeeId = driver.EmpId,
        //        ApproverFirstName = approver.FirstName,
        //        ApproverLastName = approver.LastName,
        //        LoginFirstName = loginUser.FirstName,
        //        LoginLastName = loginUser.LastName,
        //        DriverFirstName = driver.FirstName,
        //        DriverLastName = driver.LastName,
        //        EmailSendDate = DateTime.Now,
        //        CreatedBy = loginUser.EmpId,
        //        IsActive = true,
        //        CreatedOn = DateTime.Now
        //    };
        //    var approvalHistoryId = await _unitOfWork.ApprovalHistoryRepositories.SaveAsync(approvalHistory);
        //    emailBody = emailBody.Replace("#HistoryId", approvalHistoryId.ToString());

        //    if (isSMTPFlag == "YES")
        //        await _emailRepository.SendAsync(fromEmail, emailSubject, emailBody.ToString(), toAddress, fileAttachment);
        //    else
        //    {
        //        //Email testing scenario when SMTP is not enabled/ configured on the server.
        //        string fullPath = Environment.CurrentDirectory + "//" + eDMSConstant.logFolder;
        //        string fullFilePath = fullPath + "//" + eDMSConstant.emailLogFileName;

        //        CreateCloseFile(fullPath, fullFilePath);

        //        StringBuilder email = new StringBuilder();
        //        email.Append("From: " + "\t" + "\t" + fromEmail);
        //        email.Append("\nTo: " + "\t" + "\t" + toAddress[0]);
        //        email.Append("\nSubject: " + "\t" + emailSubject);
        //        email.Append("\nbody: " + "\t" + "\t" + emailBody);

        //        using (StreamWriter writer = new StreamWriter(fullFilePath))
        //        {
        //            writer.WriteLine(email);
        //        }
        //    }
        //}

        //[HttpGet("ApproverResponseEmail")]
        //public async Task ApprovarResponse(int id, bool isApproved)
        //{
        //    var approvalHis = await _unitOfWork.ApprovalHistoryRepositories.GetByIdAsync(id);
        //    if (approvalHis != null)
        //    {
        //        ApplicationDBContext _context = new ApplicationDBContext();

        //        var driver = _context.EmployeeMasters.Where(r => r.EmpId == approvalHis.DriverEmployeeId).FirstOrDefault();
        //        var approver = _context.EmployeeMasters.Where(r => r.EmpId == approvalHis.ApproverEmployeeId).FirstOrDefault();
        //        var loginUser = _context.EmployeeMasters.Where(r => r.EmpId == approvalHis.LoginUserId).FirstOrDefault();

        //        var toAddress = new List<string>(new string[] { loginUser.EmailId });
        //        string fromAddress = approver.EmailId;
        //        var cc = new List<string>(new string[] { string.Empty });
        //        var bcc = new List<string>(new string[] { string.Empty });
        //        string emailSubject = eDMSConstant.approvalResponseTitle;
        //        StringBuilder emailBody = new StringBuilder();
        //        if (isApproved)
        //            emailBody.Append(eDMSConstant.approveEmailTemplate);
        //        else
        //            emailBody.Append(eDMSConstant.rejectEmailTemplate);

        //        emailBody = emailBody.Replace("#EmployeeID", driver.EmpId.ToString());
        //        emailBody = emailBody.Replace("#EmployeeName", driver.FirstName + " " + driver.LastName);
        //        emailSubject = emailSubject.Replace("#EmployeeID", driver.EmpId.ToString());

        //        string isSMTPFlag = GetKeyValue(_configuration, "appConfigurations:isSMTPOn");

        //        if (isSMTPFlag == "YES")
        //            await _emailRepository.SendAsync(fromAddress, emailSubject, emailBody.ToString(), toAddress, null);
        //        else
        //        {
        //            //Email testing scenario when SMTP is not enabled/ configured on the server.
        //            string fullPath = Environment.CurrentDirectory + "//" + eDMSConstant.logFolder;
        //            string fullFilePath = fullPath + "//" + eDMSConstant.emailLogFileName;

        //            CreateCloseFile(fullPath, fullFilePath);

        //            StringBuilder email = new StringBuilder();
        //            email.Append("From: " + "\t" + "\t" + fromAddress);
        //            email.Append("\nTo: " + "\t" + "\t" + toAddress[0]);
        //            email.Append("\nSubject: " + "\t" + emailSubject);
        //            email.Append("\nbody: " + "\t" + "\t" + emailBody);

        //            using (StreamWriter writer = new StreamWriter(fullFilePath))
        //            {
        //                writer.WriteLine(email);
        //            }
        //        }
        //    }
        //}
        //#endregion

        #region ===[ Private Methods ]=================================================================
        private string GetKeyValue(IConfiguration configuration, string keyName)
        {
            return configuration[keyName].ToString().ToUpper();
        }

        private void CreateCloseFile(string fullPath, string fullFilePath)
        {
            if (!Directory.Exists(fullPath))
                Directory.CreateDirectory(fullPath);
        }
        #endregion
    }
}