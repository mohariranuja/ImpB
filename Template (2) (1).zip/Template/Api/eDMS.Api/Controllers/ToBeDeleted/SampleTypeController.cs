﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SampleTypeController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public SampleTypeController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<SampleType>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<SampleType>>();
            var data = await _unitOfWork.SampleTypes.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<SampleType>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<SampleType>();
            var data = await _unitOfWork.SampleTypes.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByTestCategory_Type/{testCategory}/{testTypeId}")]
        public async Task<ApiResponse<List<SampleType>>> GetByTestCategory(string testCategory, int testTypeId)
        {
            var apiResponse = new ApiResponse<List<SampleType>>();
            var data = await _unitOfWork.SampleTypes.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive == true && r.TestTypeId == testTypeId &&
            r.TestCategoryName.ToLower() == testCategory.ToLower()).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(SampleTypeSaveRequest sampleTypeRequest)
        {
            var apiResponse = new ApiResponse<int>();
            if (sampleTypeRequest == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            ApplicationDBContext _context = new ApplicationDBContext();
            var allSampleType = _context.SampleTypes;
            bool recordExists = false;
            bool fieldValueExists = false;
            if (sampleTypeRequest.SampleTypeId > 0)
            {
                recordExists = allSampleType.Where(r => r.SampleTypeName.ToLower() == sampleTypeRequest.SampleTypeName.ToLower()
                && r.TestCategoryId == sampleTypeRequest.TestCategoryId && r.TestTypeId == sampleTypeRequest.TestTypeId
                && r.SampleTypeId != sampleTypeRequest.SampleTypeId).Count() > 0;

                fieldValueExists = allSampleType.Where(r => r.FieldValue.ToLower() == sampleTypeRequest.FieldValue.ToLower()
                && r.TestCategoryId == sampleTypeRequest.TestCategoryId && r.TestTypeId == sampleTypeRequest.TestTypeId
                && r.SampleTypeId != sampleTypeRequest.SampleTypeId).Count() > 0;
            }
            else
            {
                recordExists = allSampleType.Where(r => r.SampleTypeName.ToLower() == sampleTypeRequest.SampleTypeName.ToLower()
                && r.TestCategoryId == sampleTypeRequest.TestCategoryId
                && r.TestTypeId == sampleTypeRequest.TestTypeId).Count() > 0;

                fieldValueExists = allSampleType.Where(r => r.FieldValue.ToLower() == sampleTypeRequest.FieldValue.ToLower()
                && r.TestCategoryId == sampleTypeRequest.TestCategoryId
                && r.TestTypeId == sampleTypeRequest.TestTypeId).Count() > 0;
            }

            if (recordExists || fieldValueExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;
                apiResponse.Message = (recordExists == true) ? CommonMessages.RecordExistsMessage
                        : CommonMessages.FieldValueExistsMessage;
            }
            else
            {
                var testCategory = await _unitOfWork.TestCategories.GetByIdAsync(sampleTypeRequest.TestCategoryId)
                    ?? throw new DMSException(CommonMessages.InvalidModelMessage);

                var testType = await _unitOfWork.TestTypes.GetByIdAsync(sampleTypeRequest.TestTypeId)
                    ?? throw new DMSException(CommonMessages.InvalidModelMessage);

                SampleType sampleType = new SampleType()
                {
                    SampleTypeId = sampleTypeRequest.SampleTypeId,
                    SampleTypeName = sampleTypeRequest.SampleTypeName,
                    TestCategoryId = sampleTypeRequest.TestCategoryId,
                    TestCategoryName = testCategory.TestCategoryName,
                    TestTypeId = sampleTypeRequest.TestTypeId,
                    TestTypeName = testType.TestTypeName,
                    FieldValue = sampleTypeRequest.FieldValue,
                    IsActive = sampleTypeRequest.IsActive,
                    CreatedBy = sampleTypeRequest.CreatedBy
                };

                var data = await _unitOfWork.SampleTypes.SaveAsync(sampleType);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(SampleType sampleType)
        {
            var apiResponse = new ApiResponse<int>();
            if (sampleType == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.SampleTypes.SaveAsync(sampleType);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.SampleTypes.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getSampleTypeList")]
        public async Task<ApiResponse<SampleTypeResponseList>> getSampleTypeList(GridPagination gridPagination)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<SampleTypeResponseList>();
            if (gridPagination.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE > 0)
            {
                top = gridPagination.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = gridPagination.PAGE_SIZE;
                skip = (gridPagination.START_INDEX - 1) * gridPagination.PAGE_SIZE;
            }

            var data = await _unitOfWork.SampleTypes.GetAllWithPaginationAsync(top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.sampleTypeResponseList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}