﻿using DocumentFormat.OpenXml.InkML;
using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Extension;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.RiskCalculations.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage;

namespace eDMS.Api.Controllers.ToBeDeleted
{
    [Route("api/[controller]")]
    [ApiController]
    public class RiskCalculationsController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize RiskCalculationsController by injecting an object type of IUnitOfWork
        /// </summary>
        public RiskCalculationsController(IUnitOfWork unitOfWork)//
        {
            _unitOfWork = unitOfWork;

        }

        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpPost]
        public async Task<ApiResponse<List<DriverRiskInfo>>> Post(RisksRequest inputParamter)//,TransactionScope? inputScope
        {
            ApplicationDBContext context = new ApplicationDBContext();
            //await method is missing so getting error.
            var apiOutput = new ApiResponse<List<DriverRiskInfo>>();
            if (inputParamter == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);
            bool isTranscationCreatedInRisk = false;
            ApplicationDBContext _contextRisk = new ApplicationDBContext();
            IDbContextTransaction transRisk = null;
            if (inputParamter.inputTransaction == null)
            {
                transRisk = _contextRisk.Database.BeginTransaction();
                isTranscationCreatedInRisk = true;
            }
            else
                transRisk = inputParamter.inputTransaction;
            //using (ApplicationDBContext _contextRisk = new ApplicationDBContext())
            //{
            //    using (var transRisk = (inputParamter.inputTransaction != null) ? inputParamter.inputTransaction : _contextRisk.Database.BeginTransaction())
            //    {


            //  using (var scope = (inputParamter.inputScope != null) ? inputParamter.inputScope : new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))

            // {

            try
            {
                if (inputParamter.Region == null || inputParamter.Region.Trim() == string.Empty)
                {
                    int EmpId = 0;
                    DriverSearchRequest searchRequest = new DriverSearchRequest();
                    searchRequest.EmplId = inputParamter.EmplId;
                    inputParamter.Region = await GetRegion(inputParamter.EmplId);
                    //    var objDriverLicense = await _unitOfWork.DriversSearchResultList.GetManyAsyncResult(searchRequest);
                    //    if (objDriverLicense != null && objDriverLicense.driverSearchResultList != null && objDriverLicense.driverSearchResultList.Count > 0)
                    //    {
                    //        EmpId = objDriverLicense.driverSearchResultList.FirstOrDefault().EmpId;
                    //    }
                    //    if (EmpId > 0)
                    //    {
                    //        var empMaster = await _unitOfWork.EmployeeMasters.GetByIdAsync(EmpId);
                    //        if (empMaster != null)
                    //            inputParamter.Region = empMaster.Country;
                    //        if (inputParamter.Region != null && inputParamter.Region.Length > 0)
                    //        {
                    //            if (inputParamter.Region.Contains(eDMSConstant.usaConstant))//"USA"
                    //                inputParamter.Region = eDMSConstant.regionUSA;//"8USAR";
                    //            else if (inputParamter.Region.Contains(eDMSConstant.CanadaConstant))//"CAN"
                    //                inputParamter.Region = eDMSConstant.regionCAN;//"2CANR";
                    //        }
                    //    }
                }
                if (inputParamter.DriverLicenseId == 0)
                {
                    var objDriverLicense = await _unitOfWork.DriverLicenses.GetByIDMultipleRecord(inputParamter.EmplId);
                    inputParamter.DriverLicenseId = objDriverLicense.FirstOrDefault().DriverLicId;
                }
                //Get the record for risk from DriverRisks Table
                List<DriverRiskList> driverRisks = await GetDriverRisk(inputParamter.DriverLicenseId);
                //Need to calculate Behavior Risk Console
                var behavRiskConsoleResult = await _unitOfWork.DriversBehaviourRisks.GetBehaviorConsoleAsyncResult(inputParamter.EmplId);
                string behavRiskConsole = GetStringValueOfRisk(behavRiskConsoleResult);
                //Need to calculate Hos Risk or Behavitor Risk
                //var behavRiskResult = string.Empty;
                var behavRiskResult = await _unitOfWork.DriversBehaviourRisks.GetBehaviorAsyncResult(inputParamter.EmplId, inputParamter.Region);

                //Update Driver Risks table with all 5 risk Values ,
                DriverRiskList driverBehaviorRisk = await UpdateDriverRisksBehv(driverRisks, behavRiskConsole, context, 1);
                //DriverRiskList driverBehaviorRisk = await UpdateDriverRisks1(driverRisks, behavRiskResult, context);
                //Update Hos Table for HOS Risk ,
                var hosRiskResult = await _unitOfWork.HoursOfServices.GetHosRiskAsyncResult(inputParamter.EmplId);
                //Update Hos Table for Overall Risk ,
                string hosRisk = GetStringValueOfRisk(hosRiskResult);
                var hosResult = await _unitOfWork.HoursOfServices.GetHosAsyncResult(inputParamter.EmplId, inputParamter.Region);

                var driverAllRisks = await UpdateDriverRisks(driverRisks, behavRiskConsole, hosRisk, context, 1);
                // var driverAllRisks = await UpdateDriverRisks(driverRisks, behavRiskResult, hosResult, context);
                int result = await UpdateOverAllRisk(driverRisks, context);



                apiOutput.Success = true;
                apiOutput.Result = new List<DriverRiskInfo>();
                apiOutput.Message = CommonMessages.AddSuccessMessage;
                if (isTranscationCreatedInRisk)
                {
                    var transResult = transRisk.CommitAsync();
                }


                // if (scope != null && inputParamter.inputScope == null)
                //    scope.Complete(); // Commit transaction if all operations are successful
                // return Ok("Transaction successful");
                return apiOutput;
            }
            catch (Exception ex)
            {

                if (isTranscationCreatedInRisk)
                { transRisk.Rollback(); }
                // Log or handle exception
                //  return StatusCode(500, "An error occurred during transaction");
                throw new DMSException(CommonMessages.AddErrorMessage);
            }
            finally
            {
                if (isTranscationCreatedInRisk)//(transRisk != null && inputParamter.inputTransaction == null)
                {
                    transRisk.Dispose();
                }
            }

            // };
            //  };
            // };

        }

        private string GetStringValueOfRisk(string behavRiskConsoleResult)
        {
            string returnValue = string.Empty;
            switch (behavRiskConsoleResult)
            {
                case "1":
                    {
                        returnValue = "L";
                        break;
                    }
                case "2":
                    {
                        returnValue = "M";
                        break;
                    }
                case "3":
                    {
                        returnValue = "H";
                        break;
                    }
                default:
                    {
                        returnValue = "NA";
                        break;
                    }

            }
            return returnValue;
        }


        #endregion

        private async Task<DriverRiskList> UpdateDriverRisks(List<DriverRiskList> driverRisks, string behavRiskResult, string hosRiskResult, ApplicationDBContext objContext, int loginUserId)
        {
            var driverRisksResult = 0;
            int hosRiskIndexValueId = 0;
            if (hosRiskResult.Trim() == string.Empty)
                hosRiskResult = "NA";
            if (driverRisks != null && driverRisks.Count > 0)
            {
                var hosRisk = driverRisks.Where(x => x.RiskType == eDMSConstant.hosRiskType).SingleOrDefault();
                if (hosRisk != null && hosRiskResult != string.Empty)
                {

                    if (!hosRisk.RiskIndex.Contains(hosRiskResult))
                    {
                        var riskIndexAllResult = await GetAllRiskIndexes();
                        var riskIndexResult = riskIndexAllResult.Where(x => x.RiskIndex.Contains(hosRiskResult)).FirstOrDefault(); //behavRiskResult
                        if (riskIndexResult != null)
                        {
                            hosRiskIndexValueId = riskIndexResult.RiskIndexId;
                            bool removeResult = driverRisks.Remove(hosRisk);
                            hosRisk.RiskIndex = riskIndexResult.RiskIndex;
                            hosRisk.RiskIndexValueId = hosRiskIndexValueId;
                            driverRisks.Add(hosRisk);
                        }
                    }
                    if (hosRiskIndexValueId == 0)
                        hosRiskIndexValueId = hosRisk.RiskIndexValueId;
                    DriverRisks obj = new DriverRisks() { DriverRiskId = hosRisk.DriverRiskId, DriverLicenseId = hosRisk.DriverLicId, RiskTypeId = hosRisk.RiskTypeId, RiskIndexValueId = hosRiskIndexValueId, ModifiedBy = loginUserId, ModifiedOn = DateTime.Now, IsActive = hosRisk.IsActive, CreatedBy = hosRisk.CreatedBy };
                    //  driverRisksResult = await _unitOfWork.DriverRisks.SaveAsync(obj);
                    // UpdateOverAllRisk(driverRisks);
                    objContext.DriversRisk.Update(obj);
                    objContext.SaveChanges();
                    return hosRisk;
                }
            }
            return null;
        }

        private async Task<DriverRiskList> UpdateDriverRisksBehv(List<DriverRiskList> driverRisks,
            string behavRiskResult, ApplicationDBContext objContext, int modifyBy)
        {
            var driverRisksResult = 0;
            int RiskIndexValueId = 0;
            if (behavRiskResult.Trim() == string.Empty)
                behavRiskResult = "NA";
            if (driverRisks != null && driverRisks.Count > 0)
            {
                var behavRisk = driverRisks.Where(x => x.RiskType == eDMSConstant.behaviorRiskType).SingleOrDefault();
                if (behavRisk != null && behavRiskResult != string.Empty)
                {

                    if (!behavRisk.RiskIndex.Contains(behavRiskResult)) //behavRiskResult
                    {
                        var riskIndexAllResult = await GetAllRiskIndexes();
                        var riskIndexResult = riskIndexAllResult.Where(x => x.RiskIndex.Contains(behavRiskResult)).FirstOrDefault(); //behavRiskResult
                        if (riskIndexResult != null)
                        {
                            RiskIndexValueId = riskIndexResult.RiskIndexId;
                            bool removeResult = driverRisks.Remove(behavRisk);
                            behavRisk.RiskIndex = riskIndexResult.RiskIndex;
                            behavRisk.RiskIndexValueId = RiskIndexValueId;
                            driverRisks.Add(behavRisk);
                        }
                    }
                    if (RiskIndexValueId == 0)
                        RiskIndexValueId = behavRisk.RiskIndexValueId;
                    DriverRisks obj = new DriverRisks()
                    {
                        DriverRiskId = behavRisk.DriverRiskId,
                        DriverLicenseId = behavRisk.DriverLicId,
                        RiskTypeId = behavRisk.RiskTypeId,
                        RiskIndexValueId = RiskIndexValueId,
                        ModifiedBy = modifyBy,
                        ModifiedOn = DateTime.Now,
                        IsActive = behavRisk.IsActive,
                        CreatedBy = behavRisk.CreatedBy
                    };
                    objContext.DriversRisk.Update(obj);
                    objContext.SaveChanges();
                    //driverRisksResult = await _unitOfWork.DriverRisks.SaveAsync(obj);
                    // UpdateOverAllRisk(driverRisks);
                    return behavRisk;
                }
            }
            return null;
        }

        private async Task<int> UpdateOverAllRisk(List<DriverRiskList> driverRisks, ApplicationDBContext objContext)
        {
            var driverRisksResult = 0;
            var overAllRisk = driverRisks.Where(x => x.RiskType == eDMSConstant.OverallRisk).SingleOrDefault();
            int overAllRiskIndexValueId = eDMSConstant.overAllRiskIndexNA;//9;
            bool removeOverAllRisk = driverRisks.Remove(overAllRisk);
            bool IsHighExist = driverRisks.Any(n => n.RiskIndex == eDMSConstant.highRisk);//"High"
            if (!IsHighExist)
            {
                bool IsMediumExist = driverRisks.Any(n => n.RiskIndex == eDMSConstant.mediumRisk);//"Medium"
                if (!IsMediumExist)
                {
                    bool IsLowExist = driverRisks.Any(n => n.RiskIndex == eDMSConstant.lowRisk);//"Low"
                    if (IsLowExist)
                        overAllRiskIndexValueId = 3;
                }
                else
                    overAllRiskIndexValueId = 2;
            }
            else
                overAllRiskIndexValueId = 1;
            if (overAllRisk != null)
            {
                overAllRisk.RiskIndexValueId = overAllRiskIndexValueId;
                driverRisks.Add(overAllRisk);
                DriverRisks objOverAll = new DriverRisks() { DriverRiskId = overAllRisk.DriverRiskId, DriverLicenseId = overAllRisk.DriverLicId, RiskTypeId = overAllRisk.RiskTypeId, RiskIndexValueId = overAllRiskIndexValueId, ModifiedBy = 1, ModifiedOn = DateTime.Now, IsActive = overAllRisk.IsActive, CreatedBy = overAllRisk.CreatedBy };
                //  driverRisksResult = await _unitOfWork.DriverRisks.SaveAsync(objOverAll);
                objContext.DriversRisk.Update(objOverAll);
                objContext.SaveChanges();
                return driverRisksResult;
            }
            return 0;
        }

        private async Task<int> UpdateOverAllRisks(List<DriverRiskList> driverRisks, string overAllBehvRisk,
            ApplicationDBContext objContext, int loginUserId)
        {
            var driverRisksResult = 1;
            var overAllRisk = driverRisks.Where(x => x.RiskType == eDMSConstant.OverallRisk).SingleOrDefault();
            int overAllRiskIndexValueId = eDMSConstant.overAllRiskIndexNA;//9;
            bool removeOverAllRisk = driverRisks.Remove(overAllRisk);
            overAllBehvRisk = overAllBehvRisk.Trim().ToUpper();
            if (overAllBehvRisk == "H")
                overAllRiskIndexValueId = 1;
            else if (overAllBehvRisk == "M")
                overAllRiskIndexValueId = 2;
            else if (overAllBehvRisk == "L")
                overAllRiskIndexValueId = 3;

            if (overAllRisk != null)
            {
                overAllRisk.RiskIndexValueId = overAllRiskIndexValueId;
                driverRisks.Add(overAllRisk);
                DriverRisks objOverAll = new DriverRisks()
                {
                    DriverRiskId = overAllRisk.DriverRiskId,
                    DriverLicenseId = overAllRisk.DriverLicId,
                    RiskTypeId = overAllRisk.RiskTypeId,
                    RiskIndexValueId = overAllRiskIndexValueId,
                    ModifiedBy = loginUserId,
                    ModifiedOn = DateTime.Now,
                    IsActive = overAllRisk.IsActive,
                    CreatedBy = overAllRisk.CreatedBy
                };
                //  driverRisksResult = await _unitOfWork.DriverRisks.SaveAsync(objOverAll);
                objContext.DriversRisk.Update(objOverAll);
                objContext.SaveChanges();
                return driverRisksResult;
            }
            return 0;
        }

        private async Task<IReadOnlyList<MDMRiskIndex>> GetAllRiskIndexes()
        {
            return await _unitOfWork.RiskIndexes.GetAllAsync();

        }

        private async Task<List<DriverRiskList>> GetDriverRisk(int driverId)
        {
            List<DriverRiskList> riskInfo = new List<DriverRiskList>();
            var data = await _unitOfWork.DriverRiskList.GetManyAsync(driverId);
            riskInfo = (List<DriverRiskList>)data;

            return riskInfo;
        }
        private async Task<string> GetRegion(string emplID)
        {
            string result = string.Empty;
            string region = string.Empty;
            // int EmpId = 0;
            DriverLicense validLicenseData = null;
            //DriverSearchRequest driverSearchRequest= new DriverSearchRequest();
            //driverSearchRequest.EmplId=emplID;
            var objDriverLicense = await _unitOfWork.DriverLicenses.GetByIDMultipleRecord(emplID);
            //var objDriverLicense = await _unitOfWork.DriversSearchResultList.GetManyAsyncResult(driverSearchRequest);
            if (objDriverLicense != null && objDriverLicense.Count > 0)
            {
                // EmpId = objDriverLicense.FirstOrDefault().EmployeeId;
                validLicenseData = objDriverLicense.OrderByDescending(y => y.ExpirationDT).FirstOrDefault();
            }
            if (validLicenseData != null)
            {

                //var empMaster = await _unitOfWork.EmployeeMasters.GetByIdAsync(EmpId);
                //if (empMaster != null)
                region = validLicenseData.Country;
                if (region != null && region.Length > 0)
                {
                    if (region.Contains(eDMSConstant.usaConstant))//"USA"
                        result = eDMSConstant.regionUSA;//"8USAR";
                    else if (region.Contains(eDMSConstant.CanadaConstant))//"CAN"
                        result = eDMSConstant.regionCAN;//"2CANR";
                }
            }
            return result;
        }
        [HttpPost("GetBehaviorRisk")]
        public async Task<ApiResponse<string>> GetBehavior(string emplId, int loginUserId)
        {
            var apiResponse = new ApiResponse<string>();
            bool isTranscationCreatedInRisk = false;
            ApplicationDBContext _contextRisk = new ApplicationDBContext();
            IDbContextTransaction transRisk = _contextRisk.Database.BeginTransaction();
            isTranscationCreatedInRisk = true;
            try
            {
                ApplicationDBContext context = new ApplicationDBContext();
                string regionId = await GetRegion(emplId);
                var objDriverLicense = await _unitOfWork.DriverLicenses.GetByIDMultipleRecord(emplId);
                int driverLicenseId = objDriverLicense.FirstOrDefault().DriverLicId;
                List<DriverRiskList> driverRisks = await GetDriverRisk(driverLicenseId);
                var behavRiskConsoleResult = await _unitOfWork.DriversBehaviourRisks.GetBehaviorConsoleAsyncResult(emplId);
                string behavRiskConsole = GetStringValueOfRisk(behavRiskConsoleResult);
                string overallRisk = await _unitOfWork.DriversBehaviourRisks.GetBehaviorAsyncResult(emplId, regionId);
                DriverRiskList driverBehaviorRisk = await UpdateDriverRisksBehv(driverRisks, behavRiskConsole, context, loginUserId);
                int result = 0;
                if (overallRisk.Trim().Length > 0 && !overallRisk.Trim().ToUpper().Contains(eDMSConstant.defaultShortNA))
                    result = await UpdateOverAllRisks(driverRisks, overallRisk, context, loginUserId);

                if (result == 1 || result == -1)
                {
                    apiResponse.Result = "Success";
                    apiResponse.Success = true;
                }
                else
                {
                    apiResponse.Result = "Failure";
                    apiResponse.Success = false;
                }
                return apiResponse;
            }
            catch (Exception ex)
            {

                if (isTranscationCreatedInRisk)
                { transRisk.Rollback(); }
                // Log or handle exception
                //  return StatusCode(500, "An error occurred during transaction");
                throw new DMSException(CommonMessages.AddErrorMessage);
            }
            finally
            {
                if (isTranscationCreatedInRisk)//(transRisk != null && inputParamter.inputTransaction == null)
                {
                    transRisk.Dispose();
                }
            }
        }
        [HttpPost("GetHosRisk")]
        public async Task<ApiResponse<string>> GetHos(string emplId, int loginUserId)
        {
            var apiResponse = new ApiResponse<string>();
            bool isTranscationCreatedInRisk = false;
            ApplicationDBContext _contextRisk = new ApplicationDBContext();
            IDbContextTransaction transRisk = _contextRisk.Database.BeginTransaction();
            isTranscationCreatedInRisk = true;
            try
            {
                ApplicationDBContext context = new ApplicationDBContext();
                string regionId = await GetRegion(emplId);

                var objDriverLicense = await _unitOfWork.DriverLicenses.GetByIDMultipleRecord(emplId);
                int driverLicenseId = objDriverLicense.FirstOrDefault().DriverLicId;
                List<DriverRiskList> driverRisks = await GetDriverRisk(driverLicenseId);
                var hosRiskResult = await _unitOfWork.HoursOfServices.GetHosRiskAsyncResult(emplId);
                //Update Hos Table for Overall Risk ,
                string hosRisk = GetStringValueOfRisk(hosRiskResult);

                string overallRisk = await _unitOfWork.HoursOfServices.GetHosAsyncResult(emplId, regionId);
                DriverRiskList driverHosRisk = await UpdateDriverRisks(driverRisks, string.Empty, hosRisk, context, loginUserId);
                int result = 0;
                if (overallRisk.Trim().Length > 0 && !overallRisk.Trim().ToUpper().Contains(eDMSConstant.defaultShortNA))
                    result = await UpdateOverAllRisks(driverRisks, overallRisk, context, loginUserId);

                if (result == 1 || result == -1)
                {
                    apiResponse.Result = "Success";
                    apiResponse.Success = true;
                }
                else
                {
                    apiResponse.Result = "Failure";
                    apiResponse.Success = false;
                }
                return apiResponse;
            }
            catch (Exception ex)
            {

                if (isTranscationCreatedInRisk)
                { transRisk.Rollback(); }
                // Log or handle exception
                //  return StatusCode(500, "An error occurred during transaction");
                throw new DMSException(CommonMessages.AddErrorMessage);
            }
            finally
            {
                if (isTranscationCreatedInRisk)//(transRisk != null && inputParamter.inputTransaction == null)
                {
                    transRisk.Dispose();
                }
            }
        }



        [HttpGet("GetOverAllRisk")]
        public async Task<ApiResponse<List<DriverRiskList>>> GetOverAllRisk(int driverLicId)
        {
            var apiResponse = new ApiResponse<List<DriverRiskList>>();
            var data = await _unitOfWork.DriverRiskList.GetManyAsync(driverLicId);
            List<DriverRiskList> driverRiskInfo = (List<DriverRiskList>)data;
            // int result= await UpdateOverAllRisk(driverRiskInfo);


            apiResponse.Result = driverRiskInfo;
            apiResponse.Success = true;


            return apiResponse;
        }
        [HttpGet("GetVoilationRisk")]
        public async Task<ApiResponse<string>> GetVoilationRisk()
        {
            var apiResponse = new ApiResponse<string>();

            string result = await _unitOfWork.ViolationRisks.GetViolationAsyncResult();


            apiResponse.Result = result;
            apiResponse.Success = true;


            return apiResponse;
        }
    }
}