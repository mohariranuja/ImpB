﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IncidentSeverityMatrixController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public IncidentSeverityMatrixController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<IncidentSeverityMatrix>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<IncidentSeverityMatrix>>();
            var data = await _unitOfWork.IncidentSeverityMatrices.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetById/{id}")]
        public async Task<ApiResponse<IncidentSeverityMatrix>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<IncidentSeverityMatrix>();
            var data = await _unitOfWork.IncidentSeverityMatrices.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetRiskIndexByIncidentType_Value/{incidentValue}, {incidentTypeId}")]
        public async Task<ApiResponse<IncidentSeverityMatrix>> GetRiskIndex(int incidentValue, int incidentTypeId)
        {
            if (incidentValue <= 0 || incidentTypeId <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<IncidentSeverityMatrix>();
            var data = await _unitOfWork.IncidentSeverityMatrices.GetAllAsync();
            var riskIndex = data.Where(w => w.IsActiveIncidentSeverityMatrix = true && w.IncidentValue == incidentValue
            && w.IncidentTypeId == incidentTypeId).FirstOrDefault();
            //var data = await _unitOfWork.IncidentValues.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = riskIndex;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(IncidentSeverityMatrix incidentSeverityMatrix)
        {
            var apiResponse = new ApiResponse<int>();
            if (incidentSeverityMatrix == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.IncidentSeverityMatrices.SaveAsync(incidentSeverityMatrix);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(IncidentSeverityMatrix mdmIncidentTypeValue)
        {
            var apiResponse = new ApiResponse<int>();
            if (mdmIncidentTypeValue == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);
            var data = await _unitOfWork.IncidentSeverityMatrices.SaveAsync(mdmIncidentTypeValue);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.IncidentSeverityMatrices.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

     
        [HttpPost("getIncidentSeverityMatrixByPage")]
        public async Task<ApiResponse<IncidentsSeverityMatrixResult>> getIncidentSeverityMatrixByPage(IncidentSeverityMatrixRequest incidentSeverityMatrixRequest)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<IncidentsSeverityMatrixResult>();
            //Expression<Func<EmployeeMaster, bool>> filterData = getIncidentFilterData(employeeMasterTeamsRequest)!;
            if (incidentSeverityMatrixRequest.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (incidentSeverityMatrixRequest.START_INDEX == 0 && incidentSeverityMatrixRequest.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (incidentSeverityMatrixRequest.START_INDEX == 0 && incidentSeverityMatrixRequest.PAGE_SIZE > 0)
            {
                top = incidentSeverityMatrixRequest.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = incidentSeverityMatrixRequest.PAGE_SIZE;
                skip = (incidentSeverityMatrixRequest.START_INDEX - 1) * incidentSeverityMatrixRequest.PAGE_SIZE;
            }

            var data = await _unitOfWork.IncidentSeverityMatrixByPage.GetManyAsync(null, top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.incidentSeverityMatrices.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost("getAllIncidentSeverityMatrixes")]
        public async Task<ApiResponse<IncidentsSeverityMatrixResult>> GetAll(GenericSearchRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<IncidentsSeverityMatrixResult>();
            Expression<Func<IncidentSeverityMatrix, bool>> filterData = getFilterData(request)!;

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.IncidentSeverityMatrixByPage.GetManyAsyncFilter(filterData,null, top, skip);

            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.incidentSeverityMatrices.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [NonAction]
        internal Expression<Func<IncidentSeverityMatrix, bool>>? getFilterData(GenericSearchRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<IncidentSeverityMatrix, bool>>> obList = new List<Expression<Func<IncidentSeverityMatrix, bool>>>();
                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<IncidentSeverityMatrix>.getFilter(kvp));
                }
                var combinedFilter = FilterHelper<IncidentSeverityMatrix>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        #endregion
    }
}