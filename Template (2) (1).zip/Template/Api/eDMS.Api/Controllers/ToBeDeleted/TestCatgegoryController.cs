﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestCategoryController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize TestCatgegoryController by injecting an object type of IUnitOfWork
        /// </summary>
        public TestCategoryController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpGet]
        public async Task<ApiResponse<List<TestCategory>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<TestCategory>>();
            var data = await _unitOfWork.TestCategories.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive == true).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<TestCategory>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<TestCategory>();
            var data = await _unitOfWork.TestCategories.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetTestCategoryByFieldValue")]
        public async Task<ApiResponse<TestCategory>> GetByFieldValue(string fieldValue)
        {
            if (string.IsNullOrEmpty(fieldValue))
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<TestCategory>();
            var allData = await _unitOfWork.TestCategories.GetAllAsync();
            var data = allData.Where(r => r.FieldValue == fieldValue).FirstOrDefault();
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }
        
        [HttpPost]
        public async Task<ApiResponse<int>> Add(TestCategoryRequest testCategoryRequest)
        {
            var apiResponse = new ApiResponse<int>();
            if (testCategoryRequest == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var testCategory = await _unitOfWork.TestCategories.GetAllAsync();
            bool recordExists = false;
            bool fieldValueExists = false;

            if (testCategoryRequest.TestCategoryId > 0)
            {
                recordExists = testCategory.Where(r => r.TestCategoryName.ToLower() == testCategoryRequest.TestCategoryName.ToLower()
                && r.TestCategoryId != testCategoryRequest.TestCategoryId).Count() > 0;

                fieldValueExists = testCategory.Where(r => r.FieldValue.ToLower() == testCategoryRequest.FieldValue.ToLower()
                && r.TestCategoryId != testCategoryRequest.TestCategoryId).Count() > 0;
            }
            else
            {
                recordExists = testCategory.Where(r => r.TestCategoryName.ToLower() == testCategoryRequest.TestCategoryName.ToLower()).Count() > 0;
                fieldValueExists = testCategory.Where(r => r.FieldValue.ToLower() == testCategoryRequest.FieldValue.ToLower()).Count() > 0;
            }

            if (recordExists || fieldValueExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;

                apiResponse.Message = (recordExists == true) ? CommonMessages.RecordExistsMessage
                    : CommonMessages.FieldValueExistsMessage;
            }
            else
            {
                TestCategory request = new TestCategory();
                if (testCategoryRequest.TestCategoryId > 0)
                {
                    request = await _unitOfWork.TestCategories.GetByIdAsync(testCategoryRequest.TestCategoryId);
                    request.ModifiedBy = testCategoryRequest.CreatedBy;
                    request.ModifiedOn = DateTime.Now;
                }
                else
                {
                    request.CreatedBy = testCategoryRequest.CreatedBy;
                    request.CreatedOn = DateTime.Now;
                }

                request.TestCategoryId = testCategoryRequest.TestCategoryId;
                request.TestCategoryName = testCategoryRequest.TestCategoryName;
                request.IsActive = testCategoryRequest.IsActive;
                request.FieldValue = testCategoryRequest.FieldValue;

                var data = await _unitOfWork.TestCategories.SaveAsync(request);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }
        
        [HttpPut]
        public async Task<ApiResponse<int>> Update(TestCategory testCategory)
        {
            var apiResponse = new ApiResponse<int>();
            if (testCategory == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.TestCategories.SaveAsync(testCategory);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }
        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.TestCategories.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getTestCategotyList")]
        public async Task<ApiResponse<TestCategoryResponse>> getTestCategotyList(GridPagination gridPagination)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<TestCategoryResponse>();
            
            if (gridPagination.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE > 0)
            {
                top = gridPagination.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = gridPagination.PAGE_SIZE;
                skip = (gridPagination.START_INDEX - 1) * gridPagination.PAGE_SIZE;
            }

            var data = await _unitOfWork.TestCategories.GetAllWithPaginationAsync(top, skip);

            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.TestCategoryResponseList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}