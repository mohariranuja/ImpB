﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApprovalHistoryController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        private readonly IEmailRepository _emailRepository;
        private readonly IConfiguration _configuration;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public ApprovalHistoryController(IUnitOfWork unitOfWork, IEmailRepository emailRepository,
        IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            this._emailRepository = emailRepository;
            this._configuration = configuration;
        }

        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet("GetApproval")]
        public async Task<ApiResponse<int>>GetData(int id, bool isApproved)//)
        {
            ApplicationDBContext _context = new ApplicationDBContext();
            //Get DriverEmployeeId based on ApprovalHistoryId

            var apiResponse = new ApiResponse<int>();
            int result = 0;
            ApiResponse<List<ApprovalHistory>> approvalHistories = await GetAll();  //GetById(id);
            if(approvalHistories == null)
                throw new DMSException(CommonMessages.AddErrorMessage);
            int modifiedBy = approvalHistories.Result.Where(x => x.ApprovalHistoryId == id).First().ApproverEmployeeId;
            int DriverEmployeeId = approvalHistories.Result.Where (x=>x.ApprovalHistoryId==id).First().DriverEmployeeId;
            var allDriverEmployees = approvalHistories.Result.Where(y => y.DriverEmployeeId == DriverEmployeeId ).ToList();
            allDriverEmployees = allDriverEmployees.Where(z => !z.IsApproved.HasValue).ToList();
            foreach (var driverEmployee in allDriverEmployees)
            {
                driverEmployee.IsApproved = isApproved;
                driverEmployee.ModifiedOn = DateTime.Now;
                driverEmployee.ModifiedBy = modifiedBy;
                driverEmployee.ResponseDate = DateTime.Now;
            }
            IEnumerable<ApprovalHistory> inptValues = allDriverEmployees;
            _context.UpdateRange(inptValues);
            int resultAll = _context.SaveChanges();
            ApiResponse<int> returnVal = new ApiResponse<int> { Result = resultAll };
            result = returnVal.Result;
            //if (approvalHis.Result != null && approvalHis.Result.IsApproved == null)
            //{
            //    approvalHis.Result.IsApproved = isApproved;                
            //    approvalHis.Result.ModifiedOn = DateTime.Now;
            //    approvalHis.Result.ModifiedBy = approvalHis.Result.ApproverEmployeeId;
            //    approvalHis.Result.ResponseDate = DateTime.Now;

            //    ApiResponse<int> returnVal = await Add(approvalHis.Result);
            //    result = returnVal.Result;
            //if (returnVal.Result == 0)
            //    throw new DMSException(CommonMessages.AddErrorMessage);

            //EmailController email = new EmailController(_emailRepository,_configuration,_unitOfWork);
            //email.ApprovarResponse(id, isApproved);
            // }
            apiResponse.Result = result;
            apiResponse.Success = true;
            apiResponse.Message = (result> 0)? (isApproved?"Approved successfully!": "Rejected successfully!"): "Already Approved/Rejected";

            return apiResponse;
        }

        [HttpGet]
        public async Task<ApiResponse<List<ApprovalHistory>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<ApprovalHistory>>();
            var data = await _unitOfWork.ApprovalHistoryRepositories.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<ApprovalHistory>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<ApprovalHistory>();
            var data = await _unitOfWork.ApprovalHistoryRepositories.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(ApprovalHistory approvalHistory)
        {
            var apiResponse = new ApiResponse<int>();
            if (approvalHistory == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.ApprovalHistoryRepositories.SaveAsync(approvalHistory);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(ApprovalHistory approvalHistory)
        {
            var apiResponse = new ApiResponse<int>();
            if (approvalHistory == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.ApprovalHistoryRepositories.SaveAsync(approvalHistory);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.ApprovalHistoryRepositories.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }
        #endregion
    }
}