﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestTypeController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public TestTypeController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<TestType>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<TestType>>();
            var data = await _unitOfWork.TestTypes.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive== true).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<TestType>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<TestType>();
            var data = await _unitOfWork.TestTypes.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByTestCategory{testCategory}")]
        public async Task<ApiResponse<List<TestType>>> GetByTestCategory(string testCategory)
        {
            var apiResponse = new ApiResponse<List<TestType>>();
            var data = await _unitOfWork.TestTypes.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive == true && 
            r.TestCategoryName.ToLower() == testCategory.ToLower()).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetTestTypeByTestCategoryId{testCategoryId}")]
        public async Task<ApiResponse<List<TestType>>> GetByTestCategoryId(int testCategoryId)
        {
            var apiResponse = new ApiResponse<List<TestType>>();
            var data = await _unitOfWork.TestTypes.GetAllAsync();
            data = data.ToList().Where(r => r.IsActive == true && r.TestCategoryId == testCategoryId).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(TestTypeSaveRequest testType)
        {
            ApplicationDBContext _context = new ApplicationDBContext();

            var apiResponse = new ApiResponse<int>();
            if (testType == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var allTestTypes = _context.TestTypes;

            bool recordExists = false;
            bool fieldValueExists = false;
            if (testType.TestTypeId > 0)
            {
                recordExists = allTestTypes.Where(r => r.TestTypeName.ToLower() == testType.TestTypeName.ToLower()
                && r.TestCategoryId == testType.TestCategoryId && r.TestTypeId != testType.TestTypeId).Count() > 0;

                fieldValueExists = allTestTypes.Where(r => r.FieldValue.ToLower() == testType.FieldValue.ToLower()
                && r.TestCategoryId == testType.TestCategoryId && r.TestTypeId != testType.TestTypeId).Count() > 0;
            }
            else
            {
                recordExists = allTestTypes.Where(r => r.TestTypeName.ToLower() == testType.TestTypeName.ToLower()
                && r.TestCategoryId == testType.TestCategoryId).Count() > 0;

                fieldValueExists = allTestTypes.Where(r => r.FieldValue.ToLower() == testType.FieldValue.ToLower()
                && r.TestCategoryId == testType.TestCategoryId).Count() > 0;
            }

            if (recordExists || fieldValueExists)
            {
                apiResponse.Success = false;
                apiResponse.Result = 0;
                apiResponse.Message = (recordExists == true) ? CommonMessages.RecordExistsMessage
                    : CommonMessages.FieldValueExistsMessage;
            }
            else
            {
                var testCategory = await _unitOfWork.TestCategories.GetByIdAsync(testType.TestCategoryId)
                    ?? throw new DMSException(CommonMessages.InvalidModelMessage);

                TestType request = new TestType()
                {
                    TestTypeId = testType.TestTypeId,
                    TestTypeName = testType.TestTypeName,
                    TestCategoryId = testType.TestCategoryId,
                    TestCategoryName = testCategory.TestCategoryName,
                    FieldValue = testType.FieldValue,
                    IsActive = testType.IsActive,
                    CreatedBy = testType.CreatedBy
                };

                var data = await _unitOfWork.TestTypes.SaveAsync(request);
                apiResponse.Success = true;
                apiResponse.Result = data;
                apiResponse.Message = CommonMessages.AddSuccessMessage;

                if (apiResponse.Result == 0)
                    throw new DMSException(CommonMessages.AddErrorMessage);
            }
            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(TestType testType)
        {
            var apiResponse = new ApiResponse<int>();
            if (testType == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.TestTypes.SaveAsync(testType);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.TestTypes.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("getTestTypeList")]
        public async Task<ApiResponse<TestTypeResponseList>> getTestTypeList(GridPagination gridPagination)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<TestTypeResponseList>();
            if (gridPagination.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (gridPagination.START_INDEX == 0 && gridPagination.PAGE_SIZE > 0)
            {
                top = gridPagination.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = gridPagination.PAGE_SIZE;
                skip = (gridPagination.START_INDEX - 1) * gridPagination.PAGE_SIZE;
            }

            var data = await _unitOfWork.TestTypes.GetAllWithPaginationAsync(top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.testTypeResponseList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}