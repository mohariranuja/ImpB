﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PsxlatitemController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public PsxlatitemController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<Psxlatitem>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<Psxlatitem>>();
            var data = await _unitOfWork.Psxlatitems.GetAllAsync();
            data = data.ToList().Where(r => r.EFF_STATUS == "A").ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetListByFieldNames")]
        public async Task<ApiResponse<List<Psxlatitem>>> GetListByFieldNames(string fieldName)
        {
            var apiResponse = new ApiResponse<List<Psxlatitem>>();
            var data = await _unitOfWork.Psxlatitems.GetAllAsync();
            data = data.ToList().Where(r => r.EFF_STATUS == "A" && r.FIELDNAME == fieldName).ToList();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage+ ": fieldName: " + fieldName );
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<Psxlatitem>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<Psxlatitem>();
            var data = await _unitOfWork.Psxlatitems.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(Psxlatitem entity)
        {
            var apiResponse = new ApiResponse<int>();
            if (entity == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.Psxlatitems.SaveAsync(entity);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(Psxlatitem entity)
        {
            var apiResponse = new ApiResponse<int>();
            if (entity == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.Psxlatitems.SaveAsync(entity);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> DeleteBySyncId(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.Psxlatitems.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }
        #endregion
    }
}