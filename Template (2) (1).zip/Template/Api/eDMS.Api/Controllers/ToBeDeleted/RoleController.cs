﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;


        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize RoleController by injecting an object type of IUnitOfWork
        /// </summary>
        public RoleController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;

        }

        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpGet]
        public async Task<ApiResponse<List<MdmRole>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<MdmRole>>();
            var data = await _unitOfWork.MdmRoles.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

       

        #endregion

    }
}
