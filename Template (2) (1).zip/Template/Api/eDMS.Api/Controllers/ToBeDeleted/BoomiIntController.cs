﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace eDMS.Api.Controllers
{
    public class BoomiIntController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;

        #endregion

        #region ===[ Constructor ]=================================================================

        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public BoomiIntController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;          
        }

        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpGet("GetCountryList")]
        public async Task<ApiResponse<List<Country>>> GetCountryList()
        {
            var apiResponse = new ApiResponse<List<Country>>();           
            var data = await _unitOfWork.Countries.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();          

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

      
        [HttpPost("AddCountry")]
        public async Task<ApiResponse<int>> AddCountry(Country country)
        {
            var apiResponse = new ApiResponse<int>();
            if (country == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.Countries.SaveAsync(country);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut("UpdateCountry")]
        public async Task<ApiResponse<int>> UpdateCountry(Country country)
        {
            var apiResponse = new ApiResponse<int>();
            if (country == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.Countries.SaveAsync(country);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;

        }

        [HttpDelete("DeleteCountry")]
        public async Task<ApiResponse<int>> DeleteCountry(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.Countries.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        #endregion
    }
}
