﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Extension;
using Microsoft.AspNetCore.Mvc;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RiskTypeController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public RiskTypeController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<MDMRiskType>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<MDMRiskType>>();
            var data = await _unitOfWork.RiskTypes.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();
            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("{id}")]
        public async Task<ApiResponse<MDMRiskType>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<MDMRiskType>();
            var data = await _unitOfWork.RiskTypes.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByType")]
        public async Task<ApiResponse<MDMRiskType>> GetByType(string riskType)
        {
            if (riskType.IsNullOrEmpty())
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<MDMRiskType>();
            var data = await _unitOfWork.RiskTypes.GetByTypeAsync(riskType);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(MDMRiskType riskType)
        {
            var apiResponse = new ApiResponse<int>();
            if (riskType == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.RiskTypes.SaveAsync(riskType);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(MDMRiskType riskType)
        {
            var apiResponse = new ApiResponse<int>();
            if (riskType == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.RiskTypes.SaveAsync(riskType);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.RiskTypes.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }
        #endregion
    }
}