﻿using Azure.Core;
using DocumentFormat.OpenXml.Drawing.Charts;
using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Api.Controllers
{
    public class DriverRisksHistoryController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public DriverRisksHistoryController(IUnitOfWork unitOfWork, ApplicationDBContext dbContext)
        {
            this._unitOfWork = unitOfWork;
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================

        [HttpGet("{id}")]
        public async Task<ApiResponse<DriverRisksHistory>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DriverRisksHistory>();
            var data = await _unitOfWork.DriverRisksHistories.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetDriverRisksHistory")]
        public async Task<ApiResponse<DriverRisksHistory>> GetById(int driverLicenseId, int riskTypeId)
        {
            if (driverLicenseId <= 0 || riskTypeId <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<DriverRisksHistory>();
            var data = await _unitOfWork.DriverRisksHistories.GetByDLRiskTypeAsync(driverLicenseId, riskTypeId);
            apiResponse.Success = true;
            apiResponse.Result = data;

            //if (apiResponse.Result == null)
            //    throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }
        
        [HttpGet]
        public async Task<ApiResponse<List<DriverRisksHistory>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<DriverRisksHistory>>();
            var data = await _unitOfWork.DriverRisksHistories.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost]
        public async Task<ApiResponse<int>> Add(DriverRisksHistory driverRisksHistory)
        {
            var apiResponse = new ApiResponse<int>();
            if (driverRisksHistory == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DriverRisksHistories.SaveAsync(driverRisksHistory);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.AddSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.AddErrorMessage);

            return apiResponse;
        }

        [HttpPut]
        public async Task<ApiResponse<int>> Update(DriverRisksHistory driverRisksHistory)
        {
            var apiResponse = new ApiResponse<int>();
            if (driverRisksHistory == null)
                throw new DMSException(CommonMessages.InvalidModelMessage);

            var data = await _unitOfWork.DriverRisksHistories.SaveAsync(driverRisksHistory);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.UpdateSuccessMessage;
            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.UpdateErrorMessage);
            return apiResponse;
        }

        [HttpDelete]
        public async Task<ApiResponse<int>> Delete(int id)
        {
            if (id <= 0)
                throw new DMSException(CommonMessages.InputIDErrorMessage);

            var apiResponse = new ApiResponse<int>();
            var data = await _unitOfWork.DriverRisksHistories.DeleteAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;
            apiResponse.Message = CommonMessages.DeletedSuccessMessage;

            if (apiResponse.Result == 0)
                throw new DMSException(CommonMessages.DeleteErrorMessage);

            return apiResponse;
        }

        [HttpPost("GetDriverAuditReport")]
        public async Task<ApiResponse<AuditReportResponses>> GetDriverAuditReport(AuditReportRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<AuditReportResponses>();

            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.DriverRisksHistories.GetDriverAuditListAsync(request.DriverLicenseId, top, skip);

            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result.auditResponse.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }
        #endregion
    }
}