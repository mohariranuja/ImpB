﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using DocumentFormat.OpenXml.Drawing.Charts;
using System.Reflection;
using System.ComponentModel;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MDMManagerAccessController : BaseApiController
    {
        #region ===[ Private Members ]=============================================================

        private readonly IUnitOfWork _unitOfWork;


        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public MDMManagerAccessController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpPost("getMDMManagerCountries")]
        public async Task<ApiResponse<List<MDMManagerCountryAccess>>> GetCountries(int emplID)
        {
            var apiResponse = new ApiResponse<List<MDMManagerCountryAccess>>();           
            var data = await _unitOfWork.MDMManagerAccessListRepository.GetManyAsync(emplID);
            apiResponse.Result = data.ToList<MDMManagerCountryAccess>();
            apiResponse.Success = true;

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost("GetMananagerCountryWiseUsers")]
        public async Task<ApiResponse<MDMManagerAccessSearchResult>> GetMananagerCountryWiseUsers(MDMManagerAccessRequest request)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<MDMManagerAccessSearchResult>();
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.MDMManagerAccessListRepository.GetMananagerAccessList(request.EmpId, request.CountryIds, top, skip);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result.managerUserAccess.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpPost("GetMananagerCountryWiseUsersFileDownload")]
        public async Task<IActionResult> ViolationReportFileDownload(MDMManagerAccessRequest request)
        {
            var apiResponse = new ApiResponse<MDMManagerAccessSearchResult>();
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                request.START_INDEX = null;
                request.PAGE_SIZE = null;
            }

            var data = await _unitOfWork.MDMManagerAccessListRepository.GetMananagerAccessList(request.EmpId, request.CountryIds, request.PAGE_SIZE, request.START_INDEX);
            string filepath = string.Empty;
            try
            {
                var stream = new MemoryStream();
                using (var spreadsheetDocument = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook))
                {
                    var workbookPart = spreadsheetDocument.AddWorkbookPart();
                    workbookPart.Workbook = new Workbook();
                    var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                    worksheetPart.Worksheet = new Worksheet(new SheetData());
                    var sheets = spreadsheetDocument.WorkbookPart.Workbook.AppendChild(new Sheets());
                    sheets.Append(new Sheet() { Id = spreadsheetDocument.WorkbookPart.GetIdOfPart(worksheetPart), SheetId = 1, Name = "Sheet1" });
                    var sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();
                    if (data.managerUserAccess.Count > 0)
                    {
                        var columnList = data.managerUserAccess[0].GetType().GetProperties().Where(r => r.Name != "EmpId").Select(k => k).ToList();
                        Row rowHeader = GetHeaderRow(columnList);
                        sheetData.Append(rowHeader);
                        Row[] rowData = GetRecordRows(data, columnList, sheetData, null);
                    }
                    spreadsheetDocument.Dispose();
                }
                stream.Position = 0;
                return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "data.xlsx");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        private Row GetHeaderRow(List<PropertyInfo> columnList)
        {
            try
            {
                Row row = new Row() { RowIndex = 1 };
                int i = 65;

                foreach (PropertyInfo property in columnList)
                {
                    CellValues value1 = CellValues.String;
                    if (property.PropertyType == typeof(int))
                        value1 = CellValues.Number;
                    else if (property.PropertyType == typeof(DateTime))
                        value1 = CellValues.Date;
                    char c = Convert.ToChar(i);
                    string cellRef = c.ToString() + "1";
                    if (i == 91)
                        cellRef = "AA1";
                    if (i == 92)
                        cellRef = "AB1";
                    if (i == 93)
                        cellRef = "AC1";
                    if (i == 94)
                        cellRef = "AD1";
                    if (i == 95)
                        cellRef = "AE1";
                    if (i == 96)
                        cellRef = "AF1";
                    if (i == 97)
                        cellRef = "AG1";
                    if (i == 98)
                        cellRef = "AH1";
                    if (i == 99)
                        cellRef = "AI1";
                    if (i == 100)
                        cellRef = "AJ1";
                    if (i == 101)
                        cellRef = "AK1";
                    if (i == 102)
                        cellRef = "AL1";
                    if (i == 103)
                        cellRef = "AM1";
                    if (i == 104)
                        cellRef = "AN1";
                    if (i == 105)
                        cellRef = "AO1";
                    if (i == 106)
                        cellRef = "AP1";
                    if (i == 107)
                        cellRef = "AQ1";
                    if (i == 108)
                        cellRef = "AR1";
                    if (i == 109)
                        cellRef = "AS1";
                    if (i == 110)
                        cellRef = "AT1";

                    string ColumnName = GetDisplayName(property);
                    Cell header1 = new Cell() { CellReference = cellRef, CellValue = new CellValue(ColumnName), DataType = CellValues.String };//value1
                    row.Append(header1);
                    i = i + 1;
                }
                return row;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string GetDisplayName(PropertyInfo property)
        {
            string columnName = String.Empty;
            bool isDisplayNameAttributeDefined = false;
            isDisplayNameAttributeDefined = Attribute.IsDefined(property, typeof(DisplayNameAttribute));

            if (isDisplayNameAttributeDefined)
            {
                DisplayNameAttribute dna = (DisplayNameAttribute)Attribute.GetCustomAttribute(property, typeof(DisplayNameAttribute));
                if (dna != null)
                    columnName = dna.DisplayName;
            }
            else
                columnName = property.Name;


            isDisplayNameAttributeDefined = false;
            return columnName;
        }

        private Row[] GetRecordRows(MDMManagerAccessSearchResult data, List<PropertyInfo> columnList, SheetData sheetData, Stylesheet stylesheet)
        {
            List<Row> rows = new List<Row>();
            UInt32Value rowIndex = 2;

            foreach (MDMManagerAccessResult objExp in data.managerUserAccess)
            {
                int i = 65;
                Row row = new Row() { RowIndex = rowIndex };
                foreach (PropertyInfo property in columnList)
                {
                    string valueobj = null;
                    valueobj = property.GetValue(objExp, null)?.ToString();
                    CellValues value1 = CellValues.String;
                    if (property.PropertyType == typeof(int))
                    {
                        valueobj = property.GetValue(objExp)?.ToString();
                        value1 = CellValues.Number;
                    }
                    else if (property.PropertyType == typeof(DateTime))
                    {
                        valueobj = property.GetValue(objExp)?.ToString();
                        value1 = CellValues.Date;
                    }
                    char c = Convert.ToChar(i);
                    string cellRef = c.ToString() + rowIndex.ToString();

                    if (i == 91)
                        cellRef = "AA" + rowIndex.ToString();
                    if (i == 92)
                        cellRef = "AB" + rowIndex.ToString();
                    if (i == 93)
                        cellRef = "AC" + rowIndex.ToString();
                    if (i == 94)
                        cellRef = "AD" + rowIndex.ToString();
                    if (i == 95)
                        cellRef = "AE" + rowIndex.ToString();
                    if (i == 96)
                        cellRef = "AF" + rowIndex.ToString();
                    if (i == 97)
                        cellRef = "AG" + rowIndex.ToString();
                    if (i == 98)
                        cellRef = "AH" + rowIndex.ToString();
                    if (i == 99)
                        cellRef = "AI" + rowIndex.ToString();
                    if (i == 100)
                        cellRef = "AJ" + rowIndex.ToString();
                    if (i == 101)
                        cellRef = "AK" + rowIndex.ToString();
                    if (i == 102)
                        cellRef = "AL" + rowIndex.ToString();
                    if (i == 103)
                        cellRef = "AM" + rowIndex.ToString();
                    if (i == 104)
                        cellRef = "AN" + rowIndex.ToString();
                    if (i == 105)
                        cellRef = "AO" + rowIndex.ToString();
                    if (i == 106)
                        cellRef = "AP" + rowIndex.ToString();
                    if (i == 107)
                        cellRef = "AQ" + rowIndex.ToString();
                    if (i == 108)
                        cellRef = "AR" + rowIndex.ToString();
                    if (i == 109)
                        cellRef = "AS" + rowIndex.ToString();
                    if (i == 110)
                        cellRef = "AT" + rowIndex.ToString();

                    CellFormat textCellFormat = new CellFormat()
                    {
                        NumberFormatId = 49, // Number format for text
                        ApplyNumberFormat = true
                    };

                    Cell rowline = null;
                    if (property.PropertyType == typeof(int))
                    {
                        rowline = new Cell() { CellReference = cellRef, CellValue = new CellValue(Convert.ToInt32(property.GetValue(objExp)?.ToString())), DataType = value1 };
                    }
                    else if (property.PropertyType == typeof(DateTime))
                    {
                        rowline = new Cell() { CellReference = cellRef, CellValue = new CellValue(Convert.ToDateTime(property.GetValue(objExp)?.ToString())), DataType = value1 };
                    }
                    else
                    {
                        rowline = new Cell() { CellReference = cellRef, CellValue = new CellValue(property.GetValue(objExp)?.ToString()), DataType = value1 };

                        if (property.Name == "EmpId")
                        {

                        }
                    }
                    row.Append(rowline);
                    i = i + 1;
                }
                rows.Add(row);
                sheetData.Append(row);
                rowIndex = rowIndex + 1;
            }
            return rows.ToArray();
        }
        #endregion
    }
}