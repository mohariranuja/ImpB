﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenericPopupController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public GenericPopupController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================


        [HttpPost("getRegionFilterData")]
        public async Task<ApiResponse<GenericMastersSearchResult>> GetRegionFilterData(SearchPagingRequest request)
        {

            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<MDMRegion, bool>> filterData = getMDMRegionFilterResult(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.GenericPopupSearchResultList.GetManyAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }

        [HttpPost("getDivisionFilterData")]
        public async Task<ApiResponse<GenericMastersSearchResult>> getDivisionFilterData(SearchPagingRequest request)
        {

            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<EmployeeMaster, bool>> filterData = getFilterResultEmployeeMaster(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.GenericPopupSearchResultList.GetManyDivisionAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }

        [HttpPost("getProductlineFilterData")]
        public async Task<ApiResponse<GenericMastersSearchResult>> getProductlineFilterData(SearchPagingRequest request)
        {

            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<ProductLine, bool>> filterData = getFilterResultProductLines(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.ProductLinesSearchResultList.GetManyProductLinesAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }

        [HttpPost("getMDMLegalEntityFilterData")]
        public async Task<ApiResponse<GenericMastersSearchResult>> getMDMLegalEntityFilterData(SearchPagingRequest request)
        {

            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<MDMLegalEntity, bool>> filterData = getFilterResultMDMLegalEntity(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.MDMLegalEntitiesSearchRepository.GetManyMDMLegalEntityAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }
       

        [HttpPost("getSubProductlineFilterData")]
        public async Task<ApiResponse<GenericMastersSearchResult>> getSubProductlineFilterData(SearchPagingRequest request)
        {

            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<SubProductLine, bool>> filterData = getFilterResultSubProductLines(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.SubProductLinesSearchResultList.GetManySubProductLineAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }

        [HttpPost("getDepartmentFilterData")]
        public async Task<ApiResponse<GenericMastersSearchResult>> getDepartmentFilterData(SearchPagingRequest request)
        {

            var apiResponse = new ApiResponse<GenericMastersSearchResult>();
            Expression<Func<Department, bool>> filterData = getFilterResultDepartment(request)!;
            int? top = null;
            int? skip = null;
            if (request.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (request.START_INDEX == 0 && request.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (request.START_INDEX == 0 && request.PAGE_SIZE > 0)
            {
                top = request.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = request.PAGE_SIZE;
                skip = (request.START_INDEX - 1) * request.PAGE_SIZE;
            }

            var data = await _unitOfWork.DepartmentsSearchResultList.GetManyDepartAsync(filterData, null, top, skip);



            apiResponse.Result = data;
            apiResponse.Success = true;


            if (apiResponse.Result.genericMasterResultList.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;

        }

        
             [NonAction]
        internal Expression<Func<MDMLegalEntity, bool>>? getFilterResultMDMLegalEntity(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<MDMLegalEntity, bool>>> obList = new List<Expression<Func<MDMLegalEntity, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<MDMLegalEntity>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<MDMLegalEntity>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        [NonAction]
        internal Expression<Func<ProductLine, bool>>? getFilterResultProductLines(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<ProductLine, bool>>> obList = new List<Expression<Func<ProductLine, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<ProductLine>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<ProductLine>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }
        [NonAction]
        internal Expression<Func<SubProductLine, bool>>? getFilterResultSubProductLines(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<SubProductLine, bool>>> obList = new List<Expression<Func<SubProductLine, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<SubProductLine>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<SubProductLine>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }


        [NonAction]
        internal Expression<Func<MDMRegion, bool>>? getMDMRegionFilterResult(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<MDMRegion, bool>>> obList = new List<Expression<Func<MDMRegion, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<MDMRegion>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<MDMRegion>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        [NonAction]
        internal Expression<Func<EmployeeMaster, bool>>? getFilterResultEmployeeMaster(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<EmployeeMaster, bool>>> obList = new List<Expression<Func<EmployeeMaster, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<EmployeeMaster>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<EmployeeMaster>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        [NonAction]
        internal Expression<Func<Department, bool>>? getFilterResultDepartment(SearchPagingRequest request)
        {
            if (request.filterDetails != null && request.filterDetails.Count > 0)
            {
                List<Expression<Func<Department, bool>>> obList = new List<Expression<Func<Department, bool>>>();

                foreach (var kvp in request.filterDetails)
                {
                    obList.Add(FilterHelper<Department>.getFilter(kvp));
                }

                var combinedFilter = FilterHelper<Department>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        
        #endregion
    }
}
