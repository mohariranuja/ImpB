﻿using eDMS.Api.Middleware;
using eDMS.Api.Models;
using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;

namespace eDMS.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IncidentValuesController : ControllerBase
    {
        #region ===[ Private Members ]=============================================================
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region ===[ Constructor ]=================================================================
        /// <summary>
        /// Initialize VPTypeController by injecting an object type of IUnitOfWork
        /// </summary>
        public IncidentValuesController(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
        #endregion

        #region ===[ Public Methods ]==============================================================
        [HttpGet]
        public async Task<ApiResponse<List<MDMIncidentValue>>> GetAll()
        {
            var apiResponse = new ApiResponse<List<MDMIncidentValue>>();
            var data = await _unitOfWork.IncidentValues.GetAllAsync();
            apiResponse.Success = true;
            apiResponse.Result = data.ToList();

            if (apiResponse.Result.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [HttpGet("GetById/{id}")]
        public async Task<ApiResponse<MDMIncidentValue>> GetById(int id)
        {
            if (id <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<MDMIncidentValue>();
            var data = await _unitOfWork.IncidentValues.GetByIdAsync(id);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByIncidentTypeId/{incidentTypeId}")]
        public async Task<ApiResponse<List<MDMIncidentValue>>> GetByIncidentTypeId(int incidentTypeId)
        {
            if (incidentTypeId <= 0)
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }
            var apiResponse = new ApiResponse<List<MDMIncidentValue>>();
            var data = await _unitOfWork.IncidentValues.GetByIncidentTypeIdAsync(incidentTypeId);
            apiResponse.Success = true;
            apiResponse.Result = data;

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }

        [HttpGet("GetByType/{type}")]
        public async Task<ApiResponse<MDMIncidentValue>> GetByType(string type)
        {
            if (string.IsNullOrEmpty(type))
            {
                throw new DMSException(CommonMessages.InputIDErrorMessage);
            }

            var apiResponse = new ApiResponse<MDMIncidentValue>();
            var data = await _unitOfWork.IncidentValues.GetAllAsync();

            apiResponse.Success = true;
            apiResponse.Result = type == eDMSConstant.defaultIncidentValue ? data.Where(w => w.IncidentValue == type).FirstOrDefault()
                : data.Where(w => w.IncidentValue == type && w.IsActiveIncidentValue == true).FirstOrDefault();

            if (apiResponse.Result == null)
                throw new DMSException(CommonMessages.GetErrorMessage);

            return apiResponse;
        }
        
        //[HttpPost]
        //public async Task<ApiResponse<int>> Add(MDMIncidentValue mdmIncidentValue)
        //{
        //    var apiResponse = new ApiResponse<int>();
        //    if (mdmIncidentValue == null)
        //        throw new DMSException(CommonMessages.InvalidModelMessage);


        //    var data = await _unitOfWork.IncidentTypeValues.SaveAsync(mdmIncidentValue);
        //    apiResponse.Success = true;
        //    apiResponse.Result = data;
        //    apiResponse.Message = CommonMessages.AddSuccessMessage;

        //    if (apiResponse.Result == 0)
        //        throw new DMSException(CommonMessages.AddErrorMessage);

        //    return apiResponse;
        //}

        [HttpPost("getIncidentValues")]
        public async Task<ApiResponse<IncidentsSearchResponce>> GetIncidentValues(IncidentSearchRequest incidentSearchRequest)
        {
            int? top = null;
            int? skip = null;
            var apiResponse = new ApiResponse<IncidentsSearchResponce>();
            Expression<Func<MDMIncidentValue, bool>> filterData = getIncidentFilterData(incidentSearchRequest)!;
            if (incidentSearchRequest.START_INDEX == 0)
            {
                top = null;
                skip = null;
            }
            if (incidentSearchRequest.START_INDEX == 0 && incidentSearchRequest.PAGE_SIZE == 0)
            {
                top = null;
                skip = null;
            }
            else if (incidentSearchRequest.START_INDEX == 0 && incidentSearchRequest.PAGE_SIZE > 0)
            {
                top = incidentSearchRequest.PAGE_SIZE;
                skip = null;
            }
            else
            {
                top = incidentSearchRequest.PAGE_SIZE;
                skip = (incidentSearchRequest.START_INDEX - 1) * incidentSearchRequest.PAGE_SIZE;
            }

            var data = await _unitOfWork.IncidentSearchList.GetManyAsync(filterData, null, incidentSearchRequest.IncidentTypeId, top, skip);
            apiResponse.Result = data;
            apiResponse.Success = true;

            if (apiResponse.Result.IncidentSearchResponces.Count == 0)
                throw new DMSException(CommonMessages.GetErrorMessage);
            return apiResponse;
        }

        [NonAction]
        internal Expression<Func<MDMIncidentValue, bool>>? getIncidentFilterData(IncidentSearchRequest incidentSearchRequest)
        {
            if (incidentSearchRequest.filterDetails != null && incidentSearchRequest.filterDetails.Count > 0)
            {
                List<Expression<Func<MDMIncidentValue, bool>>> obList = new List<Expression<Func<MDMIncidentValue, bool>>>();
                foreach (var kvp in incidentSearchRequest.filterDetails)
                {
                    obList.Add(FilterHelper<MDMIncidentValue>.getFilter(kvp));
                }
                var combinedFilter = FilterHelper<MDMIncidentValue>.CombineFilters(obList);
                return combinedFilter;
            }
            return null;
        }

        //[HttpPut]
        //public async Task<ApiResponse<int>> Update(MDMIncidentValue mdmIncidentTypeValue)
        //{
        //    var apiResponse = new ApiResponse<int>();
        //    if (mdmIncidentTypeValue == null)
        //        throw new DMSException(CommonMessages.InvalidModelMessage);
        //    try
        //    {
        //        var data = await _unitOfWork.IncidentTypeValues.SaveAsync(mdmIncidentTypeValue);
        //        apiResponse.Success = true;
        //        apiResponse.Result = data;
        //        apiResponse.Message = CommonMessages.UpdateSuccessMessage;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
            
        //    if (apiResponse.Result == 0)
        //        throw new DMSException(CommonMessages.UpdateErrorMessage);
        //    return apiResponse;
        //}
        //[HttpDelete]
        //public async Task<ApiResponse<int>> Delete(int id)
        //{
        //    if (id <= 0)
        //        throw new DMSException(CommonMessages.InputIDErrorMessage);

        //    var apiResponse = new ApiResponse<int>();
        //    var data = await _unitOfWork.IncidentTypeValues.DeleteAsync(id);
        //    apiResponse.Success = true;
        //    apiResponse.Result = data;
        //    apiResponse.Message = CommonMessages.DeletedSuccessMessage;

        //    if (apiResponse.Result == 0)
        //        throw new DMSException(CommonMessages.DeleteErrorMessage);

        //    return apiResponse;
        //}
        #endregion
    }
}
