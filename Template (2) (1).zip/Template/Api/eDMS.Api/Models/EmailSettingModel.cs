﻿namespace eDMS.Api.Models
{
    public class EmailSettingModel
    {
        public class EMailSettings
        {
            public string? smtpServer { get; set; }
            public int smtpPort { get; set; }
        }

    }
}
