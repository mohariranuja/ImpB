﻿using System;

public class ResponseModel
{
    public int responseCode { get; set; }
    public string responseMessage { get; set; }

}

