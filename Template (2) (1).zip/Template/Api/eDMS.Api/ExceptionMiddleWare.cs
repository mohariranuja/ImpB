﻿using eDMS.Api.Middleware;
using Microsoft.JSInterop;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Text.Json;
using log4net;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    //private readonly ILogger<ExceptionHandlingMiddleware> _logger;
   private readonly ILog log;
    public ExceptionHandlingMiddleware(RequestDelegate next,ILog log )//ILogger<ExceptionHandlingMiddleware> logger
    {
        //  log = LogManager.GetLogger(typeof(Program));
        this.log = log;
        _next = next;
       // _logger = logger;
    }

    public async Task InvokeAsync(HttpContext httpContext)
    {
        try
        {
           // if (log.IsDebugEnabled)
             log.Info("test Info");
            log.Error("test error");
            //if ( _logger.IsEnabled(LogLevel.Information))
            //    _logger.LogInformation("Inside");
            await _next(httpContext);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(httpContext, ex);
        }
    }
    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        context.Response.ContentType = "application/json";
        var response = context.Response;

        var errorResponse = new ResponseModel();

        switch (exception)
        {
            case DMSException ex:
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                errorResponse.responseMessage = ex.Message;
                errorResponse.responseCode = (int)HttpStatusCode.InternalServerError;
                break;

            //case ApplicationException ex:
            //    if (ex.Message.Contains("Invalid token"))
            //    {
            //        response.StatusCode = (int)System.Net.HttpStatusCode.Forbidden;
            //        errorResponse.responseMessage = ex.Message;
            //        errorResponse.responseCode = (int)System.Net.HttpStatusCode.Forbidden;
            //        break;
            //    }
            //    response.StatusCode = (int)HttpStatusCode.BadRequest;
            //    errorResponse.responseMessage = ex.Message;
            //    errorResponse.responseCode = (int)HttpStatusCode.BadRequest;
            //    break;
            //case KeyNotFoundException ex:
            //    response.StatusCode = (int)HttpStatusCode.NotFound;
            //    errorResponse.responseMessage = ex.Message;
            //    errorResponse.responseCode = (int)HttpStatusCode.NotFound;
            //    break;
            //case SqlException ex:
            //    response.StatusCode = (int)HttpStatusCode.InternalServerError;
            //    errorResponse.responseMessage = ex.Message;
            //    errorResponse.responseCode = (int)HttpStatusCode.InternalServerError;
            //    break;
            default:
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                errorResponse.responseMessage = "Internal Server errors. Check Logs!";
                errorResponse.responseCode = (int)HttpStatusCode.InternalServerError;
                break;
        }
        if (exception.InnerException != null)
            log.Error(exception.InnerException.Message);
        log.Error(exception.StackTrace);
        log.Error(exception.Message);
      //  _logger.LogError(exception.Message);
        var result = JsonSerializer.Serialize(errorResponse);
        await context.Response.WriteAsync(result);
    }
}

