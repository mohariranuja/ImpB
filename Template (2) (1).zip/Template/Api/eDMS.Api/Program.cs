using eDMS.Api;
using eDMS.Infrastructure;
using eDMS.Infrastructure.Persistence;
using log4net.Config;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using static eDMS.Core.Entities.EmailSettingModel;

var builder = WebApplication.CreateBuilder(args);
string baseAddress = builder.Configuration["appConfigurations:basePolicy"];
//builder.Logging.ClearProviders();
//builder.Logging.AddLog4Net();

//object value = builder.Logging.AddLog4Net();
XmlConfigurator.Configure(new FileInfo("log4net.config"));
var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

//Injecting services.
builder.Services.RegisterServices();
// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddPersistence(builder.Configuration);
builder.Services.AddLog4net();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddDbContext<ApplicationDBContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DBConnection"),
                b => b.MigrationsAssembly(typeof(ApplicationDBContext).Assembly.FullName)), ServiceLifetime.Transient);

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      policy =>
                      {
                          policy.WithOrigins(baseAddress).AllowAnyHeader().AllowAnyMethod();
                      });
});

builder.Services.AddSwaggerGen(c =>
{
    c.EnableAnnotations();
    c.AddSecurityDefinition("basic", new OpenApiSecurityScheme
    {
        Description = "api key.",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "basic"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "basic"
                },
                In = ParameterLocation.Header
            },
            new List<string>()
        }
    });
});

//configure the EMailsettings
builder.Services.Configure<EMailSettings>(builder.Configuration.GetSection("EmailSettings"));
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseCors(MyAllowSpecificOrigins);
app.MapControllers();

app.Run();