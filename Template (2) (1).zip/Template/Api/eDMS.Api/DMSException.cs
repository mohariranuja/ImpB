﻿using System;
using System.Runtime.Serialization;

namespace eDMS.Api.Middleware
{
    [Serializable]
    public class DMSException : Exception
    {        

        public DMSException(string message) : base(message)
        {

        }
        public DMSException(string message, Exception innerException) : base(message,innerException)
        {

        }
        public DMSException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

    }

}
