﻿using eDMS.Application.Interfaces;
using eDMS.Application.Interfaces.TOBEDeleted;
using eDMS.Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace eDMS.Infrastructure
{
    public static class ServiceCollectionExtension
    {
        public static void RegisterServices(this IServiceCollection services)
        {
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddTransient<ICountryListRepository, CountryListRepository>(); 
            services.AddTransient<ICountryRepository, CountryRepository>();
            services.AddTransient<IDriversSearchResultListRepository, DriverSearchResultListRepository>();
            services.AddTransient<IDriverLicenseRepository, DriverLicenseRepository>();
            services.AddTransient<IBusinessUnitSearchRepository, BusinessUnitSearchRepository>();
            services.AddTransient<IDriverRiskListRepository, DriverRiskListRepository>();
            services.AddTransient<IDriverBehaviourRiskViewRepository, DriverBehaviourRiskViewRepository>();
            services.AddTransient<ILocationSearchRepository, LocationSearchRepository>();
            services.AddTransient<ILocationRepository, LocationRepository>();
            services.AddTransient<IDriversBehaviourRiskRepository, DriversBehaviourRiskRepository>();
          
            services.AddTransient<IDriverRiskRepository, DriverRisksRepository>();
           
        }
    }
}