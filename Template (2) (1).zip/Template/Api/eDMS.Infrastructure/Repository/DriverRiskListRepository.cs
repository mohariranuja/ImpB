﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DriverRiskListRepository : IDriverRiskListRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriverRiskListRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IDriverRiskRepository Methods ]==================================================
        async Task<IReadOnlyList<DriverRiskList>> IDriverRiskListRepository.GetManyAsync(int id)
        {
            return await _dbContext.DriverRiskLists.FromSqlInterpolated<DriverRiskList>($" {StoreProc.Sp_DriverRiskInfo} {id}").ToListAsync();
        }

        public async Task<int> SaveAsync(DriverRiskList driverRisk)
        {
            var result = _dbContext.DriverRiskLists.AsNoTracking().Where(w => w.DriverRiskId == driverRisk.DriverRiskId
                                                            ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DriverRiskLists.Add(driverRisk);
            }
            else
            {
                _dbContext.DriverRiskLists.Update(driverRisk);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}