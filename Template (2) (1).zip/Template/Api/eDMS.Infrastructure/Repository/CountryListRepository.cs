﻿using EverestVPS.Core.Entities;
using Microsoft.Extensions.Configuration;
using System.Data;
using Microsoft.EntityFrameworkCore;
using eDMS.Application;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class CountryListRepository : ICountryListRepository
    {
        #region ===[ Private Members ]=============================================================

       
        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public CountryListRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
           
        }

        #endregion
        #region ===[ ICountryListRepository Methods ]==================================================

       

        async Task<IReadOnlyList<CountryList>> ICountryListRepository.GetManyAsync(CountryRequest request)
        {
            return await _dbContext.CountryLists.FromSqlInterpolated<CountryList>($" {StoreProc.Sp_GetCountryList} {request.SEARCH_TEXT} ,{request.SORT_COLUMN_NAME},{request.SORT_COLUMN_DIRECTION} ,{request.START_INDEX},{request.PAGE_SIZE}").ToListAsync();
            // return await _dbContext.CountryLists.FromSqlInterpolated<CountryList>($" {StoreProc.Sp_GetCountryList} {request.CountryId} ,{request.RegionId}").ToListAsync();
        }

        public async Task<GenericMastersSearchResult> GetManyAsync1(
        Expression<Func<Country, bool>> filter = null,
        Func<IQueryable<Country>, IOrderedQueryable<Country>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<Country> query = _dbContext.Countries.Where(x=>x.CountryName!="NA");

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            //if (orderBy != null)
            //{
            //    query = orderBy(query);
            //}

            //if (skip.HasValue)
            //{
            //    query = query.Skip(skip.Value);
            //}

            //if (top.HasValue)
            //{
            //    query = query.Take(top.Value);
            //}

            //return await query.ToListAsync();
            IQueryable<Country> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var pagesitem = await query.ToListAsync();
            var genericMasterResultList = new List<GenericMasterResult>();
            foreach (Country regMaster in pagesitem)
            {
                var list1 = new GenericMasterResult { CountryCode = regMaster.CountryCode, CountryName = regMaster.CountryName, CountryId= regMaster.CountryId };
                genericMasterResultList.Add(list1);
            }

            GenericMastersSearchResult result = new GenericMastersSearchResult();
            result.TotalCount = countSearch;
            result.genericMasterResultList = genericMasterResultList;
            return result;
        }



        #endregion
    }
}
