﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace eDMS.Infrastructure.Repository
{
    public class DriversBehaviourRiskRepository : IDriversBehaviourRiskRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriversBehaviourRiskRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IManagerSearchRepository Methods ]==================================================
        public async Task<DriversBehaviourRiskResult> GetManyAsync(bool isCommendationType, int employeeId,
            int? top = null, int? skip = null, params string[] includeProperties)
        {
            //IncodentId for commendation type.
            int? incidentTypeId = (_dbContext.MDMIncidentTypes.Where(w => w.IsCommendationType == true)?.FirstOrDefault()?.IncidentTypeId);

            IQueryable<DriverBehaviourRiskView> query = (!isCommendationType) ?
                _dbContext.DriverBehaviourRiskViews.Where(x => x.EmployeeId == employeeId &&
                x.IsActive == true && x.IncidentTypeId != incidentTypeId).OrderByDescending(x => x.DriverBehaviourId)
            : _dbContext.DriverBehaviourRiskViews.Where(x => x.EmployeeId == employeeId &&
            x.IsActive == true && x.IncidentTypeId == incidentTypeId).OrderByDescending(x => x.DriverBehaviourId);

            var riskIndex = _dbContext.MDMRiskIndexes;

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }
            int countSearch = query.Count();

            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }
            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var driverBehaviourList = await query.ToListAsync();

            var managerSearchResultList = new List<DriverBehaviourRiskResult>();
            managerSearchResultList.AddRange(driverBehaviourList.ConvertAll(x => new DriverBehaviourRiskResult()
            {
                DriverBehaviourId = x.DriverBehaviourId,
                EmpId = x.EmpId,
                EmployeeId = x.EmployeeId,
                Date1 = x.Date1,
                Time_Entered = x.Time_Entered,
                IncidentTypeId = x.IncidentTypeId,
                IncidentType = x.IncidentType,
                IncidentValueId = x.IncidentValueId,
                IncidentValue = x.IncidentValue,
                ViolationValueId = x.ViolationValueId,
                ViolationValue = x.ViolationValue,
                IsActive = x.IsActive,
                RiskIndex = riskIndex?.Where(r => r.RiskIndexId == x.RiskIndexId)?.FirstOrDefault()?.RiskIndex, //x.RiskIndex,
                RiskIndexId = x.RiskIndexId,
                Descr200 = x.Descr200,
                DescrLong_Notes = x.DescrLong_Notes,
                Date2 = x.Date2,
                TIME_RECORDED = x.Time_Recorded,
                EFFDate = x.EFFDate,
                TIME_EDIT = x.Time_Edit,
                CreatedBy = x.CreatedBy,
                CreatedOn = x.CreatedOn,
                ModifiedBy = x.ModifiedBy,
                ModifiedOn = x.ModifiedOn
            }));
            DriversBehaviourRiskResult result = new DriversBehaviourRiskResult();
            result.TotalCount = countSearch;
            result.driverBehaviourRiskResult = managerSearchResultList;
            return result;
        }

        public async Task<string> GetBehaviorAsyncResult(string emplId, string regionId)
        {
            string result = string.Empty;

            var sql = $"EXEC YourStoredProcedure @InputParam, @OutputParam OUTPUT";
            // Execute the raw SQL query with output parameter
            // Use the output value as needed

            var paramName = new SqlParameter("@returnValue", SqlDbType.NVarChar, 100)
            {
                Direction = ParameterDirection.Output
            };
            _dbContext.Database.ExecuteSqlInterpolated($"EXEC RiskIndexCalculation_Final1 {emplId},{regionId}, {paramName} OUTPUT");

            //Access the output parameter value
            var outputValue = paramName.Value;
            // string @returnValue = string.Empty;

            // var driverRiskResult = await _dbContext.DriverBehaviorRiskResults.FromSqlInterpolated($" {StoreProc.Sp_GetDriverBehaviorRisk} {emplId},{regionId},{paramName} OUTPUT").ToListAsync<DriverBehaviorRiskResult>();
            // Access the output parameter value
            //  var outputValue1 = paramName.Value.ToString();
            // Use the output value as needed
            result = outputValue.ToString();

            return result;
        }

        public async Task<string> GetBehaviorConsoleAsyncResult(string emplId)
        {
            string result = string.Empty;

            var sql = $"EXEC YourStoredProcedure @InputParam, @OutputParam OUTPUT";
            // Execute the raw SQL query with output parameter
            // Use the output value as needed

            var paramName = new SqlParameter("@returnValue", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Output
            };
            _dbContext.Database.ExecuteSqlInterpolated($"EXEC {StoreProc.sp_GetRiskCalculationConsole} {emplId}, {paramName} OUTPUT");

            //Access the output parameter value
            var outputValue = paramName.Value;
           
            result = outputValue.ToString();

            return result;
        }
        #endregion
    }
}