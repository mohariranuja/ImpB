﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class ManagerSearchRepository : IManagerSearchRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public ManagerSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region ===[ IManagerSearchRepository Methods ]==================================================
        public async Task<ManagersSearchResult> GetManyAsync(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(x=>x.ManagerCode!="-1");
            //query= query.Join(EmployeeMaster => empMaster,
            //        EmployeeMaster => emp.empId,
            //        (person, pet) =>
            //            new { OwnerName = person.Name, Pet = pet.Name }); )

            


            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            //IQueryable<ManagerSearchResult> employees =
            //    from m in query
            //    join e1 in query on m.ManagerId equals e1.EmpId
            //    select new ManagerSearchResult
            //    {
            //        EmpId = m.EmpId,
            //        FirstName = m.FirstName,
            //        LastName = m.LastName,
            //        ManagerId=m.ManagerId,
            //        ManagerName = e1.FirstName +' '+ e1.LastName//,
            //        //LocationDescription=m.LocationDescription,
            //        //MiddleName=m.MiddleName,
            //        //AlternateName=m.Al

            //        //Designation = m.Designation,
            //        //Phone = m.Phone,
            //        //Address = m.Address
            //    };
           // query = employees;

            var employeeMasterList = await query.ToListAsync();
            var managerSearchResultList = new List<ManagerSearchResult>();

            foreach (EmployeeMaster empMaster in employeeMasterList)
            {
                var managerList = new ManagerSearchResult {EmpId=empMaster.EmpId, FirstName = empMaster.FirstName, LastName = empMaster.LastName, ManagerCode = empMaster.ManagerCode, ManagerName=empMaster.ManagerName };
                managerSearchResultList.Add(managerList);
            }
            ManagersSearchResult result = new ManagersSearchResult();
            result.TotalCount = countSearch;
            result.managerSearchResult = managerSearchResultList;
            return result;
            // return await query.ToListAsync();
        }

        public async Task<ManagersSearchResult> GetManyApproversAsync(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters;
            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var employeeMasterList = await query.ToListAsync();
            var managerSearchResultList = new List<ManagerSearchResult>();

            foreach (EmployeeMaster empMaster in employeeMasterList)
            {
                var managerList = new ManagerSearchResult { EmpId = empMaster.EmpId, EmplId = empMaster.EmplId, FirstName = empMaster.FirstName, LastName = empMaster.LastName, ManagerCode = empMaster.ManagerCode, ManagerName = empMaster.ManagerName };
                managerSearchResultList.Add(managerList);
            }
            ManagersSearchResult result = new ManagersSearchResult();
            result.TotalCount = countSearch;
            result.managerSearchResult = managerSearchResultList;
            return result;
            // return await query.ToListAsync();
        }

        //public async Task<GenericMastersSearchResult> GetManyBusinessUnitAsync(
        //Expression<Func<EmployeeMaster, bool>> filter = null,
        //Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        //int? top = null,
        //int? skip = null,
        //params string[] includeProperties)
        //{
        //    IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(h => h.BusinessUnitDescription != null);             

        //    // IQueryable<EmployeeMaster> query = (IQueryable<EmployeeMaster>)_dbContext.EmployeeMasters.Distinct<EmployeeMaster>().Select(x=>new  {x.BusinessUnit,x.BusinessUnitDescription });
        //    //  IQueryable<EmployeeMaster> query = (IQueryable<EmployeeMaster>)_dbContext.EmployeeMasters.Distinct<EmployeeMaster>(y=>y.).Select(x => new { x.BusinessUnit, x.BusinessUnitDescription });


        //    if (filter != null)
        //    {
        //        query = query.Where(filter);
        //    }
        //    query = query.GroupBy(x => x.BusinessUnit).Select(y => y.OrderByDescending(d => d.BusinessUnit).First());

        //    if (includeProperties.Length > 0)
        //    {
        //        query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
        //    }

        //    if (orderBy != null)
        //    {
        //        query = orderBy(query);
        //    }
        //    IQueryable<EmployeeMaster> queryCount = query;
        //    var countItem = await queryCount.ToListAsync();
        //    int countSearch = countItem.Count;
        //    if (skip.HasValue)
        //    {
        //        query = query.Skip(skip.Value);
        //    }

        //    if (top.HasValue)
        //    {
        //        query = query.Take(top.Value);
        //    }
        //    var pagesitem = await query.ToListAsync();
        //    var genericMasterResultList = new List<GenericMasterResult>();
        //    foreach (EmployeeMaster empMaster in pagesitem)
        //    {
               
        //        var list1 = new GenericMasterResult { BusinessUnit = empMaster.BusinessUnit, BusinessUnitDescription = empMaster.BusinessUnitDescription };
        //        genericMasterResultList.Add(list1);
        //    }

        //    // var employeeMasterList = await query.ToListAsync();

        //    GenericMastersSearchResult result = new GenericMastersSearchResult();
        //    result.TotalCount = countSearch;
        //    result.genericMasterResultList = genericMasterResultList;
        //    return result;
        //    // return await query.ToListAsync();
        //}
        #endregion
    }
}