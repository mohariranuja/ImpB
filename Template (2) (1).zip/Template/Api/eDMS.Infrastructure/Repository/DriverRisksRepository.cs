﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DriverRisksRepository : IDriverRiskRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriverRisksRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion
        
        #region ===[ Public Methods ]=================================================================
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DriversRisk.Where(w => w.DriverRiskId == id
                                                           ).FirstOrDefault();

            if (result != null)
            {
                // result.IsActive= false;
                _dbContext.DriversRisk.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<IReadOnlyList<DriverRisks>> GetAllAsync()
        {
            return await _dbContext.DriversRisk.ToListAsync();
        }

        public async Task<DriverRisks> GetByIdAsync(int id)
        {
            return await _dbContext.DriversRisk.Where(w => w.DriverRiskId == id).FirstOrDefaultAsync();
        }

        public async Task<DriverRisks?> GetByDLRiskTypeAsync(int driverLicenseId, int riskTypeId)
        {
            return await _dbContext.DriversRisk.Where(w => w.DriverLicenseId == driverLicenseId
            && w.RiskTypeId == riskTypeId).FirstOrDefaultAsync();
        }

        public  async Task<int> SaveAsync(DriverRisks entity)
        {
            var result = _dbContext.DriversRisk.AsNoTracking().Where(w => w.DriverRiskId == entity.DriverRiskId
                                                            ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DriversRisk.Add(entity);
            }
            else
            {
                entity.ModifiedBy = 2;
                entity.ModifiedOn = DateTime.Now;
                _dbContext.DriversRisk.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}