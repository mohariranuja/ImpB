﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DispositionRepository : IDispositionRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public DispositionRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ ISubstanceRepository Methods ]==================================================
        public async Task<IReadOnlyList<Disposition>> GetAllAsync()
        {
            return await _dbContext.Dispositions.Where(r => r.IsActive == true).ToListAsync();
        }

        public async Task<Disposition> GetByIdAsync(int id)
        {
            return await _dbContext.Dispositions.Where(w => w.DispositionId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(Disposition disposition)
        {
            var result = _dbContext.Dispositions.AsNoTracking().Where(w => w.DispositionId == disposition.DispositionId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.Dispositions.Add(disposition);
            }
            else
            {
                _dbContext.Dispositions.Update(disposition);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.Dispositions.Where(w => w.DispositionId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.Dispositions.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}