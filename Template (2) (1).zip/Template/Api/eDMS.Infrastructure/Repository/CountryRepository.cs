﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class CountryRepository : ICountryRepository//,ICountryListRepository
    {
        #region ===[ Private Members ]=============================================================

       
        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public CountryRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion
        #region ===[ ICountryRepository Methods ]==================================================
        public async Task<IReadOnlyList<Country>> GetAllAsync()
        {
            return await _dbContext.Countries.ToListAsync();
        }

        public async Task<Country> GetByIdAsync(int id)
        {
            return await _dbContext.Countries.Where(w => w.CountryId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(Country country)
        {
            var result = _dbContext.Countries.AsNoTracking().Where(w => w.CountryId == country.CountryId
                                                            ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.Countries.Add(country);
            }
            else
            {
                _dbContext.Countries.Update(country);
            }
            return await _dbContext.SaveChangesAsync();
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.Countries.Where(w => w.CountryId == id
                                                           ).FirstOrDefault();

            if (result != null)
            {
               // result.IsActive= false;
                _dbContext.Countries.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public Task<IReadOnlyList<Country>> GetManyAsync(Expression<Func<Country, bool>> filter = null)
        {
            throw new NotImplementedException();
        }


        #endregion

        //async Task<IReadOnlyList<CountryList>> ICountryListRepository.GetManyAsync(CountryRequest request)
        //{
        //    return await _dbContext.CountryLists.FromSqlInterpolated<CountryList>($" {StoreProc.Sp_GetRateTemplateList} {request.CountryId} ,{request.RegionId}").ToListAsync();
        //}


        //public async Task<IEnumerable<Country>> GetManyAsync1(
        //Expression<Func<Country, bool>> filter = null,
        //Func<IQueryable<Country>, IOrderedQueryable<Country>> orderBy = null,
        //int? top = null,
        //int? skip = null,
        //params string[] includeProperties)
        //{
        //    IQueryable<Country> query = _dbContext.Countries;

        //    if (filter != null)
        //    {
        //        query = query.Where(filter);
        //    }

        //    if (includeProperties.Length > 0)
        //    {
        //        query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
        //    }

        //    if (orderBy != null)
        //    {
        //        query = orderBy(query);
        //    }

        //    if (skip.HasValue)
        //    {
        //        query = query.Skip(skip.Value);
        //    }

        //    if (top.HasValue)
        //    {
        //        query = query.Take(top.Value);
        //    }

        //    return await query.ToListAsync();
        //}


    }
}
