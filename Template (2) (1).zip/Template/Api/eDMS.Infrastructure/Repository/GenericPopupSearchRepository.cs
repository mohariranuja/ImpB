﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class GenericPopupSearchRepository :IGenericPopupSearchRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public GenericPopupSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ IGenericPopupSearchRepository Methods ]==================================================

      
      
       

        async Task<GenericMastersSearchResult> IGenericPopupSearchRepository.GetManyAsync(Expression<Func<MDMRegion, bool>> filter, Func<IQueryable<MDMRegion>, IOrderedQueryable<MDMRegion>> orderBy, int? top, int? skip, params string[] includeProperties)
        {
            
            IQueryable<MDMRegion> query = _dbContext.MdmRegions.Where(h=>h.RegionCode != null);
            query = query.Where(x => x.RegionCode != "UNKNOWN");


            if (filter != null)
            {
                query = query.Where(filter);
            }
            query = query.GroupBy(x => x.RegionName).Select(y => y.OrderByDescending(d => d.RegionName).First());


            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
              //  query = orderBy(query);
            }
            IQueryable<MDMRegion> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var pagesitem = await query.ToListAsync();
            var genericMasterResultList = new List<GenericMasterResult>();
            foreach (MDMRegion regMaster in pagesitem)
            {
                var list1 = new GenericMasterResult { Region = regMaster.RegionName, RegionCode = regMaster.RegionCode };
                genericMasterResultList.Add(list1);
            }

            GenericMastersSearchResult result = new GenericMastersSearchResult();
            result.TotalCount = countSearch;
            result.genericMasterResultList = genericMasterResultList;
            return result;
        }

        public async Task<GenericMastersSearchResult> GetManyDivisionAsync(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(h => h.Devision != null);




            if (filter != null)
            {
                query = query.Where(filter);
            }
            query = query.GroupBy(x => x.Devision).Select(y => y.OrderByDescending(d => d.Devision).First());

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var pagesitem = await query.ToListAsync();
            var genericMasterResultList = new List<GenericMasterResult>();
            foreach (EmployeeMaster empMaster in pagesitem)
            {

                var list1 = new GenericMasterResult { Devision = empMaster.Devision, DevisionDescription = empMaster.DevisionDescription };
                genericMasterResultList.Add(list1);
            }


            GenericMastersSearchResult result = new GenericMastersSearchResult();
            result.TotalCount = countSearch;
            result.genericMasterResultList = genericMasterResultList;
            return result;
            // return await query.ToListAsync();
        }

       // public async Task<GenericMastersSearchResult> GetManyProductlineAsync(
       // Expression<Func<EmployeeMaster, bool>> filter = null,
       // Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       // int? top = null,
       // int? skip = null,
       // params string[] includeProperties)
       // {
       //     IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(h => h.ProductLineDescription != null);




       //     if (filter != null)
       //     {
       //         query = query.Where(filter);
       //     }
       //     query = query.GroupBy(x => x.ProductLine).Select(y => y.OrderByDescending(d => d.ProductLine).First());

       //     if (includeProperties.Length > 0)
       //     {
       //         query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
       //     }

       //     if (orderBy != null)
       //     {
       //         query = orderBy(query);
       //     }
       //     IQueryable<EmployeeMaster> queryCount = query;
       //     var countItem = await queryCount.ToListAsync();
       //     int countSearch = countItem.Count;
       //     if (skip.HasValue)
       //     {
       //         query = query.Skip(skip.Value);
       //     }

       //     if (top.HasValue)
       //     {
       //         query = query.Take(top.Value);
       //     }
       //     var pagesitem= await query.ToListAsync();
       //     var genericMasterResultList = new List<GenericMasterResult>();
       //     foreach (ProductLine empMaster in pagesitem)
       //     {

       //         var list1 = new GenericMasterResult { ProductLineId = empMaster.ProductLineId, ProductLineDescription = empMaster.Description };
       //         genericMasterResultList.Add(list1);
       //     }


       //     GenericMastersSearchResult result = new GenericMastersSearchResult();
       //     result.TotalCount = countSearch;
       //     result.genericMasterResultList = genericMasterResultList;
       //     return result;
       //     // return await query.ToListAsync();
       // }

       // public async Task<GenericMastersSearchResult> GetManySubProductlineAsync(
       //Expression<Func<EmployeeMaster, bool>> filter = null,
       //Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       //int? top = null,
       //int? skip = null,
       //params string[] includeProperties)
       // {
       //     IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(h => h.SubProductLineDescription != null);




       //     if (filter != null)
       //     {
       //         query = query.Where(filter);
       //     }
       //     query = query.GroupBy(x => x.SubProductLine).Select(y => y.OrderByDescending(d => d.SubProductLine).First());

       //     if (includeProperties.Length > 0)
       //     {
       //         query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
       //     }

       //     if (orderBy != null)
       //     {
       //         query = orderBy(query);
       //     }
       //     IQueryable<EmployeeMaster> queryCount = query;
       //     var countItem = await queryCount.ToListAsync();
       //     int countSearch = countItem.Count;
       //     if (skip.HasValue)
       //     {
       //         query = query.Skip(skip.Value);
       //     }

       //     if (top.HasValue)
       //     {
       //         query = query.Take(top.Value);
       //     }
       //     var pagesitem = await query.ToListAsync();
       //     var genericMasterResultList = new List<GenericMasterResult>();
       //     foreach (EmployeeMaster empMaster in pagesitem)
       //     {

       //         var list1 = new GenericMasterResult { SubProductLine = empMaster.SubProductLine, SubProductLineDescription = empMaster.SubProductLineDescription };
       //         genericMasterResultList.Add(list1);
       //     }


       //     GenericMastersSearchResult result = new GenericMastersSearchResult();
       //     result.TotalCount = countSearch;
       //     result.genericMasterResultList = genericMasterResultList;
       //     return result;
       //     // return await query.ToListAsync();
       // }

        
       // public async Task<GenericMastersSearchResult> GetManyDepartAsync(
       //Expression<Func<EmployeeMaster, bool>> filter = null,
       //Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
       //int? top = null,
       //int? skip = null,
       //params string[] includeProperties)
       // {
       //     IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(h => h.DepartmentDescription != null);




       //     if (filter != null)
       //     {
       //         query = query.Where(filter);
       //     }
       //     query = query.GroupBy(x => x.DepartmentId).Select(y => y.OrderByDescending(d => d.DepartmentId).First());

       //     if (includeProperties.Length > 0)
       //     {
       //         query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
       //     }

       //     if (orderBy != null)
       //     {
       //         query = orderBy(query);
       //     }
       //     IQueryable<EmployeeMaster> queryCount = query;
       //     var countItem = await queryCount.ToListAsync();
       //     int countSearch = countItem.Count;
       //     if (skip.HasValue)
       //     {
       //         query = query.Skip(skip.Value);
       //     }

       //     if (top.HasValue)
       //     {
       //         query = query.Take(top.Value);
       //     }
       //     var pagesitem = await query.ToListAsync();
       //     var genericMasterResultList = new List<GenericMasterResult>();
       //     foreach (EmployeeMaster empMaster in pagesitem)
       //     {

       //         var list1 = new GenericMasterResult { DepartmentId = empMaster.DepartmentId, DepartmentDescription = empMaster.DepartmentDescription };
       //         genericMasterResultList.Add(list1);
       //     }


       //     GenericMastersSearchResult result = new GenericMastersSearchResult();
       //     result.TotalCount = countSearch;
       //     result.genericMasterResultList = genericMasterResultList;
       //     return result;
       //     // return await query.ToListAsync();
       // }

        #endregion
    }
}
