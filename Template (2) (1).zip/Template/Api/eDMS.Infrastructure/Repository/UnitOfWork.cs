﻿using eDMS.Application.Interfaces;
using eDMS.Application.Interfaces.TOBEDeleted;
using eDMS.Core.Entities;

namespace eDMS.Infrastructure.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(ICountryRepository _CountryRepository, ICountryListRepository _CountryListRepository,
          
            IDriversSearchResultListRepository _DriverSearchListRepository,
           
             IDriverRiskListRepository _DriverRiskList,
            IDriverBehaviourRiskViewRepository _DriverBehaviourRiskViews,
            IDriversBehaviourRiskRepository _DriversBehaviourRisks,

           IDriverLicenseRepository _DriverLicensesRepository,
            IDriverRiskRepository _DriverRisks,
            IBusinessUnitSearchRepository businessUnitsSearchResultList, ILocationSearchRepository _LocationSearchRepository
           )
        {
            Countries = _CountryRepository;
            CountryList = _CountryListRepository;
            DriverLicenses = _DriverLicensesRepository;
            DriverBehaviourRiskViews = _DriverBehaviourRiskViews;
             DriverRiskList = _DriverRiskList;
            BusinessUnitsSearchResultList= businessUnitsSearchResultList;
            LocationsSearchResultList = _LocationSearchRepository;
            DriversBehaviourRisks = _DriversBehaviourRisks;
           
            DriverRisks = _DriverRisks;
            
        }

        public ICountryRepository Countries { get; set; }
        public ICountryListRepository CountryList { get; set; }
       
        public IDriversSearchResultListRepository DriversSearchResultList { get; set; }
       
        public IDriverRiskListRepository DriverRiskList { get; set; }
        public IDriversBehaviourRiskRepository DriversBehaviourRisks { get; set; }
       
        public IDriverRiskRepository DriverRisks { get; set; }
        public IDriverLicenseRepository DriverLicenses { get; set; }
        public IDriverBehaviourRiskViewRepository DriverBehaviourRiskViews { get; set; }
        public IBusinessUnitSearchRepository BusinessUnitsSearchResultList { get; set; }
        public ILocationSearchRepository LocationsSearchResultList { get; set; }

      //  ILocationSearchRepository IUnitOfWork.LocationsSearchResultList => throw new NotImplementedException();
        // IDriverBehaviourRiskViewRepository IUnitOfWork.DriverBehaviourRiskViews => throw new NotImplementedException();
    }
}