﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using System.Reflection.Metadata;

namespace eDMS.Infrastructure.Repository
{
    public class DriverSearchResultListRepository : IDriversSearchResultListRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public DriverSearchResultListRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ IDriverSearchResultListRepository Methods ]==================================================

         async Task<IReadOnlyList<DriverSearchResult>> IDriversSearchResultListRepository.GetManyAsync(DriverSearchRequest request)
        {
             return await _dbContext.DriverSearchResults.FromSqlInterpolated<DriverSearchResult>($" {StoreProc.Sp_GetDriverSearchList} {request.EmpId}, {request.FirstName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerCode},{request.ManagerName},{request.HRStatus},{request.IsDriverEvaluator},{request.START_INDEX},{request.PAGE_SIZE}").ToListAsync();
          // return await _dbContext.DriverSearchResults.FromSqlInterpolated<DriverSearchResult>($" {StoreProc.Sp_GetDriverSearchList}{request.EmpId} , {request.FirstName} ,{request.LastName},{request.START_INDEX},{request.PAGE_SIZE}").ToListAsync();
            // return await _dbContext.DriverSearchResults.FromSqlInterpolated<DriverSearchResult>($" {StoreProc.Sp_GetDriverSearchList}{request.EmpId} , {request.FirstName} ,{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerId},{request.ManagerName},{request.HRStatus},{request.IsDriverEvaluator},{request.START_INDEX},{request.PAGE_SIZE}").ToListAsync();
        }
         async Task<DriversSearchResult> IDriversSearchResultListRepository.GetManyAsyncResult(DriverSearchRequest request)
        {
            var paramName = new SqlParameter("@TotalCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            var driverSearchResult = await _dbContext.DriverSearchResults.FromSqlInterpolated<DriverSearchResult>($" {StoreProc.Sp_GetDriverSearchListSp} {request.EmpId},{request.EmplId}, {request.FirstName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerCode},{request.ManagerName},{request.HRStatus},{request.IsDriverEvaluator},{request.LoggedInUserId},{request.IsGlobalAccess},{request.START_INDEX},{request.PAGE_SIZE},{paramName} OUTPUT").ToListAsync();
            // Access the output parameter value
            var outputValue = paramName.Value;
            // Use the output value as needed

            // var driverSearchResult = await _dbContext.DriverSearchResults.FromSqlInterpolated<DriverSearchResult>($" {StoreProc.Sp_GetDriverSearchList} {request.EmpId}, {request.FirstName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerId},{request.ManagerName},{request.HRStatus},{request.IsDriverEvaluator},{request.START_INDEX},{request.PAGE_SIZE}").ToListAsync();
             //var driverSearchCountList = await _dbContext.DriverSearchResults.FromSqlInterpolated<DriverSearchResult>($" {StoreProc.Sp_GetDriverSearchList} {request.EmpId}, {request.FirstName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerId},{request.ManagerName},{request.HRStatus},{request.IsDriverEvaluator},Null,Null").ToListAsync();
            DriversSearchResult result = new DriversSearchResult();
            result.TotalCount = Convert.ToInt32(outputValue);//driverSearchCountList.Count;
            result.driverSearchResultList = driverSearchResult;
            return result;
        }
        public async Task<DriversSearchResult> GetManyAsync(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var employeeMasterList = await query.ToListAsync();
            var driverSearchResultList = new List<DriverSearchResult>();
            foreach (EmployeeMaster empMaster in employeeMasterList)
            {
                var countryList1 = new DriverSearchResult {  FirstName = empMaster.FirstName, LastName = empMaster.LastName, ManagerCode = empMaster.ManagerCode };
                driverSearchResultList.Add(countryList1);
            }
            DriversSearchResult result = new DriversSearchResult();
            result.TotalCount = countSearch;
            result.driverSearchResultList = driverSearchResultList;
            return result;
            // return await query.ToListAsync();
        }




        #endregion
    }
}
