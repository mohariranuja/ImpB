﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class IncidentTypeRepository : IIncidentTypeRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        #region ===[ Constructor ]=================================================================
        public IncidentTypeRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion
        #region ===[ IIncidentTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMIncidentType>> GetAllAsync()
        {
            return await _dbContext.MDMIncidentTypes.OrderByDescending(r=>r.IncidentTypeId).ToListAsync();
        }
        public async Task<MDMIncidentType> GetByIdAsync(int id)
        {
            return await _dbContext.MDMIncidentTypes.Where(w => w.IncidentTypeId == id).FirstOrDefaultAsync();
        }
        public async Task<int> SaveAsync(MDMIncidentType mdmIncidentType)
        {
            var result = _dbContext.MDMIncidentTypes.AsNoTracking().Where(w => w.IncidentTypeId == mdmIncidentType.IncidentTypeId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.MDMIncidentTypes.Add(mdmIncidentType);
            }
            else
            {
                _dbContext.MDMIncidentTypes.Update(mdmIncidentType);
            }
            return await _dbContext.SaveChangesAsync();
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.MDMIncidentTypes.Where(w => w.IncidentTypeId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActiveIncidentType = false;
                _dbContext.MDMIncidentTypes.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}