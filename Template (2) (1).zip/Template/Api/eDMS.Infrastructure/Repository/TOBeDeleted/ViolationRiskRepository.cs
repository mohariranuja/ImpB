﻿using eDMS.Application.Interfaces;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class ViolationRiskRepository :IViolationRiskRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public ViolationRiskRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region ===[ IViolationRiskRepository Methods ]==================================================
        public async Task<string> GetViolationAsyncResult()
        {
            string result = string.Empty;


            var sql = $"EXEC YourStoredProcedure @InputParam, @OutputParam OUTPUT";
            // Execute the raw SQL query with output parameter

            // 
            // Use the output value as needed

            var paramName = new SqlParameter("@returnResult", SqlDbType.VarChar, 8000)
            {
                Direction = ParameterDirection.Output

            };
            _dbContext.Database.ExecuteSqlInterpolated($"EXEC ViolationUpdate_New_Old {paramName} OUTPUT");

            //Access the output parameter value
            var outputValue = paramName.Value;
            
            // Use the output value as needed
            result = outputValue.ToString();

            return result;
        }
        #endregion
    }
}
