﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class PsxlatitemRepository : IPsxlatitemRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public PsxlatitemRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IDLUPLDWRKRepository Methods ]==================================================
        public async Task<IReadOnlyList<Psxlatitem>> GetAllAsync()
        {
            return await _dbContext.Psxlatitems.ToListAsync();
        }

        public async Task<Psxlatitem> GetByIdAsync(int id)
        {
            return await _dbContext.Psxlatitems.Where(w => w.SYNCID == id).FirstOrDefaultAsync();
        }
        
        public async Task<int> SaveAsync(Psxlatitem entity)
        {
            var result = _dbContext.Psxlatitems.AsNoTracking().Where(w => w.FIELDNAME == entity.FIELDNAME
            && w.FIELDVALUE == entity.FIELDVALUE).FirstOrDefault();

            if (result == null)
            {
                _dbContext.Psxlatitems.Add(entity);
            }
            else
            {
                _dbContext.Psxlatitems.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.Psxlatitems.Where(w => w.SYNCID == id).FirstOrDefault();
            if (result != null)
            {
                result.EFF_STATUS = "A";
                _dbContext.Psxlatitems.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}