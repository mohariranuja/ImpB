﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DOTDrugAlcoholTestRepository : IDrugAlcoholTestRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public DOTDrugAlcoholTestRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IIncidentTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<DOTDrug_AlcoholTest>> GetAllAsync()
        {
            return await _dbContext.DOTDrug_AlcoholTest.Where(w => w.IsActive == true).ToListAsync();
        }

        public async Task<DOTDrug_AlcoholTest> GetByIdAsync(int id)
        {
            return await _dbContext.DOTDrug_AlcoholTest.Where(w => w.DOTDrug_AlcoholTestId == id && w.IsActive == true).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(DOTDrug_AlcoholTest dotDrugAlcoholTest)
        {
            var result = _dbContext.DOTDrug_AlcoholTest.AsNoTracking().Where(w => w.DOTDrug_AlcoholTestId == dotDrugAlcoholTest.DOTDrug_AlcoholTestId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DOTDrug_AlcoholTest.Add(dotDrugAlcoholTest);
            }
            else
            {
                _dbContext.DOTDrug_AlcoholTest.Update(dotDrugAlcoholTest);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DOTDrug_AlcoholTest.Where(w => w.DOTDrug_AlcoholTestId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.DOTDrug_AlcoholTest.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<DrugTestGetResponse> GetManyAsync(int employeeId, int? top = null,
            int? skip = null, params string[] includeProperties)
        {
            IQueryable<DOTDrug_AlcoholTest> query = _dbContext.DOTDrug_AlcoholTest
                .Where(x => x.EmployeeId == employeeId && x.IsActive == true)
                .OrderByDescending(x => x.DOTDrug_AlcoholTestId);

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }
            int countSearch = query.Count();

            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }
            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var testType = await _dbContext.TestTypes.Where(w => w.IsActive == true).ToListAsync();
            var sampleType = await _dbContext.SampleTypes.Where(w => w.IsActive == true).ToListAsync();
            var disposition = await _dbContext.Dispositions.Where(w => w.IsActive == true).ToListAsync();
            var testResult = await _dbContext.TestResults.Where(w => w.IsActive == true).ToListAsync();

            //var response = (from dt in query.ToList()
            //                select new
            //                {
            //                    DOTDrug_AlcoholTestId = dt.DOTDrug_AlcoholTestId,
            //                    EmployeeId = dt.EmployeeId,
            //                    EmpId = dt.EmpId,
            //                    TestDate = dt.ExamDate,
            //                    //TestCategoryId = dt.TestCategoryId,
            //                    TestCategory = dt.ExamCategory,
            //                    TestType = dt.ExamType,
            //                    TestTypeName = string.Empty,//tt.TestTypeName,
            //                    Agency = dt.Agency,
            //                    SampleType = dt.SampleType,
            //                    SampleTypeName = string.Empty,//st.SampleTypeName,
            //                    TestNumber = dt.TestNumber,
            //                    PhysicianName = dt.PhysicianName,
            //                    TestResult = dt.TestResultDrug,
            //                    TestResultName = string.Empty,//tr.TestResultName,
            //                    Disposition = dt.Disposition,
            //                    DispositionName = (dt.Disposition == string.Empty) ? string.Empty : disposition.Where(x => x.FieldValue == dt.Disposition).First().DispositionName,
            //                    //DispositionName = d.DispositionName,
            //                    Description = dt.Description,
            //                    Amphetamine = dt.Amphetamine,
            //                    Cocaine = dt.Cocaine,
            //                    Marijuana = dt.Marijuana,

            //                    Opiates = dt.Opiates,
            //                    Phencyclidine = dt.Phencyclidine,
            //                    Other = dt.Other
            //                }).ToList();
            var resultQuery = query.ToList();
            var drugResponseList = new List<DrugAlcoholTestResponse>();
            for (int i = 0; i < resultQuery.Count; i++)
            {
                var drugResponse = new DrugAlcoholTestResponse();
                drugResponse.TestResultName = (resultQuery[i].TestResultDrug == string.Empty) ? string.Empty 
                    : testResult.Where(z => z.FieldValue.ToLower() == resultQuery[i].TestResultDrug.ToLower() 
                    && z.TestCategoryId == resultQuery[i].TestCategoryId).First().TestResultName;
                drugResponse.SampleTypeName = (resultQuery[i].SampleType == string.Empty) ? string.Empty 
                    : sampleType.Where(z => z.FieldValue.ToLower() == resultQuery[i].SampleType.ToLower() 
                    && z.TestCategoryId == resultQuery[i].TestCategoryId).First().SampleTypeName;
                drugResponse.TestTypeName = (resultQuery[i].ExamType == string.Empty) ? string.Empty 
                    : testType.Where(y => y.FieldValue.ToLower() == resultQuery[i].ExamType.ToLower() 
                    && y.TestCategoryId == resultQuery[i].TestCategoryId).First().TestTypeName;
                
                drugResponse.DOTDrug_AlcoholTestId = resultQuery[i].DOTDrug_AlcoholTestId;
                drugResponse.EmployeeId = resultQuery[i].EmployeeId;
                drugResponse.EmpId = resultQuery[i].EmpId;
                drugResponse.TestDate = resultQuery[i].ExamDate;
                drugResponse.TestCategory = resultQuery[i].ExamCategory;
                drugResponse.TestType = resultQuery[i].ExamType;
                //drugResponse.TestTypeName = response[i].TestTypeName;//testType.Where(r => r.FieldValue == response[i].TestType).FirstOrDefault().TestCategoryName;
                drugResponse.Agency = resultQuery[i].Agency;
                drugResponse.SampleType = resultQuery[i].SampleType;
                //drugResponse.SampleTypeName = response[i].SampleTypeName;
                drugResponse.TestNumber = resultQuery[i].TestNumber;
                drugResponse.PhysicianName = resultQuery[i].PhysicianName;
                drugResponse.TestResult = resultQuery[i].TestResultDrug;
                //drugResponse.TestResultName = response[i].TestResultName;
                drugResponse.Disposition = resultQuery[i].Disposition;
                drugResponse.DispositionName = (resultQuery[i].Disposition.Trim() == string.Empty) ? string.Empty 
                    : disposition.Where(x => x.FieldValue == resultQuery[i].Disposition)?.FirstOrDefault()?.DispositionName;
                drugResponse.Description = resultQuery[i].Description;
                drugResponse.Amphetamine = resultQuery[i].Amphetamine;
                drugResponse.Cocaine = resultQuery[i].Cocaine;
                drugResponse.Marijuana = resultQuery[i].Marijuana;
                drugResponse.Opiates = resultQuery[i].Opiates;
                drugResponse.Phencyclidine = resultQuery[i].Phencyclidine;
                drugResponse.Other = resultQuery[i].Other;

                drugResponseList.Add(drugResponse);
            }

            DrugTestGetResponse result = new DrugTestGetResponse();
            result.TotalCount = countSearch;

            result.DrugAlcoholTest = drugResponseList;
            return result;
        }
        #endregion
    }
}