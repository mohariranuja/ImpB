﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class IncidentSeverityMatrixByPageRepository : IIncidentSeverityMatrixByPageRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public IncidentSeverityMatrixByPageRepository   (ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        public async Task<IncidentsSeverityMatrixResult> GetManyAsync(Func<IQueryable<IncidentSeverityMatrix>, IOrderedQueryable<IncidentSeverityMatrix>> orderBy = null, int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<IncidentSeverityMatrix> query = _dbContext.IncidentSeverityMatrices.Where(x => x.IncidentSeverityMatrixId > 0 /*&& x.IsActiveIncidentSeverityMatrix == true*/)
                .OrderByDescending(x=>x.IncidentSeverityMatrixId);

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }
            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<IncidentSeverityMatrix> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var incidentTypes = _dbContext.MDMIncidentTypes;
            var query_result = (from ISM in query
                                join incT in incidentTypes on ISM.IncidentTypeId equals incT.IncidentTypeId
                                select new
                                {
                                    IncidentSeverityMatrixId = ISM.IncidentSeverityMatrixId,
                                    IncidentTypeId = ISM.IncidentTypeId,
                                    IncidentType = incT.IncidentType,
                                    IncidentSeverityMatrixDescription = ISM.IncidentSeverityMatrixDescription,
                                    RiskIndexId = ISM.RiskIndexId,
                                    IncidentValue = ISM.IncidentValue,
                                    IsActiveIncidentSeverityMatrix = ISM.IsActiveIncidentSeverityMatrix
                                }
                        );

            var incidentSeverityMatrixResponceList = new List<IncidentSeverityMatrixSet>();

            foreach (var incidentSeverityMatrix in query_result)
            {
                IncidentSeverityMatrixSet incidentSeverityList = new IncidentSeverityMatrixSet
                {
                    IncidentSeverityMatrixId = incidentSeverityMatrix.IncidentSeverityMatrixId,
                    IncidentTypeId = incidentSeverityMatrix.IncidentTypeId,
                    IncidentType = incidentSeverityMatrix.IncidentType,
                    IncidentSeverityMatrixDescription = incidentSeverityMatrix.IncidentSeverityMatrixDescription,
                    RiskIndexId = incidentSeverityMatrix.RiskIndexId,
                    IncidentValue = incidentSeverityMatrix.IncidentValue,
                    IsActiveIncidentSeverityMatrix = incidentSeverityMatrix.IsActiveIncidentSeverityMatrix
                };
                incidentSeverityMatrixResponceList.Add(incidentSeverityList);
            }

            IncidentsSeverityMatrixResult result = new IncidentsSeverityMatrixResult();
            result.TotalCount = countSearch;
            result.incidentSeverityMatrices = incidentSeverityMatrixResponceList;
            return result;
        }

        public async Task<IncidentsSeverityMatrixResult> GetManyAsyncFilter(
         Expression<Func<IncidentSeverityMatrix, bool>> filter = null,
         Func<IQueryable<IncidentSeverityMatrix>, IOrderedQueryable<IncidentSeverityMatrix>> orderBy = null,
         int? top = null,
         int? skip = null,
         params string[] includeProperties)
        {
            IQueryable<IncidentSeverityMatrix> query =  _dbContext.IncidentSeverityMatrices;
            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }
            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<IncidentSeverityMatrix> queryCount = query;
            var countItem = await  queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var incidentTypes = _dbContext.MDMIncidentTypes;
            var query_result = (from ISM in query
                                join incT in incidentTypes on ISM.IncidentTypeId equals incT.IncidentTypeId
                                select new
                                {
                                    IncidentSeverityMatrixId = ISM.IncidentSeverityMatrixId,
                                    IncidentTypeId = ISM.IncidentTypeId,
                                    IncidentType = incT.IncidentType,
                                    IncidentSeverityMatrixDescription = ISM.IncidentSeverityMatrixDescription,
                                    RiskIndexId = ISM.RiskIndexId,
                                    IncidentValue = ISM.IncidentValue,
                                    IsActiveIncidentSeverityMatrix = ISM.IsActiveIncidentSeverityMatrix
                                }
                        );

            var incidentSeverityMatrixResponceList = new List<IncidentSeverityMatrixSet>();

            foreach (var incidentSeverityMatrix in query_result)
            {
                IncidentSeverityMatrixSet incidentSeverityList = new IncidentSeverityMatrixSet
                {
                    IncidentSeverityMatrixId = incidentSeverityMatrix.IncidentSeverityMatrixId,
                    IncidentTypeId = incidentSeverityMatrix.IncidentTypeId,
                    IncidentType = incidentSeverityMatrix.IncidentType,
                    IncidentSeverityMatrixDescription = incidentSeverityMatrix.IncidentSeverityMatrixDescription,
                    RiskIndexId = incidentSeverityMatrix.RiskIndexId,
                    IncidentValue = incidentSeverityMatrix.IncidentValue,
                    IsActiveIncidentSeverityMatrix = incidentSeverityMatrix.IsActiveIncidentSeverityMatrix
                };
                incidentSeverityMatrixResponceList.Add(incidentSeverityList);
            }

            IncidentsSeverityMatrixResult result = new IncidentsSeverityMatrixResult();
            result.TotalCount = countSearch;
            result.incidentSeverityMatrices = incidentSeverityMatrixResponceList;
            return result;
        }
    }
}