﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class LocationRepository: ILocationRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public LocationRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion
        #region ===[ ILocationRepositoryRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMLocation>> GetAllAsync()
        {
            return await _dbContext.Locations.ToListAsync();
        }

        public async Task<MDMLocation> GetByIdAsync(int id)
        {
            return await _dbContext.Locations.Where(w => w.LocationId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(MDMLocation mdmLocation)
        {
            var result = _dbContext.Locations.AsNoTracking().Where(w => w.LocationId == mdmLocation.LocationId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.Locations.Add(mdmLocation);
            }
            else
            {
                _dbContext.Locations.Update(mdmLocation);
            }
            return await _dbContext.SaveChangesAsync();
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.Locations.Where(w => w.LocationId == id).FirstOrDefault();

            if (result != null)
            {
                // result.IsActive= false;
                _dbContext.Locations.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        #endregion

    }
}
