﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class MdmUserRoleRepository(ApplicationDBContext dbContext) : IMdmUserRoleRepository
    {
        private readonly ApplicationDBContext _dbContext = dbContext;

        public async Task<MdmUserRole?> GetMdmUserRoleByUserIdAsync(int userId)
        {
            return await _dbContext.MdmUserRoles
                .Where(u => u.UserId == userId)
                .FirstOrDefaultAsync();
        }
    }
}
