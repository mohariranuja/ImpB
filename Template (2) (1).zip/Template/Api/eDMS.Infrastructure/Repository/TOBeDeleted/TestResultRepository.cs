﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class TestResultRepository : ITestResultRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
    
        #region ===[ Constructor ]=================================================================
        public TestResultRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IIncidentTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<TestResult>> GetAllAsync()
        {
            return await _dbContext.TestResults.Where(w => w.IsActive == true).ToListAsync();
        }

        public async Task<TestResult> GetByIdAsync(int id)
        {
            return await _dbContext.TestResults.Where(w => w.TestResultId == id).FirstOrDefaultAsync();
        }
        
        public async Task<int> SaveAsync(TestResult testResult)
        {
            var result = _dbContext.TestResults.AsNoTracking().Where(w => w.TestResultId == testResult.TestResultId).FirstOrDefault();

            if (result == null)
            {
                testResult.CreatedOn = DateTime.Now;
                _dbContext.TestResults.Add(testResult);
            }
            else
            {
                testResult.ModifiedBy = testResult.CreatedBy;
                testResult.ModifiedOn = DateTime.Now;
                testResult.CreatedBy = result.CreatedBy;
                testResult.CreatedOn = result.CreatedOn;
                _dbContext.TestResults.Update(testResult);
            }
            return await _dbContext.SaveChangesAsync();
        }
        
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.TestResults.Where(w => w.TestResultId == id).FirstOrDefault();
            if (result != null)
            {
                if (result.TestResultName.ToLower() != "positive")
                {
                    result.IsActive = false;
                    _dbContext.TestResults.Update(result);
                }
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<TestResultResponseList> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        {
            IQueryable<TestResult> query = _dbContext.TestResults.OrderByDescending(x => x.TestResultId);

            IQueryable<TestResult> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var testResultList = await query.ToListAsync();
            var testResultResponce_List = new List<TestResultResponse>();
            foreach (TestResult testResult in testResultList)
            {
                var testResults = new TestResultResponse
                {
                    TestResultId = testResult.TestResultId,
                    TestResultName = testResult.TestResultName,
                    TestCategoryId = testResult.TestCategoryId,
                    TestCategoryName = testResult.TestCategoryName,
                    TestTypeId = testResult.TestTypeId,
                    TestTypeName = testResult.TestTypeName,
                    FieldValue = testResult.FieldValue,
                    IsActive = testResult.IsActive
                };
                testResultResponce_List.Add(testResults);
            }

            TestResultResponseList result = new TestResultResponseList();
            result.TotalCount = countSearch;
            result.testResultResponseList = testResultResponce_List;
            return result;
        }
        #endregion
    }
}