﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class TestCategoryRepository : ITestCategoryRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
    
        #region ===[ Constructor ]=================================================================
        public TestCategoryRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region ===[ ITestCategoryRepository Methods ]==================================================
        public async Task<IReadOnlyList<TestCategory>> GetAllAsync()
        {
            return await _dbContext.TestCategories.ToListAsync();
        }

        public async Task<TestCategory> GetByIdAsync(int id)
        {
            return await _dbContext.TestCategories.Where(w => w.TestCategoryId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(TestCategory testCategory)
        {
                var result = _dbContext.TestCategories.AsNoTracking().Where(w => w.TestCategoryId == testCategory.TestCategoryId).FirstOrDefault();

                if (result == null)
                {
                    _dbContext.TestCategories.Add(testCategory);
                }
                else
                {
                    _dbContext.TestCategories.Update(testCategory);
                }
                return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.TestCategories.Where(w => w.TestCategoryId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.TestCategories.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<TestCategoryResponse> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        {
            IQueryable<TestCategory> query = _dbContext.TestCategories.OrderByDescending(r => r.TestCategoryId);

            IQueryable<TestCategory> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var TestResultList = await query.ToListAsync();
            var testResultListResponceList = new List<TestCategoriesResponse>();
            foreach (TestCategory TestValue in TestResultList)
            {
                var testList = new TestCategoriesResponse
                {
                    TestCategoryId = TestValue.TestCategoryId,
                    TestCategoryName = TestValue.TestCategoryName,
                    FieldValue = TestValue.FieldValue,
                    IsActive = TestValue.IsActive
                };
                testResultListResponceList.Add(testList);
            }
            TestCategoryResponse result = new TestCategoryResponse();
            result.TotalCount = countSearch;
            result.TestCategoryResponseList = testResultListResponceList;
            return result;
        }
        #endregion
    }
}