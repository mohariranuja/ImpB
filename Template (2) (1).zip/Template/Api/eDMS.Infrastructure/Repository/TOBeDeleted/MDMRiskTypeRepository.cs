﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class MDMRiskTypeRepository : IMDMRiskTypeRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public MDMRiskTypeRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ MDMRiskTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMRiskType>> GetAllAsync()
        {
            return await _dbContext.RiskTypes.Where(r => r.IsActive == true).ToListAsync();
        }

        public async Task<MDMRiskType> GetByIdAsync(int id)
        {
            return await _dbContext.RiskTypes.Where(w => w.RiskTypeId == id)?.FirstOrDefaultAsync();
        }

        public async Task<MDMRiskType> GetByTypeAsync(string riskType)
        {
            return await _dbContext.RiskTypes.Where(w => w.RiskType == riskType)?.FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(MDMRiskType riskType)
        {
            var result = _dbContext.RiskTypes.AsNoTracking().Where(w => w.RiskTypeId == riskType.RiskTypeId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.RiskTypes.Add(riskType);
            }
            else
            {
                _dbContext.RiskTypes.Update(riskType);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.RiskTypes.Where(w => w.RiskTypeId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.RiskTypes.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}