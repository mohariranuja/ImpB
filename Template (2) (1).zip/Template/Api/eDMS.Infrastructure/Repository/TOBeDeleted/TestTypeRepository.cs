﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class TestTypeRepository : ITestTypeRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
    
        #region ===[ Constructor ]=================================================================
        public TestTypeRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region ===[ IIncidentTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<TestType>> GetAllAsync()
        {
            return await _dbContext.TestTypes.Where(w => w.IsActive == true).ToListAsync();
        }

        public async Task<TestType> GetByIdAsync(int id)
        {
            return await _dbContext.TestTypes.Where(w => w.TestTypeId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(TestType testType)
        {
            var result = _dbContext.TestTypes.AsNoTracking().Where(w => w.TestTypeId == testType.TestTypeId).FirstOrDefault();

            if (result == null)
            {
                testType.CreatedOn = DateTime.Now;
                _dbContext.TestTypes.Add(testType);
            }
            else
            {
                testType.ModifiedBy = testType.CreatedBy;
                testType.ModifiedOn = DateTime.Now;
                testType.CreatedBy = result.CreatedBy;
                testType.CreatedOn = result.CreatedOn;
                _dbContext.TestTypes.Update(testType);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.TestTypes.Where(w => w.TestTypeId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.TestTypes.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<TestTypeResponseList> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        {
            IQueryable<TestType> query = _dbContext.TestTypes.OrderByDescending(x => x.TestTypeId);

            IQueryable<TestType> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var testTypeList = await query.ToListAsync();
            var testTypeResponce_List = new List<TestTypeResponse>();
            foreach (TestType testType in testTypeList)
            {
                var testTypes = new TestTypeResponse
                {
                    TestTypeId   = testType.TestTypeId,
                    TestTypeName     = testType.TestTypeName,
                    TestCategoryId = testType.TestCategoryId,
                    TestCategoryName = testType.TestCategoryName,
                    FieldValue  = testType.FieldValue,
                    IsActive = testType.IsActive
                };
                testTypeResponce_List.Add(testTypes);
            }
            TestTypeResponseList result = new TestTypeResponseList();
            result.TotalCount = countSearch;
            result.testTypeResponseList = testTypeResponce_List;
            return result;
        }
        #endregion
    }
}