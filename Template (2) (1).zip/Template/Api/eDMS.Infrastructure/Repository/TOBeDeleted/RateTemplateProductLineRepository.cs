﻿using EverestVPS.Application.Interfaces;
using EverestVPS.Core.Entities;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using eDMS.Infrastructure.Persistence;


namespace EverestVPS.Infrastructure.Repository
{
    public class RateTemplateProductLineRepository : IRateTemplateProductLineRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public RateTemplateProductLineRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ IRateTemplateProductLineRepository Methods ]==================================================
        public async Task<IReadOnlyList<RateTemplateProductLine>> GetAllAsync()
        {
            return null;
          //  return await _dbContext.RateTemplateProductLines.ToListAsync();
        }


        public async Task<RateTemplateProductLine> GetByIdAsync(int rateId)
        {
            return null;//await _dbContext.RateTemplateProductLines.Where(w => w.RateId == rateId).FirstOrDefaultAsync();
        }
        #endregion
    }
}
