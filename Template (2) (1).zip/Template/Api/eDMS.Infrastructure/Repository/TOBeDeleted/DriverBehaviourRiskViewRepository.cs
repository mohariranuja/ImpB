﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Extension;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Transactions;

namespace eDMS.Infrastructure.Repository
{
    public class DriverBehaviourRiskViewRepository : IDriverBehaviourRiskViewRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriverBehaviourRiskViewRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IDriverTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<DriverBehaviourRiskView>> GetAllAsync()
        {
            return await _dbContext.DriverBehaviourRiskViews.ToListAsync();
        }

        public async Task<DriverBehaviourRiskView> GetByIdAsync(int id)
        {
            return await _dbContext.DriverBehaviourRiskViews.Where(w => w.DriverBehaviourId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(DriverBehaviourRiskView driverBehaviourRiskView)
        {
            var result = _dbContext.DriverBehaviourRiskViews.AsNoTracking().Where(w => w.DriverBehaviourId == driverBehaviourRiskView.DriverBehaviourId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DriverBehaviourRiskViews.Add(driverBehaviourRiskView);
            }
            else
            {
                _dbContext.DriverBehaviourRiskViews.Update(driverBehaviourRiskView);
            }
            return await _dbContext.SaveChangesAsync();
        }    

        public async Task<int> DeleteAsync(int id)
        {
            var driverBehaviourRiskViews = _dbContext.DriverBehaviourRiskViews.Where(w => w.DriverBehaviourId == id).FirstOrDefault();

            if (driverBehaviourRiskViews != null)
            {
                driverBehaviourRiskViews.IsActive = false;
                _dbContext.DriverBehaviourRiskViews.Update(driverBehaviourRiskViews);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public Task<IReadOnlyList<Country>> GetManyAsync(Expression<Func<Country, bool>> filter = null)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}