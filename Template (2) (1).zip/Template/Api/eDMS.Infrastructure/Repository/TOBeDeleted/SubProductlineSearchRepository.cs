﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class SubProductlineSearchRepository : ISubProductLineSearchRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public SubProductlineSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ ISubProductLineSearchRepository Methods ]==================================================




        public async Task<GenericMastersSearchResult> GetManySubProductLineAsync(Expression<Func<SubProductLine, bool>> filter = null, Func<IQueryable<SubProductLine>, IOrderedQueryable<SubProductLine>> orderBy = null, int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<SubProductLine> query = _dbContext.SubProductLines; ;


            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<SubProductLine> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var pagesitem = await query.ToListAsync();
            var genericMasterResultList = new List<GenericMasterResult>();
            foreach (SubProductLine empMaster in pagesitem)
            {

                var deptList = new GenericMasterResult { SubProductLineId = empMaster.SubProductLineId, SubProductLineDescription = empMaster.Description, SubProductLineCode=empMaster.SubProductLineCode };
                genericMasterResultList.Add(deptList);
            }


            GenericMastersSearchResult result = new GenericMastersSearchResult();
            result.TotalCount = countSearch;
            result.genericMasterResultList = genericMasterResultList;
            return result;
        }
        #endregion
    }
}
