﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DocumentTypeRepository : IDocumentTypeRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
    
        #region ===[ Constructor ]=================================================================
        public DocumentTypeRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IIncidentTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<DocType>> GetAllAsync()
        {
            return await _dbContext.DocumentTypes.ToListAsync();
        }

        public async Task<DocType> GetByIdAsync(int id)
        {
            return await _dbContext.DocumentTypes.Where(w => w.DocTypeId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(DocType documentType)
        {
            var result = _dbContext.DocumentTypes.AsNoTracking().Where(w => w.DocTypeId == documentType.DocTypeId).FirstOrDefault();

            if (result == null)
            {
                documentType.CreatedOn = DateTime.Now;
                _dbContext.DocumentTypes.Add(documentType);
            }
            else
            {
                documentType.ModifiedBy = documentType.CreatedBy;
                documentType.ModifiedOn = DateTime.Now;
                documentType.CreatedBy = result.CreatedBy;
                documentType.CreatedOn = result.CreatedOn;
                _dbContext.DocumentTypes.Update(documentType);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DocumentTypes.Where(w => w.DocTypeId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.DocumentTypes.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        //public async Task<TestTypeResponseList> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        //{
        //    IQueryable<TestType> query = _dbContext.TestTypes.OrderByDescending(x => x.TestTypeId);

        //    IQueryable<TestType> queryCount = query;
        //    var countItem = await queryCount.ToListAsync();
        //    int countSearch = countItem.Count;
        //    if (skip.HasValue)
        //    {
        //        query = query.Skip(skip.Value);
        //    }

        //    if (top.HasValue)
        //    {
        //        query = query.Take(top.Value);
        //    }
        //    var testTypeList = await query.ToListAsync();
        //    var testTypeResponce_List = new List<TestTypeResponse>();
        //    foreach (TestType testType in testTypeList)
        //    {
        //        var testTypes = new TestTypeResponse
        //        {
        //            TestTypeId   = testType.TestTypeId,
        //            TestTypeName     = testType.TestTypeName,
        //            TestCategoryId = testType.TestCategoryId,
        //            TestCategoryName = testType.TestCategoryName,
        //            FieldValue  = testType.FieldValue,
        //            IsActive = testType.IsActive
        //        };
        //        testTypeResponce_List.Add(testTypes);
        //    }
        //    TestTypeResponseList result = new TestTypeResponseList();
        //    result.TotalCount = countSearch;
        //    result.testTypeResponseList = testTypeResponce_List;
        //    return result;
        //}
        #endregion
    }
}