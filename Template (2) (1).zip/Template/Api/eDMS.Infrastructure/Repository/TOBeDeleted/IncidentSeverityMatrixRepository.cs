﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class IncidentSeverityMatrixRepository : IIncidentSeverityMatrixRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public IncidentSeverityMatrixRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IIncidentValueRepository Methods ]==================================================
        public async Task<IReadOnlyList<IncidentSeverityMatrix>> GetAllAsync()
        { 
            return await _dbContext.IncidentSeverityMatrices.ToListAsync();
        }

        public async Task<IncidentSeverityMatrix> GetByIdAsync(int id)
        {
            return await _dbContext.IncidentSeverityMatrices.Where(w => w.IncidentSeverityMatrixId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(IncidentSeverityMatrix incidentSeverityMatrix)
        {
            //var result = _dbContext.IncidentValues.AsNoTracking().Where(w => w.IncidentValueId == incidentSeverityMatrix.IncidentSeverityMatrixId).FirstOrDefault();
            var result = _dbContext.IncidentSeverityMatrices.AsNoTracking().Where(w => w.IncidentSeverityMatrixId == incidentSeverityMatrix.IncidentSeverityMatrixId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.IncidentSeverityMatrices.Add(incidentSeverityMatrix);
            }
            else
            {
                _dbContext.IncidentSeverityMatrices.Update(incidentSeverityMatrix);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.IncidentSeverityMatrices.Where(w => w.IncidentSeverityMatrixId == id).FirstOrDefault();

            if (result != null)
            {
                result.IsActiveIncidentSeverityMatrix = false;
                _dbContext.IncidentSeverityMatrices.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}