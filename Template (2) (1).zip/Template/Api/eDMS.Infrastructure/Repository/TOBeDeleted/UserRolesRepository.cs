﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class UserRolesRepository: IUserRolesRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
    #endregion

    #region ===[ Constructor ]=================================================================
    public UserRolesRepository(ApplicationDBContext dbContext)
    {
        _dbContext = dbContext;
    }

        #endregion
        #region ===[ IUserRolesRepository Methods ]==================================================
     

   

        public async Task<UserRoleList> GetMDMUserRoleByIdAsync(int id)
        {
            UserRoleList roleList = new UserRoleList();
            var result= await _dbContext.MdmUserRoles.Where(w => w.UserId == id).FirstOrDefaultAsync();
            var  employeeMaster= await _dbContext.EmployeeMasters.Where(w => w.EmpId == id).FirstOrDefaultAsync();
         //   List<MdmRole> mdmRoles = await _dbContext.MdmRoles.ToListAsync();
            if (result != null)
            {
                roleList.UserId = result.UserId;
                roleList.RoleId = result.RoleId;
                roleList.UserRoleId = result.UserRoleId;
                roleList.IsActiveUserRole = result.IsActiveUserRole;
                roleList.ModifiedBy = result.ModifiedBy;
                roleList.ModifiedOn = result.ModifiedOn;
                roleList.CreatedOn = result.CreatedOn;
                roleList.CreatedBy = result.CreatedBy;
                roleList.IsGlobalAccess= result.IsGlobalAccess;
            }
              //  roleList.MdmRoles = mdmRoles;
                roleList.EmpId = employeeMaster.EmpId;
                roleList.EmplId = employeeMaster.EmplId;
                roleList.FirstName = employeeMaster.FirstName;
                roleList.LastName = employeeMaster.LastName;
                roleList.ManagerName = employeeMaster.ManagerName;
                roleList.ManagerCode = employeeMaster.ManagerCode;

          //  }
            return roleList;
        }

        public async Task<int> SaveAsync(MdmUserRole entity)
        {
            var result = await _dbContext.MdmUserRoles.AsNoTracking().Where(w => w.UserRoleId == entity.UserRoleId).FirstOrDefaultAsync();
            //var result = _dbContext.DriversRisk.AsNoTracking().Where(w => w.DriverRiskId == entity.DriverRiskI ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.MdmUserRoles.Add(entity);
            }
            else
            {
                result.RoleId = entity.RoleId;
                result.ModifiedBy = entity.ModifiedBy;//2;
                result.ModifiedOn = DateTime.Now;
                _dbContext.MdmUserRoles.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        #endregion
    }
}
