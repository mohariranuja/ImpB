﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class MDMRegionRepository : IMDMRegionRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public MDMRegionRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ MDMRiskTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMRegion>> GetAllAsync()
        {
            return await _dbContext.MdmRegions.Where(r => r.IsActive == true).ToListAsync();
        }

        public async Task<MDMRegion> GetByIdAsync(int id)
        {
            return await _dbContext.MdmRegions.Where(w => w.RegionId == id)?.FirstOrDefaultAsync();
        }

       

        public async Task<int> SaveAsync(MDMRegion mdmRegion)
        {
            var result = _dbContext.MdmRegions.AsNoTracking().Where(w => w.RegionId == mdmRegion.RegionId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.MdmRegions.Add(mdmRegion);
            }
            else
            {
                _dbContext.MdmRegions.Update(mdmRegion);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.MdmRegions.Where(w => w.RegionId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.MdmRegions.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}
