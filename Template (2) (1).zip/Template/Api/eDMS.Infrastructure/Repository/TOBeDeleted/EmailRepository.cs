﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Extension;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using static eDMS.Core.Entities.EmailSettingModel;
namespace eDMS.Infrastructure.Repository
{
    public class EmailRepository : IEmailRepository
    {
        private readonly EMailSettings _emailSettings;
        public EmailRepository(IOptions<EMailSettings> emailSettings)
        {
            _emailSettings = emailSettings.Value;
        }

        public async Task SendAsync(string from, string subject, string body, IEnumerable<string> to, List<Attachment> fileAttachments,
            IEnumerable<string> cc = null, IEnumerable<string> bcc = null)
        {
            using (var mc = new SmtpClient())
            {
                mc.Host = "127.0.0.1";
                var msg = new MailMessage { From = new MailAddress(from) };

                // var overrideEmails = ConfigurationManager.AppSettings["OverrideEmails"];
                //  if (!String.IsNullOrWhiteSpace(overrideEmails))
                //  {
                var originalRecipients = new StringBuilder();
                originalRecipients.AppendLine("TEST EMAIL - ORIGINAL RECIPIENTS:");

                if (to != null)
                {
                    originalRecipients.Append("TO: ")
                        .AppendLine(String.Join(",", to));
                    // to = null;
                }

                if (cc != null)
                {
                    originalRecipients.Append("CC: ")
                        .AppendLine(String.Join(",", cc));
                    // cc = null;
                }

                if (bcc != null)
                {
                    originalRecipients.Append("BCC: ")
                        .AppendLine(String.Join(",", bcc));
                    // bcc = null;
                }

                originalRecipients.AppendLine();
                body = originalRecipients.ToString() + body;

                //  to = overrideEmails.Split(',');
                // }

                if (to != null)
                {
                    foreach (var addr in to)
                    {
                        msg.To.Add(new MailAddress(addr));
                    }
                }

                if (cc != null)
                {
                    foreach (var addr in cc)
                    {
                        msg.CC.Add(new MailAddress(addr));
                    }
                }

                if (bcc != null)
                {
                    foreach (var addr in bcc)
                    {
                        msg.Bcc.Add(new MailAddress(addr));
                    }
                }

                msg.Subject = subject;
                msg.Body = body;
                //msg.IsBodyHtml = true;

                if (fileAttachments != null)
                {
                    foreach (Attachment attachments in fileAttachments)
                    {
                        msg.Attachments.Add(attachments);
                    }
                }
                mc.DeliveryMethod = SmtpDeliveryMethod.Network;
               // mc.Credentials = new System.Net.NetworkCredential("anuja.moharir@weatherford.com", "Yellowrose@2525");
                //mc.Credentials = new System.Net.NetworkCredential("anujamoharir@gmail.com", "Gajanan%2020");
                //  mc.UseDefaultCredentials = true;

                await mc.SendMailAsync(msg);
            }
        }


        public Task<int> sendEmailNotification(EmailEntity emailEntity)
        {
            int result = 0;
            using (MailMessage mm = new MailMessage(new MailAddress(emailEntity.From), new MailAddress(emailEntity.To)))
            {
               // mm.From = new MailAddress(emailEntity.From); 
                mm.Subject = emailEntity.Subject;
                mm.Body = emailEntity.Body;
                if (emailEntity.Attachment!=null && emailEntity.Attachment.Length > 0)
                {
                    string fileName = Path.GetFileName(emailEntity.Attachment.FileName);
                    mm.Attachments.Add(new Attachment(emailEntity.Attachment.OpenReadStream(), fileName));
                }
                mm.IsBodyHtml = false;
                using (SmtpClient smtp = new SmtpClient())
                {
                    if (_emailSettings != null)
                    {
                        if(!_emailSettings.smtpServer.IsNullOrEmpty())
                            smtp.Host = _emailSettings.smtpServer.ToString() ;//"smtp.gmail.com";
                        smtp.Port = _emailSettings.smtpPort;//587;
                        smtp.EnableSsl = bool.Parse(_emailSettings.enableSsl);
                    }

                    //  NetworkCredential NetworkCred = new NetworkCredential(emailEntity.Email, emailEntity.Password);
                    // smtp.UseDefaultCredentials = true;
                    // smtp.Credentials = NetworkCred;

                    smtp.Send(mm);

                    result = 1;
                }
            }
            return Task.FromResult(result);

        }
    }
}

