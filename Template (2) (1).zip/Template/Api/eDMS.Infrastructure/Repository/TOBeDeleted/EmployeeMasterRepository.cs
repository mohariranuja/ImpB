﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class EmployeeMasterRepository : IEmployeeMasterRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public EmployeeMasterRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ EmployeeMasterRepository Methods ]==================================================
        public async Task<IReadOnlyList<EmployeeMaster>> GetAllAsync()
        {
            return await _dbContext.EmployeeMasters.ToListAsync();
        }

        public async Task<ApprovalResultList> GetAllUserPendingRequestsAsync(int id, int? top = null, int? skip = null)
        {
            //IQueryable<ApprovalHistory> query = _dbContext.ApprovalHistories.Where(w => w.ApproverEmployeeId == id
            //            && w.IsApproved == null);
            IQueryable<ApprovalHistory> queryAll = _dbContext.ApprovalHistories;
            var ApprovalListAll = await queryAll.ToListAsync();
            IQueryable<ApprovalHistory> query = _dbContext.ApprovalHistories.Where(w => w.ApproverEmployeeId == id
             && !w.IsApproved.HasValue).GroupBy(x => new { x.DriverEmployeeId }).Select(y => y.OrderByDescending(d => d.ApprovalHistoryId).First());
            List<ApprovalHistory> lstApprovalHistory = new List<ApprovalHistory>();
            // IQueryable<ApprovalHistory> queryCount = query;            
            var countItem = await query.ToListAsync();
            foreach (var approvalHistory in countItem)
            {
                var filteredrecord = queryAll.Where(x => x.DriverEmployeeId == approvalHistory.DriverEmployeeId).OrderByDescending(y => y.ApprovalHistoryId).First();
                if (filteredrecord.ApproverEmployeeId == id)
                    lstApprovalHistory.Add(filteredrecord);
            }
            lstApprovalHistory = lstApprovalHistory.OrderByDescending(e => e.CreatedOn).ToList();

            int countSearch = lstApprovalHistory.Count;

            if (skip.HasValue)
            {
                lstApprovalHistory = lstApprovalHistory.Skip(skip.Value).ToList();
                //query = query.Skip(skip.Value);
            }
            if (top.HasValue)
            {
                lstApprovalHistory = lstApprovalHistory.Take(top.Value).ToList();
                //query = query.Take(top.Value);
            }

            //var employeeMasterList = await query.ToListAsync();
            var approvalResultList = new List<ApprovalResult>();

            foreach (var approval in lstApprovalHistory)//query.ToList()
            {
                var empMaster = _dbContext.EmployeeMasters.Where(w => w.EmpId == approval.DriverEmployeeId).FirstOrDefault();
                var managerList = new ApprovalResult
                {
                    ApprovalHistoryId = approval.ApprovalHistoryId,
                    EmpId = empMaster.EmpId,
                    EmplId = empMaster.EmplId,
                    FirstName = empMaster.FirstName,
                    LastName = empMaster.LastName,
                    MiddleName = empMaster.MiddleName,
                    //ManagerId = empMaster.ManagerId,
                    ManagerName = empMaster.ManagerName,
                    Location = empMaster.Location,
                    Country = empMaster.Country,
                    DriverType = empMaster.DriverType,
                    ManagerCode = empMaster.ManagerCode,
                    LoginUserId = approval.LoginUserId,
                    DriverEmployeeId = approval.DriverEmployeeId,
                    DriverTypeDescription = GetEmployeeDriverTypeDescription(approval.DriverEmployeeId)
                };
                approvalResultList.Add(managerList);
            }

            ApprovalResultList result = new ApprovalResultList();
            result.TotalCounts = countSearch;
            result.approvalResult = approvalResultList;
            return result;
        }

        public async Task<EmployeeMaster> GetByIdAsync(int id)
        {
            return await _dbContext.EmployeeMasters.Where(w => w.EmpId == id).FirstOrDefaultAsync();
        }

        public async Task<EmployeeData> GetByIdWithDriverTypeDescAsync(int id)
        {
            var data = await _dbContext.EmployeeMasters.Where(w => w.EmpId == id).FirstOrDefaultAsync();
            return GetEmployeeData(data);
        }

        public async Task<EmployeeMaster?> GetByCodeAsync(string code)
        {
            return await _dbContext.EmployeeMasters.Where(w => w.EmplId == code).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(EmployeeMaster employeeMasters)
        {
            var result = _dbContext.EmployeeMasters.AsNoTracking().Where(w => w.EmpId == employeeMasters.EmpId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.EmployeeMasters.Add(employeeMasters);
            }
            else
            {
                _dbContext.EmployeeMasters.Update(employeeMasters);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.EmployeeMasters.Where(w => w.EmpId == id).FirstOrDefault();

            if (result != null)
            {
                // result.IsActive= false;
                _dbContext.EmployeeMasters.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        //public async Task<EmployeesMasterTeamsResult> GetManyAsync(int managerId, int? top = null, int? skip = null, params string[] includeProperties)
        //{
        //    //int? manager = (_dbContext.EmployeeMasters.Where(w => w.ManagerId == managerId)?.FirstOrDefault()?.ManagerId);

        //    //IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(x => x.ManagerId == managerId);
        //    _dbContext.Database.OpenConnection();
        //    IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(x => x.ManagerId == managerId);
        //    _dbContext.Database.CloseConnection();

        //    foreach (var item in query)
        //    {
        //        _dbContext.Database.OpenConnection();
        //        IQueryable<EmployeeMaster> lavel2 = _dbContext.EmployeeMasters.Where(x => x.ManagerId == item.ManagerId);
        //        _dbContext.Database.CloseConnection();
        //        if (lavel2 != null)
        //        {

        //            foreach (var item1 in lavel2)
        //            {

        //            }
        //        }
        //    }

        //    if (includeProperties.Length > 0)
        //    {
        //        query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
        //    }
        //    int countSearch = query.Count();

        //    if (skip.HasValue)
        //    {
        //        query = query.Skip(skip.Value);
        //    }
        //    if (top.HasValue)
        //    {
        //        query = query.Take(top.Value);
        //    }

        //    var driverBehaviourList = await query.ToListAsync();

        //    var managerSearchResultList = new List<EmployeeMasterTeamsResult>();
        //    //managerSearchResultList.AddRange(driverBehaviourList.ConvertAll(x => new EmployeeMasterTeamsResult()
        //    //{
        //    //    EmailId = x.EmailId,
        //    //    EmpId = x.EmpId,
        //    //    EmployeeId = x.EmployeeId,
        //    //    Date1 = x.Date1,
        //    //    Time_Entered = x.Time_Entered,
        //    //    IncidentTypeId = x.IncidentTypeId,
        //    //    IncidentType = x.IncidentType,
        //    //    IncidentValueId = x.IncidentValueId,
        //    //    IncidentValue = x.IncidentValue,
        //    //    ViolationValueId = x.ViolationValueId,
        //    //    ViolationValue = x.ViolationValue,
        //    //    IsActive = x.IsActive,
        //    //    RiskIndex = x.RiskIndex,
        //    //    RiskIndexId = x.RiskIndexId,
        //    //    Descr200 = x.Descr200,
        //    //    DescrLong_Notes = x.DescrLong_Notes,
        //    //    Date2 = x.Date2,
        //    //    TIME_RECORDED = x.Time_Recorded,
        //    //    EFFDate = x.EFFDate,
        //    //    TIME_EDIT = x.Time_Edit,
        //    //    CreatedBy = x.CreatedBy,
        //    //    CreatedOn = x.CreatedOn,
        //    //    ModifiedBy = x.ModifiedBy,
        //    //    ModifiedOn = x.ModifiedOn
        //    //}));
        //    EmployeesMasterTeamsResult result = new EmployeesMasterTeamsResult();
        //    result.TotalCount = countSearch;
        //    result.employeesMasterTeamsResults = managerSearchResultList;
        //    return result;
        //}

        public Task<IReadOnlyList<EmployeeMaster>> GetManyAsync(Expression<Func<EmployeeMaster, bool>> filter = null)
        {
            throw new NotImplementedException();
        }

        public async Task<EmployeeMaster?> GetEmployeeByEmailAsync(string email)
        {
            return await _dbContext.EmployeeMasters.Where(w => w.EmailId == email).FirstOrDefaultAsync();
        }

        public async Task<ExpirationsReportSearchResult> GetManyAsyncResult(ExpirationReportSearchRequest request)
        {
            var paramName = new SqlParameter("@TotalCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            //var expRepSearchResult = await _dbContext.ExpirationReportSearchResults.FromSqlInterpolated<ExpirationReportSearchResult>($" {StoreProc.Sp_GetExpirationReportSearchList} {request.AlertPeriod},{request.EmplId}, {request.FirstName},{request.MiddleName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerCode},{request.HRStatus},{request.IsDriverEvaluator},{request.BusinessUnitId},{request.DivisionCode},{request.RegionCode},{request.DepartmentId},{request.ProductLineId},{request.SubProductLineId},{request.DQRecComplete},{request.IsQualifiedDriver},{request.LegalEntitydesc},{request.HireCountryCode},{request.START_INDEX},{request.PAGE_SIZE},{paramName} OUTPUT").ToListAsync();
            var expRepSearchResult = await _dbContext.ExpirationReportSearchResults.FromSqlInterpolated<ExpirationReportSearchResult>($" {StoreProc.Sp_GetExpirationReportSearchList} {request.AlertPeriod},{request.EmplId}, {request.FirstName},{request.MiddleName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerCode},{request.HRStatus},{request.IsDriverEvaluator},{request.BusinessUnitId},{request.DivisionCode},{request.RegionCode},{request.DepartmentId},{request.ProductLineId},{request.SubProductLineId},{request.DQRecComplete},{request.LegalEntitydesc},{request.HireCountryCode},{request.IsQualifiedDriver},{request.START_INDEX},{request.PAGE_SIZE},{paramName} OUTPUT").ToListAsync();

            // Access the output parameter value
            var outputValue = paramName.Value;
            // Use the output value as needed

            ExpirationsReportSearchResult result = new ExpirationsReportSearchResult();
            result.TotalCount = Convert.ToInt32(outputValue);
            result.expirationReportSearchResult = expRepSearchResult;
            return result;
        }

        public async Task<ViolationsReportResult> GetValidationReportResult(ExpirationReportSearchRequest request)
        {
            var paramName = new SqlParameter("@TotalCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            //var expRepSearchResult = await _dbContext.ViolationReportResults.FromSqlInterpolated<ViolationReportResult>
            //    ($" {StoreProc.Sp_GetViolationReport} {request.AlertPeriod}, {request.EmplId}, {request.FirstName}, {request.MiddleName}, {request.LastName}, {request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerCode},{request.HRStatus},{request.IsDriverEvaluator},{request.BusinessUnitId},{request.DivisionCode},{request.RegionCode},{request.DepartmentId},{request.ProductLineId},{request.SubProductLineId},{request.DQRecComplete},{request.IsQualifiedDriver},{request.START_INDEX},{request.PAGE_SIZE},{paramName} OUTPUT").ToListAsync();
            var expRepSearchResult = await _dbContext.ViolationReportResults.FromSqlInterpolated<ViolationReportResult>
                ($" {StoreProc.Sp_GetViolationReport} {request.AlertPeriod},{request.EmplId}, {request.FirstName},{request.MiddleName},{request.LastName},{request.SecondLastName},{request.AlternateCharacterName},{request.LocationCode},{request.ManagerCode},{request.HRStatus},{request.IsDriverEvaluator},{request.BusinessUnitId},{request.DivisionCode},{request.RegionCode},{request.DepartmentId},{request.ProductLineId},{request.SubProductLineId},{request.DQRecComplete},{request.LegalEntitydesc},{request.HireCountryCode},{request.IsQualifiedDriver},{request.START_INDEX},{request.PAGE_SIZE},{paramName} OUTPUT").ToListAsync();

            // Access the output parameter value
            var outputValue = paramName.Value;
            // Use the output value as needed

            ViolationsReportResult result = new ViolationsReportResult();
            result.TotalCount = Convert.ToInt32(outputValue);
            result.violationReportResult = expRepSearchResult;
            return result;
        }

        public async Task<DocumentUploadsReportResult> GetDocumentUploadReportResult(DocumentUploadReportRequest request)
        {
            var paramName = new SqlParameter("@TotalCount", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };
            var searchResult = await _dbContext.DocumentUploadResults.FromSqlInterpolated<DocumentUploadResult>
                ($" {StoreProc.Sp_GetDocumentUploadReport} {request.EmplId}, {request.FirstName}, {request.LastName}, {request.DLDocType}, {request.UploadStatus},{request.START_INDEX},{request.PAGE_SIZE},{paramName} OUTPUT").ToListAsync();

            // Access the output parameter value
            var outputValue = paramName.Value;
            // Use the output value as needed

            DocumentUploadsReportResult result = new DocumentUploadsReportResult();
            result.TotalCount = Convert.ToInt32(outputValue);
            result.documentUpload = searchResult;
            return result;
        }

        public async Task<ManagersSearchResult> GetEmployeeSearchList(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters.Where(x => x.EmpId != -1);

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var employeeMasterList = await query.ToListAsync();
            var managerSearchResultList = new List<ManagerSearchResult>();

            foreach (EmployeeMaster empMaster in employeeMasterList)
            {
                var managerList = new ManagerSearchResult { EmplId = empMaster.EmplId, EmpId = empMaster.EmpId, FirstName = empMaster.FirstName, LastName = empMaster.LastName, ManagerCode = empMaster.ManagerCode, ManagerName = empMaster.ManagerName };
                managerSearchResultList.Add(managerList);
            }
            ManagersSearchResult result = new ManagersSearchResult();
            result.TotalCount = countSearch;
            result.managerSearchResult = managerSearchResultList;
            return result;
        }

        public EmployeeData GetEmployeeData(EmployeeMaster empMaster)
        {
            EmployeeData empData = new EmployeeData()
            {
                EmpId = empMaster.EmpId,
                EmplId = empMaster.EmplId,
                FirstName = empMaster.FirstName,
                LastName = empMaster.LastName,
                MiddleName = empMaster.MiddleName,
                ManagerId = empMaster.ManagerId,
                LocationId = empMaster.LocationId,
                PositionId = empMaster.PositionId,
                DriverType = empMaster.DriverType,
                CountryId = empMaster.CountryId,
                IsQualifiedDriver = empMaster.IsQualifiedDriver,
                IsHRActive = empMaster.IsHRActive,
                LastLoggedIn = empMaster.LastLoggedIn,
                PreferredLanguage = empMaster.PreferredLanguage,
                CreatedBy = empMaster.CreatedBy,
                CreatedOn = empMaster.CreatedOn,
                ModifiedBy = empMaster.ModifiedBy,
                ModifiedOn = empMaster.ModifiedOn,
                EmpType = empMaster.EmpType,
                HRStatus = empMaster.HRStatus,
                EmpStatus = empMaster.EmpStatus,
                AlternateName = empMaster.AlternateName,
                SecondLastName = empMaster.SecondLastName,
                DisplayName = empMaster.DisplayName,
                HRId = empMaster.HRId,
                HRName = empMaster.HRName,
                FullTimePartTime = empMaster.FullTimePartTime,
                HireDate = empMaster.HireDate,
                TerminationDate = empMaster.TerminationDate,
                Sex = empMaster.Sex,
                MaritalStatus = empMaster.MaritalStatus,
                DateOfBirth = empMaster.DateOfBirth,
                CountryOfBirth = empMaster.CountryOfBirth,
                EmailId = empMaster.EmailId,
                Nationality = empMaster.Nationality,
                CompanySanctionedDriver = empMaster.CompanySanctionedDriver,
                CommercialDriverLicense = empMaster.CommercialDriverLicense,
                Country = empMaster.Country,
                State = empMaster.State,
                ProductLine = empMaster.ProductLine,
                ProductLineDescription = empMaster.ProductLineDescription,
                SubProductLine = empMaster.SubProductLine,
                SubProductLineDescription = empMaster.SubProductLineDescription,
                Location = empMaster.Location,
                LocationDescription = empMaster.LocationDescription,
                DepartmentId = empMaster.DepartmentId,
                DepartmentDescription = empMaster.DepartmentDescription,
                JobCode = empMaster.JobCode,
                JobCodeDescription = empMaster.JobCodeDescription,
                PositionDescription = empMaster.PositionDescription,
                ReportsTo = empMaster.ReportsTo,
                ReportsToDescription = empMaster.ReportsToDescription,
                ManagerName = empMaster.ManagerName,
                BusinessUnit = empMaster.BusinessUnit,
                BusinessUnitDescription = empMaster.BusinessUnitDescription,
                Devision = empMaster.Devision,
                DevisionDescription = empMaster.DevisionDescription,
                Region = empMaster.Region,
                CostCenter = empMaster.CostCenter,
                Action = empMaster.Action,
                ActionReason = empMaster.ActionReason,
                ManagerCode = empMaster.ManagerCode
            };
            empData.DriverTypeDescription = GetEmployeeDriverTypeDescription(empMaster.EmpId);
            return empData;
        }

        private string GetEmployeeDriverTypeDescription(int empId)
        {
            DriverLicenseRepository dlr = new DriverLicenseRepository(_dbContext);
            var data = dlr.GetByEmployeeID(empId);
            string driverTypeDescription = string.Empty;
            if (data.Result?.DriverTypeId > 0)
            {
                int driverTypeId = data.Result.DriverTypeId.Value;
                DriverTypeRepository dtr = new DriverTypeRepository(_dbContext);
                driverTypeDescription = dtr.GetByIdAsync(driverTypeId).Result.DriverTypeDescription;
            }
            return driverTypeDescription;
        }
        #endregion
    }
}