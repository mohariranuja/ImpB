﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;

namespace eDMS.Infrastructure.Repository
{
    public class EmployeeTeamsSearchRepository : IEmployeesMasterTeamsRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public EmployeeTeamsSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        public async Task<EmployeesMasterTeamsResult> GetManyAsync(
            Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null, 
            string managerCode = null, int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> allEmployeeList = _dbContext.EmployeeMasters.ToList().AsQueryable();
            List<EmployeeMaster> sortedTeamsInfoList = new List<EmployeeMaster>();
            List<EmployeeMaster> matchedTeamsReporting = allEmployeeList.Where(x => x.ManagerCode == managerCode).ToList();

            if (matchedTeamsReporting != null)
            {
                sortedTeamsInfoList.AddRange(matchedTeamsReporting);
                var removedMatchedEmpItr1 = allEmployeeList.Except(sortedTeamsInfoList).ToList();
                foreach (var matchedTeamsReportingLevel2 in matchedTeamsReporting)
                {
                    List<EmployeeMaster> getLevel2ReportingTeams = removedMatchedEmpItr1.Where(x =>
                    x.ManagerCode.ToString().Trim() == matchedTeamsReportingLevel2.EmplId.Trim()).ToList();

                    if (getLevel2ReportingTeams != null)
                    {
                        sortedTeamsInfoList.AddRange(getLevel2ReportingTeams);
                        var removedMatchedEmpIt2 = removedMatchedEmpItr1.Except(getLevel2ReportingTeams).ToList();

                        foreach (var getLevel2RepoterTeam in getLevel2ReportingTeams)
                        {
                            List<EmployeeMaster> getLevel3ReportingTeams = removedMatchedEmpIt2.Where(x =>
                            x.ManagerCode.ToString().Trim() == getLevel2RepoterTeam.EmplId.Trim()).ToList();

                            if (getLevel3ReportingTeams != null)
                            {
                                sortedTeamsInfoList.AddRange(getLevel3ReportingTeams);
                            }
                        }
                    }
                }
            }
            IQueryable<EmployeeMaster> query = sortedTeamsInfoList.AsQueryable();

            if (orderBy != null)
            {
                query = orderBy(query);
            }

            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = queryCount.ToList();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            List<EmployeeMaster> employeesManagerList = query.ToList();
            //var employeeManagerSearchResponceList = new List<EmployeeMasterTeamsResult>();
            //foreach (EmployeeMaster employee in employeesManagerList)
            //{
            //    var employeeManagerSearchList = new EmployeeMasterTeamsResult
            //    {
            //        EmpId = employee.EmpId,
            //        ManagerId = employee.ManagerId,
            //        ManagerName = employee.ManagerName,
            //        EmplId = employee.EmplId,
            //        FirstName = employee.FirstName,
            //        MiddleName = employee.MiddleName,
            //        LastName = employee.LastName,
            //        SecondLastName = employee.SecondLastName,
            //        Country = employee.Country,
            //        EmpStatus = employee.EmpStatus,
            //        CommercialDriverLicense = employee.CommercialDriverLicense,
            //        Location = employee.Location,
            //        LocationId = employee.LocationId,
            //        PositionId = employee.PositionId,
            //        PositionDescription = employee.PositionDescription,
            //        CountryId = employee.CountryId,
            //        DateOfBirth = employee.DateOfBirth,
            //        IsHRActive = employee.IsHRActive,
            //        LastLoggedIn = employee.LastLoggedIn,
            //        PreferredLanguage = employee.PreferredLanguage,
            //        CreatedBy = employee.CreatedBy,
            //        CreatedOn = employee.CreatedOn,
            //        ModifiedBy = employee.ModifiedBy,
            //        ModifiedOn = employee.ModifiedOn,
            //        EmpType = employee.EmpType,
            //        HRId = employee.HRId,
            //        HRStatus = employee.HRStatus,
            //        AlternateName = employee.AlternateName,
            //        DisplayName = employee.DisplayName,
            //        FullTimePartTime = employee.FullTimePartTime,
            //        DepartmentDescription = employee.DepartmentDescription,
            //        HireDate = employee.HireDate,
            //        TerminationDate = employee.TerminationDate,
            //        MaritalStatus = employee.MaritalStatus,
            //        DepartmentId = employee.DepartmentId,
            //        ProductLine = employee.ProductLine,
            //        ProductLineDescription = employee.ProductLineDescription,
            //        SubProductLine = employee.SubProductLine,
            //        SubProductLineDescription = employee.SubProductLineDescription,
            //        BusinessUnit = employee.BusinessUnit,
            //        Action = employee.Action,
            //        ActionReason = employee.ActionReason,
            //        BusinessUnitDescription = employee.BusinessUnitDescription,
            //        CompanySanctionedDriver = employee.CompanySanctionedDriver,
            //        CostCenter = employee.CostCenter,
            //        CountryOfBirth = employee.CountryOfBirth,
            //        Devision = employee.Devision,
            //        DevisionDescription = employee.DevisionDescription,
            //        EmailId = employee.EmailId,
            //        HRName = employee.HRName,
            //        JobCode = employee.JobCode,
            //        JobCodeDescription = employee.JobCodeDescription,
            //        LocationDescription = employee.LocationDescription,
            //        Nationality = employee.Nationality,
            //        Region = employee.Region,
            //        ReportsTo = employee.ReportsTo,
            //        ReportsToDescription = employee.ReportsToDescription,
            //        Sex = employee.Sex,
            //        State = employee.State,
            //        IsQualifiedDriver = employee.IsQualifiedDriver,
            //        DriverType = employee.DriverType

            //    };
            //    employeeManagerSearchResponceList.Add(employeeManagerSearchList);
            //}
            List<EmployeeData> empDataList = new List<EmployeeData>();
            EmployeeMasterRepository emr = new EmployeeMasterRepository(_dbContext);
            foreach (EmployeeMaster empMaster in employeesManagerList) {
                var empData = emr.GetEmployeeData(empMaster);
                empDataList.Add(empData);
            }
            EmployeesMasterTeamsResult result = new EmployeesMasterTeamsResult();
            result.TotalCount = countSearch;
            result.employeesMasterTeamsResults = empDataList;
            return result;
            //throw new NotImplementedException();
        }
    }
}