﻿
    using eDMS.Application.Interfaces;
    using eDMS.Core.Entities;
    using eDMS.Core.Model;
    using eDMS.Infrastructure.Persistence;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;

    using System.Threading.Tasks;

    namespace eDMS.Infrastructure.Repository
{
    public class MDMLegalEntitySearchRepository : IMDMLegalEntitySearchRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public MDMLegalEntitySearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ IMDMLegalEntitySearchRepository Methods ]==================================================




        public async Task<GenericMastersSearchResult> GetManyMDMLegalEntityAsync(Expression<Func<MDMLegalEntity, bool>> filter = null, Func<IQueryable<MDMLegalEntity>, IOrderedQueryable<MDMLegalEntity>> orderBy = null, int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<MDMLegalEntity> query = _dbContext.MDMLegalEntities;


            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<MDMLegalEntity> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var pagesitem = await query.ToListAsync();
            var genericMasterResultList = new List<GenericMasterResult>();
            foreach (MDMLegalEntity empMaster in pagesitem)
            {

                var deptList = new GenericMasterResult { LegalEntityId = empMaster.LegalEntityId, LegalEntityName = empMaster.LegalEntityName, LegalEntityDescription= empMaster.LegalEntityDesc };
                genericMasterResultList.Add(deptList);
            }


            GenericMastersSearchResult result = new GenericMastersSearchResult();
            result.TotalCount = countSearch;
            result.genericMasterResultList = genericMasterResultList;
            return result;
            
        }
           



        #endregion
    }


}
