﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class ViolationSeverityMatrixRepository:IViolationSeverityMatrixRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public ViolationSeverityMatrixRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IViolationSeverityMatrixRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMViolationSeverityMatrix>> GetAllAsync()
        {
            return await _dbContext.ViolationSeverityMatrices.ToListAsync();
        }

        public async Task<MDMViolationSeverityMatrix> GetByIdAsync(int id)
        {
            //return await _dbContext.ViolationSeverityMatrices.Where(w => w.ViolationSeverityMatrixId == id && w.IsActiveViolationSeverityMatrix == true).FirstOrDefaultAsync();
            return await _dbContext.ViolationSeverityMatrices.Where(w => w.ViolationSeverityMatrixId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(MDMViolationSeverityMatrix mDMViolationSeverityMatrix)
        {
            var result = _dbContext.ViolationSeverityMatrices.AsNoTracking().Where(w => w.ViolationSeverityMatrixId ==mDMViolationSeverityMatrix.ViolationSeverityMatrixId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.ViolationSeverityMatrices.Add(mDMViolationSeverityMatrix);
            }
            else
            {
                _dbContext.ViolationSeverityMatrices.Update(mDMViolationSeverityMatrix);
            }
            return await _dbContext.SaveChangesAsync();
        }
        
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.ViolationSeverityMatrices.Where(w => w.ViolationSeverityMatrixId == id && w.IsActiveViolationSeverityMatrix == true).FirstOrDefault();

            if (result != null)
            {
                result.IsActiveViolationSeverityMatrix = false;
                _dbContext.ViolationSeverityMatrices.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}