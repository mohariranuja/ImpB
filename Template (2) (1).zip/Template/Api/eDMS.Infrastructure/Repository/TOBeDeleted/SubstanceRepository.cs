﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class SubstanceRepository : ISubstanceRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public SubstanceRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region ===[ ISubstanceRepository Methods ]==================================================
        public async Task<IReadOnlyList<Substance>> GetAllAsync()
        {
            return await _dbContext.Substances.Where(r => r.IsActive == true).ToListAsync();
        }
        public async Task<Substance> GetByIdAsync(int id)
        {
            return await _dbContext.Substances.Where(w => w.SubstanceId == id).FirstOrDefaultAsync();
        }
        public async Task<int> SaveAsync(Substance substance)
        {
            var result = _dbContext.Substances.AsNoTracking().Where(w => w.SubstanceId == substance.SubstanceId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.Substances.Add(substance);
            }
            else
            {
                _dbContext.Substances.Update(substance);
            }
            return await _dbContext.SaveChangesAsync();
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.Substances.Where(w => w.SubstanceId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.Substances.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}