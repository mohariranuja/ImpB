﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class SampleTypeRepository : ISampleTypeRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
    
        #region ===[ Constructor ]=================================================================
        public SampleTypeRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region ===[ IIncidentTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<SampleType>> GetAllAsync()
        {
            return await _dbContext.SampleTypes.Where(w => w.IsActive == true).ToListAsync();
        }

        public async Task<SampleType> GetByIdAsync(int id)
        {
            return await _dbContext.SampleTypes.Where(w => w.SampleTypeId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(SampleType sampleType)
        {
            var result = _dbContext.SampleTypes.AsNoTracking().Where(w => w.SampleTypeId == sampleType.SampleTypeId).FirstOrDefault();

            if (result == null)
            {
                sampleType.CreatedOn = DateTime.Now;
                _dbContext.SampleTypes.Add(sampleType);
            }
            else
            {
                sampleType.ModifiedBy = sampleType.CreatedBy;
                sampleType.ModifiedOn = DateTime.Now;
                sampleType.CreatedBy = result.CreatedBy;
                sampleType.CreatedOn = result.CreatedOn;
                _dbContext.SampleTypes.Update(sampleType);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.SampleTypes.Where(w => w.SampleTypeId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.SampleTypes.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<SampleTypeResponseList> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        {
            IQueryable<SampleType> query = _dbContext.SampleTypes.OrderByDescending(x => x.SampleTypeId);

            IQueryable<SampleType> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var sampleTypeList = await query.ToListAsync();
            var sampleTypeResponce_List = new List<SampleTypeResponse>();
            foreach (SampleType sampleType in sampleTypeList)
            {
                var sampleTypes = new SampleTypeResponse
                {
                    SampleTypeId = sampleType.SampleTypeId,
                    SampleTypeName = sampleType.SampleTypeName,
                    TestCategoryId = sampleType.TestCategoryId,
                    TestCategoryName = sampleType.TestCategoryName,
                    TestTypeId= sampleType.TestTypeId,
                    TestTypeName = sampleType.TestTypeName,
                    FieldValue = sampleType.FieldValue,
                    IsActive = sampleType.IsActive
                };
                sampleTypeResponce_List.Add(sampleTypes);
            }

            SampleTypeResponseList result = new SampleTypeResponseList();
            result.TotalCount = countSearch;
            result.sampleTypeResponseList = sampleTypeResponce_List;
            return result;
        }
        #endregion
    }
}