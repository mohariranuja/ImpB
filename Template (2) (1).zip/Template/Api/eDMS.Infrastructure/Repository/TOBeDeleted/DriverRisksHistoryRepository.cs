﻿using eDMS.Application.Interfaces;
using eDMS.Core;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DriverRisksHistoryRepository : IDriverRisksHistoryRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriverRisksHistoryRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion
        
        #region ===[ Public Methods ]=================================================================
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DriverRisksHistories.Where(w => w.DriverRiskId == id).FirstOrDefault();

            if (result != null)
            {
                 result.IsActive= false;
                _dbContext.DriverRisksHistories.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<IReadOnlyList<DriverRisksHistory>> GetAllAsync()
        {
            return await _dbContext.DriverRisksHistories.ToListAsync();
        }

        public async Task<DriverRisksHistory> GetByIdAsync(int id)
        {
            return await _dbContext.DriverRisksHistories.Where(w => w.DriverRiskId == id).FirstOrDefaultAsync();
        }

        public async Task<IReadOnlyList<DriverRisksHistory>> GetAllDLRiskTypeAsync(int driverLicenseId, int riskTypeId)
        {
            return await _dbContext.DriverRisksHistories.Where(w => w.DriverLicenseId == driverLicenseId
            && w.RiskTypeId == riskTypeId).OrderByDescending(r => r.PeriodEnd).ToListAsync();
        }

        public async Task<DriverRisksHistory?> GetByDLRiskTypeAsync(int driverLicenseId, int riskTypeId)
        {
            return await _dbContext.DriverRisksHistories.Where(w => w.DriverLicenseId == driverLicenseId
            && w.RiskTypeId == riskTypeId).OrderByDescending(r=> r.PeriodEnd).FirstOrDefaultAsync();
        }

        public  async Task<int> SaveAsync(DriverRisksHistory entity)
        {
            var result = _dbContext.DriverRisksHistories.AsNoTracking().Where(w => w.DriverRiskId == entity.DriverRiskId
                                                            ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DriverRisksHistories.Add(entity);
            }
            else
            {
                entity.ModifiedBy = 2;
                entity.ModifiedOn = DateTime.Now;
                _dbContext.DriverRisksHistories.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<AuditReportResponses> GetDriverAuditListAsync(int driverLicId,int? top = null, int? skip = null)
        {
            int riskTypeId = _dbContext.RiskTypes.Where(w => w.RiskType == eDMSConstant.OverallRisk).FirstOrDefaultAsync().Result.RiskTypeId; 
            var riskData = await _dbContext.DriverRisksHistories.Where(w => w.DriverLicenseId == driverLicId
            && w.RiskTypeId == riskTypeId).OrderByDescending(r => r.PeriodEnd).ToListAsync();
            var driverData = riskData.ToList().OrderBy(r => r.PeriodStart);
            var riskIndexesData = await _dbContext.MDMRiskIndexes.ToListAsync();
            var auditData = new List<AuditReportResponse>();
            foreach (var driverRisk in driverData)
            {
               // if (driverRisk.RiskIndexValueId == 1 || driverRisk.RiskIndexValueId == 2)
               // {
                    var auditDataRow = new AuditReportResponse
                    {
                        DriverRiskId = driverRisk.DriverRiskId,
                        RiskIndex = riskIndexesData?.Where(r => r.RiskIndexId == driverRisk.RiskIndexValueId).FirstOrDefault()?.RiskIndex,
                        ModifiedOn = driverRisk.PeriodStart,
                        ModifiedBy = driverRisk.ModifiedBy,
                        ModifiedByName = await GetUserName(driverRisk.ModifiedBy)
                    };

                    if (auditData.Count() == 0)
                        auditData.Add(auditDataRow);
                    else if (auditDataRow.RiskIndex != auditData[auditData.Count() - 1].RiskIndex)
                        auditData.Add(auditDataRow);
                    else
                    {
                        int index = auditData.Count() - 1;
                        auditData[index].DriverRiskId = auditDataRow.DriverRiskId;
                        auditData[index].RiskIndex = auditDataRow.RiskIndex;
                        auditData[index].ModifiedOn = auditDataRow.ModifiedOn;
                        auditData[index].ModifiedBy = auditDataRow.ModifiedBy;
                        auditData[index].ModifiedByName = auditDataRow.ModifiedByName;
                    }
                //}
            }
            auditData=auditData.OrderByDescending(r => r.ModifiedOn).ToList();
            int countSearch = auditData.Count;

            if (skip.HasValue)
            {
                auditData = auditData.Skip(skip.Value).ToList();
            }
            if (top.HasValue)
            {
                auditData = auditData.Take(top.Value).ToList();
            }

            var approvalResultList = new List<ApprovalResult>();
            AuditReportResponses result = new AuditReportResponses();
            result.TotalCounts = countSearch;
            result.auditResponse = auditData.OrderByDescending(r=>r.ModifiedOn).ToList();
            return result;
        }

        public async Task<string> GetUserName(int? empId)
        {
            string empName;
            if (empId == -1 || empId == null)
                empName = eDMSConstant.systemUser;
            else
            {
                var employeeData = _dbContext.EmployeeMasters.Where(r => r.EmpId == Convert.ToInt32(empId))?.FirstOrDefault();
                empName = (employeeData == null) ? eDMSConstant.systemUser : employeeData.FirstName + " " + employeeData.LastName;
            }
            return empName;
        }
        #endregion
    }
}