﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class PSDRIVERLTYPTBLRepository : IPSDRIVERLTYPTBLRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public PSDRIVERLTYPTBLRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IDLUPLDWRKRepository Methods ]==================================================
        public async Task<IReadOnlyList<PSDRIVERLTYPTBL>> GetAllAsync()
        {
            return await _dbContext.PSDRIVERLTYPTBLs.ToListAsync();
        }

        public async Task<PSDRIVERLTYPTBL> GetByIdAsync(int id)
        {
            return await _dbContext.PSDRIVERLTYPTBLs.Where(w => w.EFFStatus == "A" && w.DriverLTypTblId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(PSDRIVERLTYPTBL entity)
        {
            var result = _dbContext.PSDRIVERLTYPTBLs.AsNoTracking().Where(w => w.Country == entity.Country
            && w.LicenseType == entity.LicenseType).FirstOrDefault();

            if (result == null)
            {
                _dbContext.PSDRIVERLTYPTBLs.Add(entity);
            }
            else
            {
                if (result.IsActive == false)
                    result.IsActive = true;
                _dbContext.PSDRIVERLTYPTBLs.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.PSDRIVERLTYPTBLs.Where(w => w.EFFStatus == "A" && w.DriverLTypTblId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.PSDRIVERLTYPTBLs.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}