﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class MDMManagerAccessListRepository : IMDMManagerAccessListRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public MDMManagerAccessListRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IMDMManagerAccessListRepository Methods ]==================================================

        public async Task<IReadOnlyList<MDMManagerCountryAccess>> GetManyAsync(int emplID)
        {
            IQueryable<MDMManagerAccess> query = _dbContext.MDMManagerAccesses.Where(x => x.UserId == emplID);
            IQueryable<Country> queryCountry = _dbContext.Countries;
            var mDMMangerAccessList = await query.ToListAsync();
            var countryList = await queryCountry.ToListAsync();
            List<MDMManagerCountryAccess> mDMManagerCountryAccessList = new List<MDMManagerCountryAccess>();
            if (mDMMangerAccessList != null && mDMMangerAccessList.Count > 0)
            {
                string[] countryIds = mDMMangerAccessList[0].CountryId.Split(',');
                if (countryIds.Length > 0)
                {
                    foreach (string id in countryIds)
                    {
                        MDMManagerCountryAccess managerAccessCountry = new MDMManagerCountryAccess();
                        managerAccessCountry.UserId = mDMMangerAccessList[0].UserId;
                        managerAccessCountry.CreatedBy = mDMMangerAccessList[0].CreatedBy;
                        managerAccessCountry.CreatedOn = mDMMangerAccessList[0].CreatedOn;
                        managerAccessCountry.IsActive = mDMMangerAccessList[0].IsActive;
                        managerAccessCountry.CountryIds = id;
                        managerAccessCountry.CountryName = countryList?.Where(x => x.CountryId == Convert.ToInt32(id)).FirstOrDefault().CountryName;
                        mDMManagerCountryAccessList.Add(managerAccessCountry);
                    }
                }
            }
            return mDMManagerCountryAccessList;
        }

        public async Task<MDMManagerAccessSearchResult> GetMananagerAccessList(int userId, string? CountryIds, int? top = null,
            int? skip = null)
        {
            ApplicationDBContext _context = new ApplicationDBContext();
            List<int> countryList = new List<int>();
            List<MDMManagerAccessResult> employees = new List<MDMManagerAccessResult>();
            if (string.IsNullOrEmpty(CountryIds))
            {
                string countries = _context.MDMManagerAccesses.Where(x => x.UserId == userId).FirstOrDefault().CountryId.ToString();
                if (!string.IsNullOrEmpty(countries))
                {
                    string[] _countryids = countries.Split(',');
                    for (int i = 0; i < _countryids.Length; i++)
                        countryList.Add(Convert.ToInt32(_countryids[i].Trim()));
                }
            }
            else
            {
                string[] _countryids = CountryIds.Split(',');
                for (int i = 0; i < _countryids.Length; i++)
                    countryList.Add(Convert.ToInt32(_countryids[i].Trim()));
            }

            foreach (int countryId in countryList)
            {
                var countryEmps = await _context.EmployeeMasters.Where(x => x.CountryId == countryId && x.HRStatus == "A").ToListAsync();
                var licenses = await _context.DriverLicenses.ToListAsync();
                foreach (EmployeeMaster emp in countryEmps)
                {
                    var dl = licenses.Where(x => x.EmployeeId == emp.EmpId).OrderByDescending(x => x.ExpirationDT).FirstOrDefault();
                    if (dl != null)
                    {
                        int? dlTypeID = dl?.DriverTypeId;
                        var driverType = await _context.DriverTypes.Where(w => w.DriverTypeId == dlTypeID).FirstOrDefaultAsync();
                        string driverTypeDesc = driverType?.DriverTypeDescription;

                        MDMManagerAccessResult managerAccessResult = new MDMManagerAccessResult()
                        {
                            EmpId = emp.EmpId,
                            EmplId = emp.EmplId,
                            FirstName = emp.FirstName,
                            LastName = emp.LastName,
                            MiddleName = emp.MiddleName,
                            HireCountry = emp.HireCountry,
                            ManagerCode = emp.ManagerCode,
                            ManagerName = emp.ManagerName,
                            DriverType = driverTypeDesc,//dl.DriverType,
                            QualifiedDriver = (emp.IsQualifiedDriver == true) ? "Yes" : "No"
                        };
                        employees.Add(managerAccessResult);
                    }
                }
            }

            int countSearch = employees.Count;
            if (skip.HasValue)
                employees = employees.Skip(skip.Value).ToList();
            if (top.HasValue)
                employees = employees.Take(top.Value).ToList();

            MDMManagerAccessSearchResult result = new MDMManagerAccessSearchResult();
            result.TotalCount = countSearch;
            result.managerUserAccess = employees;
            return result;
        }
        #endregion
    }
}