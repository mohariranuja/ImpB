﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DLUPLDWRKRepository : IDLUPLDWRKRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public DLUPLDWRKRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IDLUPLDWRKRepository Methods ]==================================================
        public async Task<IReadOnlyList<DLUPLDWRK>> GetAllAsync()
        {
            return await _dbContext.DLUPLDWRKs.ToListAsync();
        }

        public async Task<DLUPLDWRK> GetByIdAsync(int id)
        {
            return await _dbContext.DLUPLDWRKs.Where(w => w.DL_UPLD_WRK_Id == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(DLUPLDWRK entity)
        {
            DLUPLDWRK result;
            if (entity.DL_UPLD_WRK_Id == 0)
                result = _dbContext.DLUPLDWRKs.AsNoTracking().Where(w => w.EmployeeId == entity.EmployeeId
                && w.DLDocType == entity.DLDocType && w.DocCategory== entity.DocCategory).FirstOrDefault();
            else
                result = _dbContext.DLUPLDWRKs.AsNoTracking().Where(w => w.DL_UPLD_WRK_Id == entity.DL_UPLD_WRK_Id).FirstOrDefault();

            if (result == null)
            {
                entity.CreatedBy = entity.EmployeeId;
                entity.CreatedOn = DateTime.Now;
                _dbContext.DLUPLDWRKs.Add(entity);
            }
            else
            {
                entity.DL_UPLD_WRK_Id = result.DL_UPLD_WRK_Id;
                entity.CreatedBy = result.CreatedBy;
                entity.CreatedOn = result.CreatedOn;
                entity.ModifiedBy = entity.EmployeeId;
                entity.ModifiedOn = DateTime.Now;
                entity.IsActive = true;
                _dbContext.DLUPLDWRKs.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<DLUPLDWRK> GetDetailToSave(DLUPLDWRK entity)
        {
            return await _dbContext.DLUPLDWRKs.AsNoTracking().Where(w => w.EmployeeId == entity.EmployeeId
                && w.DLDocType == entity.DLDocType && w.DocCategory == entity.DocCategory).FirstOrDefaultAsync();            
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DLUPLDWRKs.Where(w => w.DL_UPLD_WRK_Id == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.DLUPLDWRKs.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<DLUPLDWRK> GetWrkForEmployeeAsync(int empId, string docCategory,
            string dlDocType)
        {
            //var listDLWRK = new List<DLUPLDWRK>();
            //return await _dbContext.DLUPLDWRKs.Where(r=> r.EmployeeId == empId && r.IsActive == true).OrderByDescending(x=> x.DL_UPLD_WRK_Id).Take(2).ToListAsync();
            return await _dbContext.DLUPLDWRKs.Where(r => r.EmployeeId == empId && r.IsActive == true
                && r.DocCategory == docCategory && r.DLDocType == dlDocType)
                .OrderByDescending(x => x.ValidToDate).FirstOrDefaultAsync();
        }
        #endregion
    }
}