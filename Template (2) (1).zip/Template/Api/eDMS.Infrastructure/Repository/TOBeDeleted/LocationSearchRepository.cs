﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class LocationSearchRepository :ILocationSearchRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public LocationSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ ILocationSearchRepository Methods ]==================================================


        public async Task<LocationsSearchResult> GetManyAsync(
        Expression<Func<MDMLocation, bool>> filter = null,
        Func<IQueryable<MDMLocation>, IOrderedQueryable<MDMLocation>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<MDMLocation> query = _dbContext.Locations;
            
            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<MDMLocation> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

           
            var mDMLocationList = await query.ToListAsync();
            var locationSearchResultList = new List<LocationSearchResult>();

            foreach (MDMLocation mdmLocation in mDMLocationList)
            {
                var locationList = new LocationSearchResult { LocationId= mdmLocation.LocationId, LocationCode = mdmLocation.Locationcode, LocationDescription = mdmLocation.LocationDescription, IsActiveLocation = mdmLocation.IsActiveLocation, CreatedBy= mdmLocation.CreatedBy };
                locationSearchResultList.Add(locationList);
            }
            LocationsSearchResult result = new LocationsSearchResult();
            result.TotalCount = countSearch;
            result.locationSearchResult = locationSearchResultList;
            return result;
            // return await query.ToListAsync();
        }

        #endregion
    }
}
