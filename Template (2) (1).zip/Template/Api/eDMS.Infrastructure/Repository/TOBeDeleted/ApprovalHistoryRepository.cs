﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class ApprovalHistoryRepository : IApprovalHistoryRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public ApprovalHistoryRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IApprovalHistoryRepository Methods ]==================================================
        public async Task<IReadOnlyList<ApprovalHistory>> GetAllAsync()
        {
            return await _dbContext.ApprovalHistories.ToListAsync();
        }

        public async Task<ApprovalHistory> GetByIdAsync(int id)
        {
            return await _dbContext.ApprovalHistories.Where(w => w.ApprovalHistoryId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(ApprovalHistory entity)
        {
            var result = _dbContext.ApprovalHistories.AsNoTracking().Where(w => w.ApprovalHistoryId == entity.ApprovalHistoryId
                                                            ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.ApprovalHistories.Add(entity);
            }
            else
            {
                _dbContext.ApprovalHistories.Update(entity);
            }
            int saveResult = await _dbContext.SaveChangesAsync();
            if (saveResult > 0 && result == null)
            {
                var approvalH = _dbContext.ApprovalHistories.Where(r => r.ApproverEmployeeId == entity.ApproverEmployeeId &&
                    r.LoginUserId == entity.LoginUserId && r.DriverEmployeeId == entity.DriverEmployeeId)
                    .OrderByDescending(r => r.CreatedOn).FirstOrDefaultAsync();
                return approvalH.Result.ApprovalHistoryId;
            }
            else
                return saveResult;
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.ApprovalHistories.Where(w => w.ApprovalHistoryId == id
                                                           ).FirstOrDefault();

            if (result != null)
            {
                result.IsActive = false;
                _dbContext.ApprovalHistories.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}