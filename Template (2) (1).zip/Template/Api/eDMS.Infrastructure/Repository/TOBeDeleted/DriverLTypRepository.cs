﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class DriverLTypRepository : IDriverLTypRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriverLTypRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IDLUPLDWRKRepository Methods ]==================================================
        public async Task<IReadOnlyList<DriverLTyp>> GetAllAsync()
        {
            return await _dbContext.DriverLTyps.ToListAsync();
        }

        public async Task<DriverLTyp> GetByIdAsync(int id)
        {
            return await _dbContext.DriverLTyps.Where(w => w.IsActive == true && w.DriverLTypId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(DriverLTyp entity)
        {
            DriverLTyp result;
            if (entity.DriverLTypId == 0)
                result = _dbContext.DriverLTyps.AsNoTracking().Where(w => w.EmployeeId == entity.EmployeeId 
                && w.LicenseType == entity.LicenseType).FirstOrDefault();
            else
                result = _dbContext.DriverLTyps.AsNoTracking().Where(w => w.DriverLTypId == entity.DriverLTypId).FirstOrDefault();

            if (result == null)
            {
                entity.CreatedBy = entity.EmployeeId;
                entity.CreatedOn = DateTime.Now;
                entity.IsActive = true;
                _dbContext.DriverLTyps.Add(entity);
            }
            else
            {
                entity.DriverLTypId = result.DriverLTypId;
                entity.CreatedBy = result.CreatedBy;
                entity.CreatedOn = result.CreatedOn;
                entity.ModifiedBy = entity.EmployeeId;
                entity.ModifiedOn = DateTime.Now;
                entity.IsActive = true;
                _dbContext.DriverLTyps.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DriverLTyps.Where(w => w.IsActive == true && w.DriverLTypId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.DriverLTyps.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteForEmployeeAsync(int id)
        {
            var result = _dbContext.DriverLTyps.Where(w => w.IsActive == true && w.EmployeeId == id).ToListAsync();
            if (result != null)
            {
                foreach (var lTyp in result.Result)
                {
                    lTyp.IsActive = false;
                    _dbContext.DriverLTyps.Update(lTyp);
                }
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<IReadOnlyList<DriverLTyp>> GetAllForEmployeeIdAsync(int id)
        {
            return await _dbContext.DriverLTyps.Where(r=> r.EmployeeId == id && r.IsActive == true).ToListAsync();
        }

        public async Task<int> UpdateDLTypes(DriverLTyp dltypes, List<string> typelists)
        {
            try
            {
                int resultCount = 0;
                var result = _dbContext.DriverLTyps.AsNoTracking().Where(w => w.EmployeeId == dltypes.EmployeeId).ToListAsync();
                foreach (var type in result.Result)
                {
                    dltypes.DriverLTypId = type.DriverLTypId;
                    dltypes.CreatedBy = type.CreatedBy;
                    dltypes.CreatedOn = type.CreatedOn;
                    dltypes.ModifiedBy = dltypes.EmployeeId;
                    dltypes.ModifiedOn = DateTime.Now;
                    dltypes.LicenseType = type.LicenseType;
                    if (typelists.Contains(type.LicenseType))
                        dltypes.IsActive = true;
                    else
                        dltypes.IsActive = false;
                     _dbContext.DriverLTyps.Update(dltypes);
                    resultCount += await _dbContext.SaveChangesAsync();
                    _dbContext.Dispose();
                }
                foreach (var item in typelists)
                {
                    if (result.Result.Where(r => r.LicenseType == item).Count() == 0)
                    {
                        dltypes.CreatedBy = dltypes.EmployeeId;
                        dltypes.CreatedOn = DateTime.Now;
                        dltypes.IsActive = true;
                        await _dbContext.DriverLTyps.AddAsync(dltypes);
                        resultCount += await _dbContext.SaveChangesAsync();
                    }
                }
                return resultCount;
                //return await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        #endregion
    }
}