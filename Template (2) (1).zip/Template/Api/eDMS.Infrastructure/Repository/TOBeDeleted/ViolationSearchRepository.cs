﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class ViolationSearchRepository : IViolationSearchRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public ViolationSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ ViolationSearchRepository Methods ]==================================================
        public async Task<ViolationValuesSearchResponce> GetManyAsync(
            Expression<Func<MDMViolationSeverityMatrix, bool>> filter = null, 
            Func<IQueryable<MDMViolationSeverityMatrix>, IOrderedQueryable<MDMViolationSeverityMatrix>> orderBy = null, 
            int? id = null, int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<MDMViolationSeverityMatrix> query = id > 0?
                _dbContext.ViolationSeverityMatrices.Where(x => x.ViolationSeverityMatrixId > 0 
                && x.IsActiveViolationSeverityMatrix == true && x.IncidentValue == id)
                : _dbContext.ViolationSeverityMatrices.Where(x => x.ViolationSeverityMatrixId > 0
                && x.IsActiveViolationSeverityMatrix == true);
            
            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<MDMViolationSeverityMatrix> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var violationSearchList = await query.ToListAsync();
            var violationSearchResponceList = new List<ViolationValueSearchResponce>();
            foreach (MDMViolationSeverityMatrix violationValue in violationSearchList)
            {
                var violationList = new ViolationValueSearchResponce
                {
                    ViolationSeverityMatrixId = violationValue.ViolationSeverityMatrixId,
                    IncidentValue = violationValue.IncidentValue,
                    ViolationValue = violationValue.ViolationValue,
                    IsActiveViolationSeverityMatrix = violationValue.IsActiveViolationSeverityMatrix,
                    ViolationDescription = violationValue.ViolationDescription
                };
                violationSearchResponceList.Add(violationList);
            }
            ViolationValuesSearchResponce result = new ViolationValuesSearchResponce();
            result.TotalCount = countSearch;
            result.violationValueSearchResponceList = violationSearchResponceList;
            return result;
        }

        public async Task<ViolationValuesSearchResponce> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        {
            IQueryable<MDMViolationSeverityMatrix> query = _dbContext.ViolationSeverityMatrices.OrderByDescending(r => r.CreatedOn);                
            IQueryable<MDMViolationSeverityMatrix> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var violationSearchList = await query.ToListAsync();
            var violationSearchResponceList = new List<ViolationValueSearchResponce>();
            foreach (MDMViolationSeverityMatrix violationValue in violationSearchList)
            {
                var violationList = new ViolationValueSearchResponce
                {
                    ViolationSeverityMatrixId = violationValue.ViolationSeverityMatrixId,
                    IncidentValue = violationValue.IncidentValue,
                    ViolationValue = violationValue.ViolationValue,
                    IsActiveViolationSeverityMatrix = violationValue.IsActiveViolationSeverityMatrix,
                    ViolationDescription = violationValue.ViolationDescription
                };
                violationSearchResponceList.Add(violationList);
            }
            ViolationValuesSearchResponce result = new ViolationValuesSearchResponce();
            result.TotalCount = countSearch;
            result.violationValueSearchResponceList = violationSearchResponceList;
            return result;
        }
        #endregion
    }
}