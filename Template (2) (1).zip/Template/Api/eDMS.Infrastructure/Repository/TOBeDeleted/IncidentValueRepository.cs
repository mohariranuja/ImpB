﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class IncidentValueRepository : IIncidentValueRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public IncidentValueRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion
        
        #region ===[ IIncidentValueRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMIncidentValue>> GetAllAsync()
        {
            return await _dbContext.IncidentValues.ToListAsync();
        }

        public async Task<MDMIncidentValue> GetByIdAsync(int id)
        {
            return await _dbContext.IncidentValues.Where(w => w.IncidentValueId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(MDMIncidentValue mdmIncidentValue)
        {
            var result = _dbContext.IncidentValues.AsNoTracking().Where(w => w.IncidentValueId == mdmIncidentValue.IncidentValueId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.IncidentValues.Add(mdmIncidentValue);
            }
            else
            {
                _dbContext.IncidentValues.Update(mdmIncidentValue);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.IncidentValues.Where(w => w.IncidentValueId == id).FirstOrDefault();

            if (result != null)
            {
                result.IsActiveIncidentValue = false;
                _dbContext.IncidentValues.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }
        
        public async Task<List<MDMIncidentValue>> GetByIncidentTypeIdAsync(int incidentTypeId)
        {
            return await _dbContext.IncidentValues.Where(w => w.IncidentTypeId == incidentTypeId).ToListAsync();
        }

        #endregion
    }
}