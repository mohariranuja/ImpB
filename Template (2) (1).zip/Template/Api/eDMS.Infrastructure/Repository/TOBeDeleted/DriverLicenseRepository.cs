﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class DriverLicenseRepository : IDriverLicenseRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public DriverLicenseRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        
        #region ===[ IDriverLicenseRepository Methods ]==================================================
        public async Task<IReadOnlyList<DriverLicense>> GetAllAsync()
        {
            return await _dbContext.DriverLicenses.ToListAsync();
        }

        public async Task<DriverLicense> GetByIdAsync(int id)
        {
            return await _dbContext.DriverLicenses.Where(w => w.DriverLicId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(DriverLicense driverLicense)
        {
            var result = _dbContext.DriverLicenses.AsNoTracking().Where(w => w.DriverLicId == driverLicense.DriverLicId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DriverLicenses.Add(driverLicense);
            }
            else
            {
                _dbContext.DriverLicenses.Update(driverLicense);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DriverLicenses.Where(w => w.DriverLicId == id).FirstOrDefault();

            if (result != null)
            {
                // result.IsActive= false;
                _dbContext.DriverLicenses.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public Task<IReadOnlyList<Country>> GetManyAsync(Expression<Func<Country, bool>> filter = null)
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<DriverLicense>> GetByIDMultipleRecord(string id)
        {
            return await _dbContext.DriverLicenses.Where(x => x.EMPLId == id).OrderByDescending(x => x.ExpirationDT).ToListAsync();
        }

        public async Task<DriverLicense> GetByEmployeeID(int id)
        {
            return await _dbContext.DriverLicenses.Where(x => x.EmployeeId == id).OrderByDescending(x => x.ExpirationDT).FirstOrDefaultAsync();
        }
        
        public async Task<int> UpdateDriverInfoAsync(DriverLicense entity)
        {
            _dbContext.DriverLicenses.Update(entity);
            return await _dbContext.SaveChangesAsync();
        }
        #endregion
    }
}