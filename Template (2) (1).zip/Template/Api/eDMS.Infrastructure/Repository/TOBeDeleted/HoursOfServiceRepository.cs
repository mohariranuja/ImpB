﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace eDMS.Infrastructure.Repository
{
    public class HoursOfServiceRepository : IHoursOfServiceRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public HoursOfServiceRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }
        #endregion

        #region ===[ HoursOfServiceRepository Methods ]==================================================
        public async Task<IReadOnlyList<HoursOfService>> GetAllAsync()
        {
            return await _dbContext.HoursOfServices.ToListAsync();
        }

        public async Task<HoursOfService> GetByIdAsync(int id)
        {
            return await _dbContext.HoursOfServices.Where(w => w.HoursOfServiceId == id).FirstOrDefaultAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.HoursOfServices.Where(w => w.HoursOfServiceId == id).FirstOrDefault();

            if (result != null)
            {
                result.IsActive = false;
                _dbContext.HoursOfServices.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> SaveAsync(HoursOfService entity)
        {
            var result = _dbContext.HoursOfServices.AsNoTracking().Where(w => w.HoursOfServiceId == entity.HoursOfServiceId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.HoursOfServices.Add(entity);
            }
            else
            {
                _dbContext.HoursOfServices.Update(entity);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<HoursOfServiceGetManyResponse> GetManyAsync(int employeeId, int? top = null,
            int? skip = null)
        {
            DateTime dateRange = DateTime.Now.AddMonths(-12);

            IQueryable<HoursOfService> query =
                _dbContext.HoursOfServices.Where(x => x.EmployeeId == employeeId && x.IsActive == true && x.CreatedOn > dateRange).OrderByDescending(x => x.HoursOfServiceId);

            int countSearch = query.Count();

            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }
            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }

            var hosList = await query.ToListAsync();

            var hosGetResponse = new List<HoursOfServiceGetResponse>();
            hosGetResponse.AddRange(hosList.ConvertAll(x => new HoursOfServiceGetResponse()
            {
                HoursOfServiceId = x.HoursOfServiceId,
                EmpId = x.EmpId,
                EmployeeId = x.EmployeeId,
                Date1 = x.Date1,
                DLUploadDate = x.DLUploadDate,
                MonthXLAT = x.MonthXLAT,
                YearCD = x.YearCD,
                Submitted = x.Submitted,
                GovtAudited = x.GovtAudited,
                MajorViolation = x.MajorViolation,
                RiskIndexId = x.RiskIndexId,
                RiskIndex = x.RiskIndex,
                IncidentTypeId = x.IncidentTypeId,
                IncidentType = x.IncidentType,
                IncidentValueId = x.IncidentValueId,
                IncidentValue = x.IncidentValue,
                EDotDesc = x.EDotDesc,
                DescLongNotes = x.DescLongNotes,
                Comments = x.Comments
            }));

            HoursOfServiceGetManyResponse result = new HoursOfServiceGetManyResponse();
            result.TotalCount = countSearch;
            result.HoursOfServices = hosGetResponse;
            return result;
        }


        public async Task<string> GetHosAsyncResult(string emplId, string regionId)
        {
            string result = string.Empty;


            var sql = $"EXEC YourStoredProcedure @InputParam, @OutputParam OUTPUT";
            // Execute the raw SQL query with output parameter

            // 
            // Use the output value as needed

            var paramName = new SqlParameter("@returnValue", SqlDbType.NVarChar, 100)
            {
                Direction = ParameterDirection.Output

            };
            _dbContext.Database.ExecuteSqlInterpolated($"EXEC {StoreProc.sp_GetHosRisk} {emplId},{regionId}, {paramName} OUTPUT");//RiskIndexCalculationHOS1

            //Access the output parameter value
            var outputValue = paramName.Value;
            // string @returnValue = string.Empty;

            // var driverRiskResult = await _dbContext.DriverBehaviorRiskResults.FromSqlInterpolated($" {StoreProc.Sp_GetDriverBehaviorRisk} {emplId},{regionId},{paramName} OUTPUT").ToListAsync<DriverBehaviorRiskResult>();
            // Access the output parameter value
            //  var outputValue1 = paramName.Value.ToString();
            // Use the output value as needed
            result = outputValue.ToString();

            return result;
        }


        public async Task<string> GetHosRiskAsyncResult(string emplId)
        {
            string result = string.Empty;


            var sql = $"EXEC YourStoredProcedure @InputParam, @OutputParam OUTPUT";
            // Execute the raw SQL query with output parameter

            // 
            // Use the output value as needed

            var paramName = new SqlParameter("@returnValue", SqlDbType.NVarChar, 50)
            {
                Direction = ParameterDirection.Output

            };
            _dbContext.Database.ExecuteSqlInterpolated($"EXEC {StoreProc.sp_GetHosRiskCalculation} {emplId}, {paramName} OUTPUT");//RiskIndexCalculationHOS1

            //Access the output parameter value
            var outputValue = paramName.Value;
            // string @returnValue = string.Empty;

            // var driverRiskResult = await _dbContext.DriverBehaviorRiskResults.FromSqlInterpolated($" {StoreProc.Sp_GetDriverBehaviorRisk} {emplId},{regionId},{paramName} OUTPUT").ToListAsync<DriverBehaviorRiskResult>();
            // Access the output parameter value
            //  var outputValue1 = paramName.Value.ToString();
            // Use the output value as needed
            result = outputValue.ToString();

            return result;
        }
        #endregion
    }
}