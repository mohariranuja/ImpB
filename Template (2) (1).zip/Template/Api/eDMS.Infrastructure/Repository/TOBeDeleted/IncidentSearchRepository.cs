﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class IncidentSearchRepository : IIncidentSearchRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public IncidentSearchRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }
        #endregion

        #region ===[ IncidentSearchRepository Methods ]==================================================
        public async Task<IncidentsSearchResponce> GetManyAsync(Expression<Func<MDMIncidentValue, bool>> filter = null,
            Func<IQueryable<MDMIncidentValue>, IOrderedQueryable<MDMIncidentValue>> orderBy = null,
            int? id = null, int? top = null, int? skip = null, params string[] includeProperties)
        {
            IQueryable<MDMIncidentValue> query = id > 0 ?
                _dbContext.IncidentValues.Where(x => x.IncidentValueId > 0 && x.IsActiveIncidentValue == true
                && x.IncidentTypeId == id)
                : _dbContext.IncidentValues.Where(x => x.IncidentValueId > 0 && x.IsActiveIncidentValue == true);

            if (filter != null)
            {
                query = query.Where(filter);
            }
            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }
            if (orderBy != null)
            {
                query = orderBy(query);
            }

            IQueryable<MDMIncidentValue> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var incidentSearchList = await query.ToListAsync();
            var incidentSearchResponceList = new List<IncidentSearchResponce>();
            foreach (MDMIncidentValue incidentValue in incidentSearchList)
            {
                var incidentList = new IncidentSearchResponce
                {
                    IncidentTypeId = incidentValue.IncidentTypeId,
                    IncidentValueId = incidentValue.IncidentValueId,
                    IncidentValue = incidentValue.IncidentValue,
                    IncidentValueDescription = incidentValue.IncidentValueDescription,
                    IsActiveIncidentValue = incidentValue.IsActiveIncidentValue
                };
                incidentSearchResponceList.Add(incidentList);
            }
            IncidentsSearchResponce result = new IncidentsSearchResponce();
            result.TotalCount = countSearch;
            result.IncidentSearchResponces = incidentSearchResponceList;
            return result;
        }

        public async Task<IncidentsSearchResponce> GetManyIncidentValuesAsync(int incidentTypeId,
            Expression<Func<MDMIncidentValue, bool>> filter = null, Func<IQueryable<MDMIncidentValue>,
            IOrderedQueryable<MDMIncidentValue>> orderBy = null, int? top = null, int? skip = null,
            params string[] includeProperties)
        {
            IQueryable<MDMIncidentValue> query = _dbContext.IncidentValues.Where(x => x.IncidentValueId > 0
            && x.IncidentTypeId == incidentTypeId);
            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<MDMIncidentValue> queryCount = query;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var incidentSearchList = await query.ToListAsync();
            var incidentSearchResponceList = new List<IncidentSearchResponce>();
            foreach (MDMIncidentValue incidentValue in incidentSearchList)
            {
                var incidentList = new IncidentSearchResponce
                {
                    IncidentTypeId = incidentValue.IncidentTypeId,
                    IncidentValueId = incidentValue.IncidentValueId,
                    IncidentValue = incidentValue.IncidentValue,
                    IncidentValueDescription = incidentValue.IncidentValueDescription,
                    IsActiveIncidentValue = incidentValue.IsActiveIncidentValue
                };
                incidentSearchResponceList.Add(incidentList);
            }
            IncidentsSearchResponce result = new IncidentsSearchResponce();
            result.TotalCount = countSearch;
            result.IncidentSearchResponces = incidentSearchResponceList;
            return result;
        }

        #endregion
    }
}