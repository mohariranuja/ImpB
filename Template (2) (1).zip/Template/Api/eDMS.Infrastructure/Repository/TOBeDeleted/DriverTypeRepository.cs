﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace eDMS.Infrastructure.Repository
{
    public class DriverTypeRepository : IDriverTypeRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion

        #region ===[ Constructor ]=================================================================
        public DriverTypeRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion
        #region ===[ IDriverTypeRepository Methods ]==================================================
        public async Task<IReadOnlyList<MDMDriverType>> GetAllAsync()
        {
            return await _dbContext.DriverTypes.ToListAsync();
        }

        public async Task<MDMDriverType> GetByIdAsync(int id)
        {
            return await _dbContext.DriverTypes.Where(w => w.DriverTypeId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(MDMDriverType mdmDriverType)
        {
            var result = _dbContext.DriverTypes.AsNoTracking().Where(w => w.DriverTypeId == mdmDriverType.DriverTypeId).FirstOrDefault();

            if (result == null)
            {
                _dbContext.DriverTypes.Add(mdmDriverType);
            }
            else
            {
                _dbContext.DriverTypes.Update(mdmDriverType);
            }
            return await _dbContext.SaveChangesAsync();
        }
        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.DriverTypes.Where(w => w.DriverTypeId == id).FirstOrDefault();

            if (result != null)
            {
                // result.IsActive= false;
                _dbContext.DriverTypes.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public Task<IReadOnlyList<Country>> GetManyAsync(Expression<Func<Country, bool>> filter = null)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}