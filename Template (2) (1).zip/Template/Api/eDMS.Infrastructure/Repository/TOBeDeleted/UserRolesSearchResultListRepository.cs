﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using eDMS.Infrastructure.Utility;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class UserRolesSearchResultListRepository : IUserRolesSearchResultListRepository
    {
        #region ===[ Private Members ]=============================================================


        private readonly ApplicationDBContext _dbContext;

        #endregion

        #region ===[ Constructor ]=================================================================

        public UserRolesSearchResultListRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;

        }

        #endregion
        #region ===[ IUserRolesSearchResultListRepository Methods ]==================================================

        public async Task<UserRolesSearchResult> GetManyAsync(
        Expression<Func<EmployeeMasterRole, bool>> filter = null,
        Func<IQueryable<EmployeeMasterRole>, IOrderedQueryable<EmployeeMasterRole>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters;
            ////    IQueryable<EmployeeMasterRole> queryEmpMstRole = (from e in _dbContext.EmployeeMasters
            ////                                                       join m in _dbContext.MdmUserRoles on e.EmpId equals m.UserId
            ////                                                      join t in _dbContext.MdmRoles on m.RoleId equals t.RoleId
            ////                                                      select new EmployeeMasterRole { EmpId = e.EmpId, EmplId = e.EmplId, ManagerCode = e.ManagerCode, ManagerName = e.ManagerName, HRStatus = e.HRStatus, RoleName = t.RoleName, FirstName = e.FirstName, LastName = e.LastName }
            ////);

            IQueryable<EmployeeMasterRole> queryEmpMstRole = from e in _dbContext.Set<EmployeeMaster>()
                         from p in _dbContext.Set<MdmUserRole>().Where(p => e.EmpId == p.UserId).DefaultIfEmpty()
                         from t in _dbContext.Set<MdmRole>().Where(t=>t.RoleId==p.RoleId).DefaultIfEmpty()
                         select new EmployeeMasterRole { EmpId = e.EmpId, EmplId = e.EmplId, ManagerCode = e.ManagerCode, ManagerName = e.ManagerName, HRStatus = e.HRStatus, RoleName = t.RoleName, FirstName = e.FirstName, LastName = e.LastName, RoleId=p.RoleId };

            //      var result = _dbContext.EmployeeMasters.Join(
            //_dbContext.MdmUserRoles,
            //outer => outer.EmpId,
            //inner => inner.UserId),
            //(outer, inner) => new { Name = outer.Empid, OtherName = inner.Name });


            // List<MdmUserRole> UserRoleList = await _dbContext.MdmUserRoles.ToListAsync();
            if (filter != null)
            {
                queryEmpMstRole = queryEmpMstRole.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
                // query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                queryEmpMstRole = orderBy(queryEmpMstRole);
            }
            queryEmpMstRole = queryEmpMstRole.Where(x => x.EmpId > 0);
            IQueryable<EmployeeMasterRole> queryCount = queryEmpMstRole;
            var countItem = await queryCount.ToListAsync();
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                queryEmpMstRole = queryEmpMstRole.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                queryEmpMstRole = queryEmpMstRole.Take(top.Value);
            }
           
            var userRoleSearchResult = new List<UserRoleSearchResult>();
            foreach (var empMaster in queryEmpMstRole)
            {
                string hrStatus = string.Empty;
                if(empMaster.HRStatus!=null)
                 hrStatus = empMaster.HRStatus.ToUpper() == "A" ? "Active" : "InActive";

                var countryList1 = new UserRoleSearchResult { FirstName = empMaster.FirstName, LastName = empMaster.LastName, ManagerCode = empMaster.ManagerCode, ManagerName = empMaster.ManagerName, EmplId = empMaster.EmplId, EmpId = empMaster.EmpId, HRStatus = hrStatus , RoleName = empMaster.RoleName, RoleId= empMaster.RoleId, IsGlobalAccess=empMaster.IsGlobalAccess };
                userRoleSearchResult.Add(countryList1);
            }
            

            UserRolesSearchResult result = new UserRolesSearchResult();
            result.TotalCount = countSearch;
            result.userRoleSearchResultList = userRoleSearchResult;
            return result;
            // return await query.ToListAsync();
        }

        public async Task<UserRolesSearchResult> GetManyAsyncOld(
        Expression<Func<EmployeeMaster, bool>> filter = null,
        Func<IQueryable<EmployeeMaster>, IOrderedQueryable<EmployeeMaster>> orderBy = null,
        int? top = null,
        int? skip = null,
        params string[] includeProperties)
        {
            IQueryable<EmployeeMaster> query = _dbContext.EmployeeMasters;
           // List<MdmUserRole> UserRoleList = await _dbContext.MdmUserRoles.ToListAsync();
            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties.Length > 0)
            {
               // query = includeProperties.Aggregate(query, (theQuery, theInclude) => theQuery.Include(theInclude));
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            IQueryable<EmployeeMaster> queryCount = query;
            var countItem = await queryCount.ToListAsync();            
            int countSearch = countItem.Count;
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            MdmUserRoleRepository mdmUserRoleRepository = new MdmUserRoleRepository(_dbContext);
            MdmRoleRepository mdmRoleRepository = new MdmRoleRepository(_dbContext);
            var employeeMasterList = await query.ToListAsync();
            var userRoleSearchResult = new List<UserRoleSearchResult>();
            foreach (EmployeeMaster empMaster in employeeMasterList)
            {
                string roleName = String.Empty;
                var mdmUserRole = await mdmUserRoleRepository.GetMdmUserRoleByUserIdAsync(empMaster.EmpId);//String.Empty;

                if (mdmUserRole != null)
                {
                    var mdmRole = await mdmRoleRepository.GetMdmRoleByIdAsync(mdmUserRole.RoleId);
                    roleName = (mdmRole != null) ? mdmRole.RoleName : String.Empty;
                }
                // int? roleId= UserRoleList.Where(x=>x.UserId== empMaster.EmpId).FirstOrDefault()?.RoleId;

                var countryList1 = new UserRoleSearchResult { FirstName = empMaster.FirstName, LastName = empMaster.LastName, ManagerCode = empMaster.ManagerCode, ManagerName = empMaster.ManagerName, EmplId = empMaster.EmplId, EmpId = empMaster.EmpId, HRStatus = empMaster.HRStatus, RoleName = roleName };
                userRoleSearchResult.Add(countryList1);
            }
            if (includeProperties.Length > 0)
            {
                userRoleSearchResult= userRoleSearchResult.Where(x=>x.RoleName== includeProperties[0]).ToList();
                countSearch = userRoleSearchResult.Count;
            }
            
            UserRolesSearchResult result = new UserRolesSearchResult();
            result.TotalCount = countSearch;
            result.userRoleSearchResultList = userRoleSearchResult;
            return result;
            // return await query.ToListAsync();
        }
        #endregion
    }
}
