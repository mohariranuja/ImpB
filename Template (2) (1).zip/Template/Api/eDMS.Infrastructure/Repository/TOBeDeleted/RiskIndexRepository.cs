﻿using eDMS.Application.Interfaces.TOBEDeleted;
using eDMS.Core.Constants;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Repository
{
    public class RiskIndexRepository : IRiskIndexRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        #region ===[ Constructor ]=================================================================
        public RiskIndexRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.MDMRiskIndexes.Where(w => w.RiskIndexId == id
                                                           ).FirstOrDefault();

            if (result != null)
            {
                // result.IsActive= false;
                _dbContext.MDMRiskIndexes.Update(result);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<IReadOnlyList<MDMRiskIndex>> GetAllAsync()
        {
            return await _dbContext.MDMRiskIndexes.ToListAsync();
        }

        public async Task<MDMRiskIndex> GetByIdAsync(int id)
        {
            return await _dbContext.MDMRiskIndexes.Where(w => w.RiskIndexId == id).FirstOrDefaultAsync();
        }

        public async  Task<int> SaveAsync(MDMRiskIndex entity)
        {
            var result = _dbContext.MDMRiskIndexes.AsNoTracking().Where(w => w.RiskIndexId == entity.RiskIndexId
                                                            ).FirstOrDefault();

            if (result == null)
            {
                _dbContext.MDMRiskIndexes.Add(entity);
            }
            else
            {
                _dbContext.MDMRiskIndexes.Update(entity);
            }
            return await _dbContext.SaveChangesAsync();
        }

        #endregion

    }
}
