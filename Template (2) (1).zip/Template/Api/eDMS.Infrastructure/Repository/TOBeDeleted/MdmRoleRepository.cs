﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace eDMS.Infrastructure.Repository
{
    public class MdmRoleRepository(ApplicationDBContext dbContext) : IMdmRoleRepository
    {
        private readonly ApplicationDBContext _dbContext = dbContext;

        public async Task<MdmRole?> GetMdmRoleByIdAsync(int id)
        {
            return await _dbContext.MdmRoles.FindAsync(id);
        }
        public async Task<IReadOnlyList<MdmRole>> GetAllAsync()
        {
            return await _dbContext.MdmRoles.ToListAsync();
        }
    }
}
