﻿using eDMS.Application.Interfaces;
using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.Linq;

namespace eDMS.Infrastructure.Repository
{
    public class AgencyRepository : IAgencyRepository
    {
        #region ===[ Private Members ]=============================================================
        private readonly ApplicationDBContext _dbContext;
        #endregion
        
        #region ===[ Constructor ]=================================================================
        public AgencyRepository(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        #endregion

        #region ===[ IAgencyRepository Methods ]==================================================
        public async Task<IReadOnlyList<Agency>> GetAllAsync()
        {
            return await _dbContext.Agencies.ToListAsync();
        }

        public async Task<Agency> GetByIdAsync(int id)
        {
            return await _dbContext.Agencies.Where(w => w.AgencyId == id).FirstOrDefaultAsync();
        }

        public async Task<int> SaveAsync(Agency agency)
        {
            var result = _dbContext.Agencies.AsNoTracking().Where(w => w.AgencyId == agency.AgencyId).FirstOrDefault();

            if (result == null)
            {
                agency.CreatedOn = DateTime.Now;
                _dbContext.Agencies.Add(agency);
            }
            else
            {
                agency.ModifiedBy = agency.CreatedBy;
                agency.ModifiedOn = DateTime.Now;
                agency.CreatedBy = result.CreatedBy;
                agency.CreatedOn = result.CreatedOn;
                _dbContext.Agencies.Update(agency);
            }

            return await _dbContext.SaveChangesAsync();
        }

        public async Task<int> DeleteAsync(int id)
        {
            var result = _dbContext.Agencies.Where(w => w.AgencyId == id).FirstOrDefault();
            if (result != null)
            {
                result.IsActive = false;
                _dbContext.Agencies.Update(result);
            }
            return await _dbContext.SaveChangesAsync();
        }

        public async Task<AgencyResponseList> GetAllWithPaginationAsync(int? top = null, int? skip = null)
        {
            IQueryable<Agency> agencyQuery = _dbContext.Agencies.OrderByDescending(x=> x.AgencyId);
            //IQueryable<Agency> query = _dbContext.Agencies.Where(x => x.IsActive == true).OrderByDescending(x => x.AgencyId);
            var countries = _dbContext.Countries;

            var query = (from ag in agencyQuery
                         join cou in countries on ag.CountryId equals cou.CountryId
                         select new
                         {
                             AgencyId = ag.AgencyId,
                             AgencyName = ag.AgencyName,
                             CountryId = ag.CountryId,
                             CountryName = cou.CountryName,
                             RegionId = ag.RegionId,
                             FieldValue = ag.FieldValue,
                             IsActive = ag.IsActive
                         }
            );

            //var query = from b in context.Set<agencyQuery>()
            //            from p in context.Set<Post>().Where(p => b.BlogId == p.BlogId)
            //            select new { b, p };

            //IQueryable<Agency> queryCount = query;
            //var countItem = await queryCount.ToListAsync();
            int countSearch = query.Count();
            if (skip.HasValue)
            {
                query = query.Skip(skip.Value);
            }

            if (top.HasValue)
            {
                query = query.Take(top.Value);
            }
            var agencyList = await query.ToListAsync();
            var agencyResponse_List = new List<AgencyResponse>();
            foreach (var agency in agencyList)
            {
                var agencies = new AgencyResponse
                {
                    AgencyId = agency.AgencyId,
                    AgencyName = agency.AgencyName,
                    CountryId = agency.CountryId,
                    CountryName = agency.CountryName,
                    RegionId = agency.RegionId,
                    FieldValue = agency.FieldValue,
                    IsActive = agency.IsActive
                };
                agencyResponse_List.Add(agencies);
            }
            AgencyResponseList result = new AgencyResponseList();
            result.TotalCount = countSearch;
            result.agencyResponseList = agencyResponse_List;
            return result;
        }
        #endregion
    }
}