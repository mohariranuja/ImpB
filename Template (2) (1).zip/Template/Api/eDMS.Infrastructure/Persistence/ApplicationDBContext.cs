﻿using eDMS.Core.Entities;
using eDMS.Core.Model;
using eDMS.Infrastructure.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
namespace eDMS.Infrastructure.Persistence
{
    public class ApplicationDBContext : DbContext
    {
        #region Ctor
        // public readonly IConfiguration _configuration;
        private string connectionString;
        public ApplicationDBContext()
        {

        }
        //public ApplicationDBContext(IConfiguration configuration)
        //{
        //    _configuration = configuration;
        //}


        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
         : base(options)
        {

        }

        private string GetConnectionstring()
        {
            var builder = new ConfigurationBuilder();

            builder.AddJsonFile("appsettings.json", optional: false);

            var configuration = builder.Build();

            return configuration.GetConnectionString("DBConnection").ToString();
        }
        #endregion
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (string.IsNullOrEmpty(this.connectionString))
                this.connectionString = GetConnectionstring();
            optionsBuilder.UseSqlServer(this.connectionString);

            //Data Source=USDCSHRSQLDV010;Initial Catalog=eDMS;Integrated Security=True;User ID=eDMS_user;Password=eD$t6m#b@s&;Connect Timeout=60;TrustServerCertificate=True
            // optionsBuilder.UseSqlServer("Server=USDCSHRSQLDV010;Database=eDMS;Encrypt=False;User ID=eDMS_user;Password=eD$t6m#b@s&;");
            // optionsBuilder.UseSqlServer("Server=BSPUNL-026223;Database=eDMS;Encrypt=False;Integrated Security=SSPI;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<DriverRisksHistory>(builder =>
            {
                builder.HasNoKey();
                builder.ToTable("DriverRisksHistory");
            });
            //Below code is for enabling auditing.
            //modelBuilder.Entity<DOTDrug_AlcoholTest>().ToTable("DOTDrug_AlcoholTest", Options => { Options.IsTemporal(); });
        }

        #region DbSet
        public DbSet<DOTDrug_AlcoholTest> DOTDrug_AlcoholTest { get; set; }
        public DbSet<Country> Countries { get; set; }
        public DbSet<CountryList> CountryLists { get; set; }
        public DbSet<DriverLicense> DriverLicenses { get; set; }
        public DbSet<EmployeeMaster> EmployeeMasters { get; set; }
        public DbSet<MDMDriverType> DriverTypes { get; set; }
        public DbSet<DriverSearchResult> DriverSearchResults { get; set; }
        public DbSet<MDMLocation> Locations { get; set; }
        public DbSet<DriverRiskList> DriverRiskLists { get; set; }
        public DbSet<DriverBehaviourRiskView> DriverBehaviourRiskViews { get; set; }
        public DbSet<MDMIncidentType> MDMIncidentTypes { get; set; }
        public DbSet<MDMIncidentValue> IncidentValues { get; set; }
        public DbSet<MDMViolationSeverityMatrix> ViolationSeverityMatrices { get; set; }
        public DbSet<DriverBehaviorRiskResult> DriverBehaviorRiskResults { get; set; }
        public DbSet<DriverRisks> DriversRisk { get; set; }
        public DbSet<MDMRiskIndex> MDMRiskIndexes { get; set; }
        public DbSet<IncidentSeverityMatrix> IncidentSeverityMatrices { get; set; }
        public DbSet<TestType> TestTypes { get; set; }
        public DbSet<SampleType> SampleTypes { get; set; }
        public DbSet<TestResult> TestResults { get; set; }
        public DbSet<Substance> Substances { get; set; }
        public DbSet<Disposition> Dispositions { get; set; }
        public DbSet<HoursOfService> HoursOfServices { get; set; }
        //public DbSet<EmployeeMasterTeamsResult> EmployeeMasterTeamsResults { get; set; }
        public DbSet<DLUPLDWRK> DLUPLDWRKs { get; set; }
        public DbSet<Psxlatitem> Psxlatitems { get; set; }
        public DbSet<PSDRIVERLTYPTBL> PSDRIVERLTYPTBLs { get; set; }
        public DbSet<MdmRole> MdmRoles { get; set; }
        public DbSet<MdmUserRole> MdmUserRoles { get; set; }
        public DbSet<DriverLTyp> DriverLTyps { get; set; }
        public DbSet<DriverRisksHistory> DriverRisksHistories { get; set; }
        public DbSet<ApprovalHistory> ApprovalHistories { get; set; }
        public DbSet<MDMRiskType> RiskTypes { get; set; }
        public DbSet<Agency> Agencies { get; set; }
        public DbSet<TestCategory> TestCategories { get; set; }
        public DbSet<MDMRegion> MdmRegions { get; set; }
        public DbSet<ExpirationReportSearchResult> ExpirationReportSearchResults { get; set; }
        public DbSet<GenericMasterResult> GenericMasterResults { get; set; }
        public DbSet<ViolationReportResult> ViolationReportResults { get; set; }
        public DbSet<DocumentUploadResult> DocumentUploadResults { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<BusinessUnit> BusinessUnits { get; set; }
        public DbSet<SubProductLine> SubProductLines { get; set; }
        public DbSet<ProductLine> Productlines { get; set; }
        public DbSet<MDMLegalEntity> MDMLegalEntities { get; set; }
        public DbSet<DocType> DocumentTypes { get; set; }
        public DbSet<MDMManagerAccess> MDMManagerAccesses { get; set; }
        #endregion

        #region Methods
        public Task<int> SaveChangesAsync()
        {
            return base.SaveChangesAsync();
        }
        #endregion
    }
}