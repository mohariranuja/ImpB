﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace eDMS.Infrastructure.Utility
{
    public static class StoreProc
    {
        public const string Sp_GetVpTypeList = "GetVpTypeList";
        public const string Sp_GetRateTemplateList = "GetRateTemplateList";
        public const string Sp_GetCountryList = "GET_COUNTRY_LIST";//"GetCountryList";
        public const string Sp_GetDriverSearchList = "GetDriverSearchList4";//GetDriverSearchList3
        public const string Sp_GetDriverSearchListSp = "GetDriverSearchList7";//"GetDriverSearchList6";//GetDriverSearchList3
        public const string Sp_GetExpirationReportSearchList = "ExpirationReport";
        public const string Sp_DriverRiskInfo = "sp_DriverRisk_Select";//"GetCountryList";
        public const string Sp_GetDriverBehaviorRisk = "RiskIndexCalculation_Final1";
        public const string sp_GetHosRisk = "RiskIndexCalculationHOS1";
        public const string Sp_GetViolationReport = "ViolationReport";
        public const string Sp_GetDocumentUploadReport = "DocumentUploadReport";
        public const string sp_GetRiskCalculationConsole = "RiskCalculation_Final1";
        public const string sp_GetHosRiskCalculation = "RiskCalculation_hos_new1";
    }
}