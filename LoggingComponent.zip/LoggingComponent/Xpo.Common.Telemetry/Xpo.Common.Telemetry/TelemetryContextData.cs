﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xpo.Common.Telemetry
{
    /// <summary>
    /// Use static Create() methods to create an instance
    /// </summary>
    public sealed class TelemetryContextData
    {
        private TelemetryContextData(string correlationId, string requestId, string parentRequestId)
        {
            CorrelationId = correlationId;
            RequestId = requestId;
            ParentRequestId = parentRequestId;
        }

        public static TelemetryContextData Create()
        {
            return new TelemetryContextData(GetNewId(), GetNewId(), null);
        }

        public static TelemetryContextData Create(string correlationId, string parentRequestId)
        {
            var corId = string.IsNullOrWhiteSpace(correlationId)
                ? GetNewId()
                : correlationId;

            return new TelemetryContextData(corId, GetNewId(), parentRequestId);
        }

        public string CorrelationId { get; }

        public string RequestId { get; }

        public string ParentRequestId { get; }

        public IReadOnlyDictionary<string, object> ToDictionary()
        {
            return new Dictionary<string, object>
            {
                { nameof(CorrelationId), CorrelationId },
                { nameof(RequestId), RequestId},
                { nameof(ParentRequestId), ParentRequestId }
            };
        }
        
        internal static string GetNewId()
        {
            return Convert.ToBase64String(Guid.NewGuid().ToByteArray()).Replace("=", "").Replace("/", "_").Replace("+", "-");
        }
    }
}
