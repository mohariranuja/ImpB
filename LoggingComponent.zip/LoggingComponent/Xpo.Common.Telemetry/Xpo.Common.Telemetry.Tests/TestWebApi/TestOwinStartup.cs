﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.Owin;
using Owin;
using Xpo.Common.Telemetry.Owin;

namespace Xpo.Common.Telemetry.Tests.TestWebApi
{
    public class TestOwinStartup
    {
        public void Configuration(IAppBuilder app)
        {
            var options = new TelemetryMiddlewareOptions
            {
                LogManager = MockLoggers.LogManager.Object
            };

            app.UseXpoTelemetry(options);

            var config = new HttpConfiguration();
            config.MapHttpAttributeRoutes();

            app.UseWebApi(config);
        }
    }
}
