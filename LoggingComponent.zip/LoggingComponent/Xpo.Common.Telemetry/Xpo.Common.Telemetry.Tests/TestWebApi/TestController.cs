﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Newtonsoft.Json;
using Xpo.Common.Telemetry.Http;
using Xpo.Common.Telemetry.Tests.Owin;

namespace Xpo.Common.Telemetry.Tests.TestWebApi
{
    [RoutePrefix("test")]
    public class TestController : ApiController
    {
        [HttpGet, Route("")]
        public async Task<IHttpActionResult> Echo()
        {
            var telData = new TelemetryContextDataTest(TelemetryContext.Current.Data);
            return Ok(telData);
        }

        /// <summary>
        /// Returns array of Root telemetry data at position 0 and inner telemetry data as 1
        /// </summary>
        /// <param name="baseUri"></param>
        /// <returns></returns>
        [HttpGet, Route("root")]
        public async Task<IHttpActionResult> Root(string baseUri)
        {
            var rootTelData = new TelemetryContextDataTest(TelemetryContext.Current.Data);

            var apiClient = new TestApiClient();

            var innerTelData = await apiClient.GetInnerTelem(new Uri(baseUri));

            return Ok(new TelemetryContextDataTest[] { rootTelData, innerTelData });
        }

        [HttpGet, Route("inner")]
        public async Task<IHttpActionResult> Inner()
        {
            var telData = new TelemetryContextDataTest(TelemetryContext.Current.Data);
            return Ok(telData);
        }

        internal class TestApiClient : XpoApiClient.XpoApiClientBase
        {
            public async Task<TelemetryContextDataTest> GetInnerTelem(Uri baseUri)
            {
                var resourse = new Uri(baseUri, "test/inner");
                return await GetAsync<TelemetryContextDataTest>(resourse);
            }
        }
    }
}