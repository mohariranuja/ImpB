﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using Xpo.Common.Logging;

namespace Xpo.Common.Telemetry.Tests.TestWebApi
{
    public class MockLoggers
    {
        public static Mock<ILogger> Logger { get; }

        public static Mock<ILogger> TelemetryLogger { get; }

        public static Mock<ILogManager> LogManager { get; }

        static MockLoggers()
        {
            Logger = new Mock<ILogger>();
            TelemetryLogger = new Mock<ILogger>();

            LogManager = new Mock<ILogManager>();
            LogManager.Setup(x => x.Get(It.IsAny<Type>())).Returns(Logger.Object);
            LogManager.Setup(x => x.Get("TELEMETRY_LOG")).Returns(TelemetryLogger.Object);
        }
    }
}
