﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using Xpo.Common.Logging;
using Xpo.Common.Telemetry.Http;
using Xpo.Common.Telemetry.Tests.TestWebApi;

namespace Xpo.Common.Telemetry.Tests.Owin
{
    [TestFixture]
    public class TelemetryHttpHandlerTests : OwinTestBase
    {
        [Test]
        public async Task ShouldHave_CorrelationId_and_ParentId()
        {
            var resource = new Uri(HostAddress + $"test/root?baseUri={HttpUtility.UrlEncode(HostAddress)}");
            var response = await HttpClient.GetAsync(resource);
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            var rootTelData = JsonConvert.DeserializeObject<TelemetryContextDataTest[]>(content);

            Assert.AreEqual(2, rootTelData.Length);

            var root = rootTelData[0];
            var inner = rootTelData[1];

            Assert.IsNull(root.ParentRequestId);
            Assert.AreNotEqual(root.RequestId, inner.RequestId);
            Assert.AreEqual(root.CorrelationId, inner.CorrelationId);
            Assert.AreEqual(root.RequestId, inner.ParentRequestId);
            MockLoggers.TelemetryLogger.Verify(x => x.Log(It.IsAny<LogEntry>()), Times.AtLeastOnce);
        }

        [Test]
        [Timeout(10000)]
        public void Shoudld_Not_Deadlock()
        {
            var telemetryHttpClient = new HttpClient(new TelemetryHttpHandler(new HttpClientHandler()));

            // Emulate the ASP.NET synchronization context
            new DedicatedThreadSynchronisationContext().Send(_ =>
            {
                var resource = new Uri(HostAddress + $"test/root?baseUri={HttpUtility.UrlEncode(HostAddress)}");
                var response = telemetryHttpClient.GetAsync(resource).Result;
                response.EnsureSuccessStatusCode();
                var content = response.Content.ReadAsStringAsync().Result;
                var rootTelData = JsonConvert.DeserializeObject<TelemetryContextDataTest[]>(content);

                Assert.AreEqual(2, rootTelData.Length);

                var root = rootTelData[0];
                var inner = rootTelData[1];

                Assert.IsNull(root.ParentRequestId);
                Assert.AreNotEqual(root.RequestId, inner.RequestId);
                Assert.AreEqual(root.CorrelationId, inner.CorrelationId);
                Assert.AreEqual(root.RequestId, inner.ParentRequestId);
                MockLoggers.TelemetryLogger.Verify(x => x.Log(It.IsAny<LogEntry>()), Times.AtLeastOnce);
            }, null);
        }

        // A simple SynchronizationContext that encapsulates it's own dedicated task queue and processing
        // thread for servicing Send() & Post() calls.  
        // Based upon http://blogs.msdn.com/b/pfxteam/archive/2012/01/20/10259049.aspx but uses it's own thread
        // rather than running on the thread that it's instanciated on
        public sealed class DedicatedThreadSynchronisationContext : SynchronizationContext, IDisposable
        {
            public DedicatedThreadSynchronisationContext()
            {
                m_thread = new Thread(ThreadWorkerDelegate);
                m_thread.Start(this);
            }

            public void Dispose()
            {
                m_queue.CompleteAdding();
            }

            /// <summary>Dispatches an asynchronous message to the synchronization context.</summary>
            /// <param name="d">The System.Threading.SendOrPostCallback delegate to call.</param>
            /// <param name="state">The object passed to the delegate.</param>
            public override void Post(SendOrPostCallback d, object state)
            {
                if (d == null) throw new ArgumentNullException("d");
                m_queue.Add(new KeyValuePair<SendOrPostCallback, object>(d, state));
            }

            /// <summary> As 
            public override void Send(SendOrPostCallback d, object state)
            {
                using (var handledEvent = new ManualResetEvent(false))
                {
                    Post(SendOrPostCallback_BlockingWrapper, Tuple.Create(d, state, handledEvent));
                    handledEvent.WaitOne();
                }
            }

            public int WorkerThreadId { get { return m_thread.ManagedThreadId; } }
            //=========================================================================================

            private static void SendOrPostCallback_BlockingWrapper(object state)
            {
                var innerCallback = (state as Tuple<SendOrPostCallback, object, ManualResetEvent>);
                try
                {
                    innerCallback.Item1(innerCallback.Item2);
                }
                finally
                {
                    innerCallback.Item3.Set();
                }
            }

            /// <summary>The queue of work items.</summary>
            private readonly BlockingCollection<KeyValuePair<SendOrPostCallback, object>> m_queue =
                new BlockingCollection<KeyValuePair<SendOrPostCallback, object>>();

            private readonly Thread m_thread = null;

            /// <summary>Runs an loop to process all queued work items.</summary>
            private void ThreadWorkerDelegate(object obj)
            {
                SynchronizationContext.SetSynchronizationContext(obj as SynchronizationContext);

                try
                {
                    foreach (var workItem in m_queue.GetConsumingEnumerable())
                        workItem.Key(workItem.Value);
                }
                catch (ObjectDisposedException) { }
            }
        }
    }
}
