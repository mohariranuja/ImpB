﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Owin.Hosting;
using Newtonsoft.Json;
using NUnit.Framework;
using Xpo.Common.Telemetry.Http;
using Xpo.Common.Telemetry.Tests.TestWebApi;

namespace Xpo.Common.Telemetry.Tests.Owin
{
    public class OwinTestBase
    {
        private IDisposable _server;

        protected readonly string HostAddress = "http://localhost:9999/";

        protected HttpClient HttpClient { get; } = new HttpClient();

        [TestFixtureSetUp]
        protected void SetUp()
        {
            _server = WebApp.Start<TestOwinStartup>(HostAddress);
        }

        [TestFixtureTearDown]
        protected void TearDown()
        {
            _server.Dispose();
        }

    }

    // Internal class for testing that is mutable and can be deserialized directly
    internal class TelemetryContextDataTest
    {
        public TelemetryContextDataTest()
        {
        }

        public TelemetryContextDataTest(TelemetryContextData data)
        {
            CorrelationId = data.CorrelationId;
            RequestId = data.RequestId;
            ParentRequestId = data.ParentRequestId;
        }

        public string CorrelationId { get; set; }

        public string RequestId { get; set; }

        public string ParentRequestId { get; set; }
    }
}
