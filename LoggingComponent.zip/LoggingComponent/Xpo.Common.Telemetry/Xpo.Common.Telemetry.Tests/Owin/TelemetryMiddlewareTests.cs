﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NUnit.Framework;

namespace Xpo.Common.Telemetry.Tests.Owin
{
    [TestFixture]
    public class TelemetryMiddlewareTests : OwinTestBase
    {
        [Test]
        public async Task Should_Read_PassedInHeaders()
        {
            var correlationId = TelemetryContextData.GetNewId();
            var parentRequestId = TelemetryContextData.GetNewId();
            HttpClient.DefaultRequestHeaders.Add(TelemetryConstants.HeaderNames.CorrelationId, correlationId);
            HttpClient.DefaultRequestHeaders.Add(TelemetryConstants.HeaderNames.ParentRequestId, parentRequestId);

            var response = await HttpClient.GetAsync(HostAddress + "/test");
            var content = await response.Content.ReadAsStringAsync();

            var telData = JsonConvert.DeserializeObject<TelemetryContextDataTest>(content);

            Assert.AreEqual(correlationId, telData.CorrelationId);
            Assert.AreEqual(parentRequestId, telData.ParentRequestId);
            Assert.IsNotEmpty(telData.RequestId);
        }

        [Test]
        public async Task Should_Have_EmptyValues_WithNoHeaders()
        {
            var response = await HttpClient.GetAsync(HostAddress + "/test");
            var content = await response.Content.ReadAsStringAsync();

            var telData = JsonConvert.DeserializeObject<TelemetryContextDataTest>(content);

            Assert.IsNotEmpty(telData.CorrelationId);
            Assert.IsNotEmpty(telData.RequestId);
            Assert.AreEqual(null, telData.ParentRequestId);
        }

        [Test]
        public async Task Should_Have_DifferentCorrelationIds_For_2Requests()
        {
            var response1 = await HttpClient.GetAsync(HostAddress + "/test");
            var telData1 = JsonConvert.DeserializeObject<TelemetryContextDataTest>(await response1.Content.ReadAsStringAsync());

            Assert.IsNotEmpty(telData1.CorrelationId);
            Assert.AreEqual(null, telData1.ParentRequestId);
            Assert.IsNotEmpty(telData1.RequestId);

            var response2 = await HttpClient.GetAsync(HostAddress + "/test");
            var telData2 = JsonConvert.DeserializeObject<TelemetryContextDataTest>(await response2.Content.ReadAsStringAsync());

            Assert.IsNotEmpty(telData2.CorrelationId);
            Assert.AreEqual(null, telData2.ParentRequestId);
            Assert.IsNotEmpty(telData2.RequestId);

            Assert.AreNotEqual(telData1.CorrelationId, telData2.CorrelationId);
            Assert.AreNotEqual(telData1.RequestId, telData2.RequestId);
        }

        [Test]
        public async Task Http_Response_Headers_Should_Return_Telemetry_Ids()
        {
            var response1 = await HttpClient.GetAsync(HostAddress + "/test");
            var telData1 = JsonConvert.DeserializeObject<TelemetryContextDataTest>(await response1.Content.ReadAsStringAsync());

            var correlationIdResponse1 = response1.Headers.GetValues(TelemetryConstants.HeaderNames.CorrelationId).Single();
            Assert.AreEqual(telData1.CorrelationId, correlationIdResponse1);

            var requestIdResponse1 = response1.Headers.GetValues(TelemetryConstants.HeaderNames.RequestId).Single();
            Assert.AreEqual(telData1.RequestId, requestIdResponse1);

            var response2 = await HttpClient.GetAsync(HostAddress + "/test");
            var telData2 = JsonConvert.DeserializeObject<TelemetryContextDataTest>(await response2.Content.ReadAsStringAsync());

            var correlationIdResponse2 = response2.Headers.GetValues(TelemetryConstants.HeaderNames.CorrelationId).Single();
            Assert.AreEqual(telData2.CorrelationId, correlationIdResponse2);

            var requestIdResponse2 = response2.Headers.GetValues(TelemetryConstants.HeaderNames.RequestId).Single();
            Assert.AreEqual(telData2.RequestId, requestIdResponse2);

            Assert.AreNotEqual(telData1.CorrelationId, telData2.CorrelationId);
            Assert.AreNotEqual(telData1.RequestId, telData2.RequestId);
        }

    }

}
