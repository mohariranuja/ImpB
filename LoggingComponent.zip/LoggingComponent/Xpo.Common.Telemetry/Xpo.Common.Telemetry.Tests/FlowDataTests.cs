﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nito.AsyncEx;
using NUnit.Framework;

namespace Xpo.Common.Telemetry.Tests
{
    [TestFixture]
    public class FlowDataTests
    {
        [Test]
        public void Should_FlowData_AcrossThreads()
        {
            var telData = TelemetryContextData.Create();

            var callContext = TelemetryContext.Current;

            callContext.Begin(telData);

            Assert.AreEqual(telData.CorrelationId, callContext.Data.CorrelationId);

            var data2 = Task.Run(() =>
            {
                var context = TelemetryContext.Current;

                return context.Data;
            }).GetAwaiter().GetResult();


            Assert.AreEqual(telData.CorrelationId, data2.CorrelationId);
        }

        [Test]
        public void Should_FlowData_AcrossCapturedContexts()
        {
            var telData = TelemetryContextData.Create();

            var callContext = TelemetryContext.Current;

            callContext.Begin(telData);

            Assert.AreEqual(telData.CorrelationId, callContext.Data.CorrelationId);

            var data2 = AsyncContext.Run(() =>
            {
                var context = TelemetryContext.Current;

                return context.Data;
            });

            Assert.AreEqual(telData.CorrelationId, data2.CorrelationId);
        }
    }
}
