[Sample application wired up with telemetry and lumberjack.](https://github.com/xpologistics/xpo-lumberjack/tree/master/samples/sample1)

## Web API instrumentation
1. Install Telemery Owin Package
    ```powershell
    Install-Package Xpo.Common.Telemetry.Owin
    ```
2. Install NLog Lumberjack Target Package
    ```powershell
    Install-Package NLog.Xpo.Lumberjack.Api.NLog4
    ```
3. Configure NLog Lumberjack target
    ```csharp
    LumberjackTargetConfig.Configure("Platform", "api");
    ```
4. Register Telemetry Owin Middleware in your Startup.cs owin startup class
    ```csharp

    public void Configuration(IAppBuilder app)
    {
        var kernel = new Bootstrapper().Kernel;

        ConfigureTelemetry(app, kernel);

        // Other initialization ...
    }

    private void ConfigureTelemetry(IAppBuilder app, IKernel kernel)
    {
        LumberjackTargetConfig.Configure("Platform", "api"); // Set proper values

        var kernel = new Bootstrapper().Kernel;

        var telemOptions = new TelemetryMiddlewareOptions
        {
            LogManager = kernel.Get<ILogManager>()
        };

        app.UseXpoTelemetry(telemOptions);       
    }
    ```
5. Install Version 2.0 or higher of Xpo.Common.Logging and Xpo.Common.Logging.NLog4
   ```powershell
    Install-Package Xpo.Common.Logging
    Install-Package Xpo.Common.Logging.NLog4
    ```
    or if you already have them
    ```powershell
    Update-Package Xpo.Common.Logging
    Update-Package Xpo.Common.Logging.NLog4
    ```
6. Owin application is now telemetry instrumented, Xpo.MOM and Xpo.Common.XpoApiClient will now pass around telemetry data.

## Topshelf Service Instumentation
1. Install Telemery Package
    ```powershell
    Install-Package Xpo.Common.Telemetry
    ```
2. Install NLog Lumberjack Target Package
    ```powershell
    Install-Package NLog.Xpo.Lumberjack.Api.NLog4
    ```
3. Configure NLog Lumberjack target when the service starts
    ```csharp
    LumberjackTargetConfig.Configure("Platform", "api");
    ```
4. Install Version 2.0 or higher of Xpo.Common.Logging and Xpo.Common.Logging.NLog4
    ```powershell
    Install-Package Xpo.Common.Logging
    Install-Package Xpo.Common.Logging.NLog4
    ```
    or if you already have them
    ```powershell
    Update-Package Xpo.Common.Logging
    Update-Package Xpo.Common.Logging.NLog4
    ```
5. Service is now telemetry instrumented, Xpo.MOM and Xpo.Common.XpoApiClient will now pass around telemetry data.

## NLog Lumberjack Target
[See the doc here.](https://github.com/xpologistics/xpo-lumberjack/blob/master/README.md)
