﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Owin;
using Xpo.Common.Logging;
using Xpo.Common.Telemetry;
using System.Web;

namespace Xpo.Common.Telemetry.Owin
{
    /// <inheritdoc />
    /// <summary>
    /// </summary>
    public class TelemetryMiddleware : OwinMiddleware
    {
        private readonly TelemetryMiddlewareOptions _options;

        public TelemetryMiddleware(OwinMiddleware next, TelemetryMiddlewareOptions options) : base(next)
        {
            if (options == null) throw new ArgumentNullException(nameof(options));
            if (options.LogManager == null) throw new ArgumentNullException(nameof(options.LogManager));

            _options = options;
        }

        public override async Task Invoke(IOwinContext context)
        {
            var logger = _options.LogManager.Get(TelemetryConstants.LogName);

            var correlationId = GetHeaderValue(context, TelemetryConstants.HeaderNames.CorrelationId);
            var parentRequestId = GetHeaderValue(context, TelemetryConstants.HeaderNames.ParentRequestId);

            var telData = TelemetryContextData.Create(correlationId, parentRequestId);

            TelemetryContext.Current.Begin(telData);

            context.Response.OnSendingHeaders(ctx =>
            {
                if (HttpContext.Current?.Response?.HeadersWritten == true)
                {
                    return;
                }

                context.Response.Headers.Add(TelemetryConstants.HeaderNames.CorrelationId,
                    new[] {telData .CorrelationId});

                context.Response.Headers.Add(TelemetryConstants.HeaderNames.RequestId, new[] {telData.RequestId});
            }, null);

            var stopWatch = new Stopwatch();

            stopWatch.Start();

            LogStart(context, logger);

            try
            {
                await Next.Invoke(context);
            }
            finally
            {
                stopWatch.Stop();

                var timeElapsed = stopWatch.Elapsed.TotalMilliseconds;

                LogEnd(context, logger, timeElapsed);

                TelemetryContext.Current.End();
            }
        }

        private string GetHeaderValue(IOwinContext context, string key)
        {
            if (context.Request.Headers.ContainsKey(key))
            {
                return context.Request.Headers[key];
            }

            return null;
        }

        private void LogStart(IOwinContext context, ILogger logger)
        {
            if (!_options.EnableRequestStartLogging) return;

            var args = new Dictionary<string, object>
            {
                { "Telemetry:Owin:RequestUri", HttpUtility.UrlDecode(context.Request.Uri.AbsoluteUri) },
                { "Telemetry:Owin:Method", context.Request.Method }
            };

            logger.Log(new LogEntry(LogLevel.Trace, "Owin Request Start", null, args));
        }

        private void LogEnd(IOwinContext context, ILogger logger, double timeElapsed) 
        {
            if (!_options.EnableRequestEndLogging) return;

            var args = new Dictionary<string, object>
            {
                { "Telemetry:Owin:RequestUri", HttpUtility.UrlDecode(context.Request.Uri.AbsoluteUri) },
                { "Telemetry:Owin:Method", context.Request.Method },
                { "Telemetry:Owin:ResponseStatusCode", context.Response.StatusCode },
                { "Telemetry:Owin:TimeElapsed", timeElapsed }
            };

            logger.Log(new LogEntry(LogLevel.Trace, "Owin Request End", null, args));
        }
    }
}
