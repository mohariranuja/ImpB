﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xpo.Common.Telemetry.Owin;

namespace Owin
{
    public static class AppBuilderExtensions
    {
        public static void UseXpoTelemetry(this IAppBuilder app, TelemetryMiddlewareOptions options)
        {
            app.Use<TelemetryMiddleware>(options);
        }
    }
}
