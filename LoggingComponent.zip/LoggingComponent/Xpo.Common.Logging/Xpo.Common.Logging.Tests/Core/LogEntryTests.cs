﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Threading;
using Xpo.Common.Telemetry;

namespace Xpo.Common.Logging.Tests.Core
{
    [TestFixture]
    public class LogEntryTests
    {
        private TelemetryContextData GenerateTestTelemetryData()
        {
            return TelemetryContextData.Create(TelemetryContextData.GetNewId(), TelemetryContextData.GetNewId());
        }

        [Test]
        public void LogEntryConstructor1_ShouldProduceCorrectProperties()
        {
            var contextData = GenerateTestTelemetryData();

            TelemetryContext.Current.Begin(contextData);

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("test_user", "test_authentication_type"),
                new[] { "test_role" });

            var logEntry = new LogEntry(LogLevel.Error, "Test");

            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CorrelationId"], contextData.CorrelationId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:RequestId"], contextData.RequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ParentRequestId"], contextData.ParentRequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsInitialized"], true);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:Username"], Thread.CurrentPrincipal.Identity.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:AuthenticationType"], Thread.CurrentPrincipal.Identity.AuthenticationType);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsAuthenticated"], Thread.CurrentPrincipal.Identity.IsAuthenticated);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadId"], Thread.CurrentThread.ManagedThreadId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadName"], Thread.CurrentThread.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CultureName"], Thread.CurrentThread.CurrentCulture.Name);

            TelemetryContext.Current.End();
        }

        [Test]
        public void LogEntryConstructor2_ShouldProduceCorrectProperties()
        {
            var contextData = GenerateTestTelemetryData();

            var extraProperties = new Dictionary<string, object>
            {
                { "MyProperty", 1 },
                { "MyProperty1", 2 }
            };

            TelemetryContext.Current.Begin(contextData);

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("test_user", "test_authentication_type"),
                new[] { "test_role" });

            var logEntry = new LogEntry(LogLevel.Error, "Test", null, extraProperties);

            Assert.AreEqual(logEntry.Properties["MyProperty"], 1);
            Assert.AreEqual(logEntry.Properties["MyProperty1"], 2);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CorrelationId"], contextData.CorrelationId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:RequestId"], contextData.RequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ParentRequestId"], contextData.ParentRequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsInitialized"], true);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:Username"], Thread.CurrentPrincipal.Identity.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:AuthenticationType"], Thread.CurrentPrincipal.Identity.AuthenticationType);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsAuthenticated"], Thread.CurrentPrincipal.Identity.IsAuthenticated);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadId"], Thread.CurrentThread.ManagedThreadId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadName"], Thread.CurrentThread.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CultureName"], Thread.CurrentThread.CurrentCulture.Name);

            TelemetryContext.Current.End();
        }

        [Test]
        public void LogEntryConstructor3_ShouldProduceCorrectProperties()
        {
            var contextData = GenerateTestTelemetryData();

            TelemetryContext.Current.Begin(contextData);

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("test_user", "test_authentication_type"),
                new[] { "test_role" });

            var logEntry = new LogEntry(LogLevel.Error, "Test", null, new Exception());

            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CorrelationId"], contextData.CorrelationId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:RequestId"], contextData.RequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ParentRequestId"], contextData.ParentRequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsInitialized"], true);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:Username"], Thread.CurrentPrincipal.Identity.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:AuthenticationType"], Thread.CurrentPrincipal.Identity.AuthenticationType);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsAuthenticated"], Thread.CurrentPrincipal.Identity.IsAuthenticated);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadId"], Thread.CurrentThread.ManagedThreadId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadName"], Thread.CurrentThread.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CultureName"], Thread.CurrentThread.CurrentCulture.Name);

            TelemetryContext.Current.End();
        }

        [Test]
        public void LogEntryConstructor4_ShouldProduceCorrectProperties()
        {
            var contextData = GenerateTestTelemetryData();

            TelemetryContext.Current.Begin(contextData);

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("test_user", "test_authentication_type"),
                new[] { "test_role" });

            var logEntry = new LogEntry(LogLevel.Error, "Test", null);

            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CorrelationId"], contextData.CorrelationId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:RequestId"], contextData.RequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ParentRequestId"], contextData.ParentRequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsInitialized"], true);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:Username"], Thread.CurrentPrincipal.Identity.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:AuthenticationType"], Thread.CurrentPrincipal.Identity.AuthenticationType);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsAuthenticated"], Thread.CurrentPrincipal.Identity.IsAuthenticated);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadId"], Thread.CurrentThread.ManagedThreadId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadName"], Thread.CurrentThread.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CultureName"], Thread.CurrentThread.CurrentCulture.Name);

            TelemetryContext.Current.End();
        }

        [Test]
        public void LogEntryConstructor5_ShouldProduceCorrectProperties()
        {
            var contextData = GenerateTestTelemetryData();

            var extraProperties = new Dictionary<string, object>
            {
                { "MyProperty", 1 },
                { "MyProperty1", 2 }
            };

            TelemetryContext.Current.Begin(contextData);

            Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("test_user", "test_authentication_type"),
                new[] { "test_role" });

            var logEntry = new LogEntry(LogLevel.Error, "Test", null, extraProperties, new Exception());

            Assert.AreEqual(logEntry.Properties["MyProperty"], 1);
            Assert.AreEqual(logEntry.Properties["MyProperty1"], 2);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CorrelationId"], contextData.CorrelationId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:RequestId"], contextData.RequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ParentRequestId"], contextData.ParentRequestId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsInitialized"], true);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:Username"], Thread.CurrentPrincipal.Identity.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:AuthenticationType"], Thread.CurrentPrincipal.Identity.AuthenticationType);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsAuthenticated"], Thread.CurrentPrincipal.Identity.IsAuthenticated);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadId"], Thread.CurrentThread.ManagedThreadId);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:ThreadName"], Thread.CurrentThread.Name);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:CultureName"], Thread.CurrentThread.CurrentCulture.Name);

            TelemetryContext.Current.End();
        }

        [Test]
        public void Basic_ShouldHaveNoTelemetryContextInitializedOrUser()
        {
            TelemetryContext.Current.End();
            Thread.CurrentPrincipal = null;

            var logEntry = new LogEntry(LogLevel.Error, "Test");
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsInitialized"], false);
            Assert.AreEqual(logEntry.Properties["Telemetry:Core:IsAuthenticated"], false);
        }
    }
}
