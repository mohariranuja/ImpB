﻿using System.Collections.Generic;
using System.Text;
using NLog;
using NLog.LayoutRenderers;
using NLog.LayoutRenderers.Wrappers;

namespace Xpo.Common.Logging.Tests.NLog.Interception
{
    [LayoutRenderer("intercept")]
    public sealed class InterceptLayoutRendererWrapper : WrapperLayoutRendererBuilderBase
    {
        public static string Message { get; set; }

        public static IDictionary<object, object> Properties { get; private set; }

        protected override void TransformFormattedMesssage(StringBuilder target)
        {
            
        }

        protected override void RenderFormattedMessage(LogEventInfo logEvent, StringBuilder target)
        {
            base.RenderFormattedMessage(logEvent, target);

            Message = target.ToString();

            Properties = logEvent.Properties;
        }
    }
}
