# Xpo.Common.Logging.NLog4

Xpo.Common.Logging.NLog4 provides an implementation of the Xpo.Commong.Logging framework for NLog4.  

## Installation 

```powershell
PM> Install-Package Xpo.Common.Logging.NLog4
```

## Dependencies 
* [Xpo.Common.Logging](../Xpo.Common.Logging)
* [NLog4](https://www.nuget.org/packages/NLog/4.3.11)

## Usage

### Logging
Refer to ILogger documentation in [Xpo.Common.Logging](../Xpo.Common.Logging)

### Registering with Ninject
```csharp
kernel.Bind<ILogManager>().Constant<NLogLogManager>();
```

## Releases

### 1.0.0
* Initial release

### 2.0
* Update Xpo.Common.Logging to version 2.0