﻿using System;
using NLog;

namespace Xpo.Common.Logging.NLog4
{
    /// <summary>
    /// Class NLogLogManager.
    /// </summary>
    public class NLogLogManager : ILogManager
    {
        /// <summary>
        /// Gets this instance.
        /// </summary>
        /// <returns>ILogger.</returns>
        public ILogger Get()
        {
            return Get("DEFAULT");
        }

        /// <summary>
        /// Gets the specified name.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>ILogger.</returns>
        public ILogger Get(string name)
        {
            return new NLogLogger(LogManager.GetLogger(name));
        }

        /// <summary>
        /// Gets this instance.
        /// </summary>
        /// <typeparam name="T">type of logger</typeparam>
        /// <returns>ILogger.</returns>
        public ILogger Get<T>()
        {
            return Get(typeof (T));
        }

        /// <summary>
        /// Gets the specified type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>ILogger.</returns>
        public ILogger Get(Type type)
        {
            return new NLogLogger(LogManager.GetLogger(type.Name));
        }
    }
}