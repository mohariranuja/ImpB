# Xpo.Common.Logging

## Releases

### 1.0
* Initial Release

### 2.0
* Update Xpo.Common.Logging dependency to version 2.0
* Update Newtonsoft.Json from 8.0.3 to 9.0.1