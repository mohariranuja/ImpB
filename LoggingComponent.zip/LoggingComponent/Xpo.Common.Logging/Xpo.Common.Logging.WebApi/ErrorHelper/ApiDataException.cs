﻿
using System;
using System.Net;
using System.Runtime.Serialization;

namespace Xpo.Common.Logging.WebApi.ErrorHelper
{
    /// <summary>
    /// Api Data Exception
    /// </summary>
    [Serializable]
    [DataContract]
    public class ApiDataException : Exception, IApiExceptions
    {
        /// <summary>
        /// The reason phrase
        /// </summary>
        private string _reasonPhrase = "ApiDataException";

        /// <summary>
        /// Public constructor for Api Data Exception
        /// </summary>
        /// <param name="errorCode">The error code.</param>
        /// <param name="errorDescription">The error description.</param>
        /// <param name="httpStatus">The HTTP status.</param>
        public ApiDataException(int errorCode, string errorDescription, HttpStatusCode httpStatus)
        {
            ErrorCode = errorCode;
            ErrorDescription = errorDescription;
            HttpStatus = httpStatus;
        }

        /// <summary>
        /// ErrorCode
        /// </summary>
        /// <value>The error code.</value>
        [DataMember]
        public int ErrorCode { get; set; }

        /// <summary>
        /// ErrorDescription
        /// </summary>
        /// <value>The error description.</value>
        [DataMember]
        public string ErrorDescription { get; set; }

        /// <summary>
        /// HttpStatus
        /// </summary>
        /// <value>The HTTP status.</value>
        [DataMember]
        public HttpStatusCode HttpStatus { get; set; }


        /// <summary>
        /// ReasonPhrase
        /// </summary>
        /// <value>The reason phrase.</value>
        [DataMember]
        public string ReasonPhrase
        {
            get { return _reasonPhrase; }

            set { _reasonPhrase = value; }
        }
    }
}