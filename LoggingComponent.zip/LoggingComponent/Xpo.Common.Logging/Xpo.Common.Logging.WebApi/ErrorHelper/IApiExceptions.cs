﻿using System.Net;

namespace Xpo.Common.Logging.WebApi.ErrorHelper
{
    /// <summary>
    /// IApiExceptions Interface
    /// </summary>
    public interface IApiExceptions
    {
        /// <summary>
        /// ErrorCode
        /// </summary>
        /// <value>The error code.</value>
        int ErrorCode { get; set; }

        /// <summary>
        /// ErrorDescription
        /// </summary>
        /// <value>The error description.</value>
        string ErrorDescription { get; set; }

        /// <summary>
        /// HttpStatus
        /// </summary>
        /// <value>The HTTP status.</value>
        HttpStatusCode HttpStatus { get; set; }

        /// <summary>
        /// ReasonPhrase
        /// </summary>
        /// <value>The reason phrase.</value>
        string ReasonPhrase { get; set; }
    }
}