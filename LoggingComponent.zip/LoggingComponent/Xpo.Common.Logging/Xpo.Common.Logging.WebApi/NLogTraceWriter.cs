﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Http.Tracing;
using System.Web.Script.Serialization;
using NLog;
using Xpo.Common.Logging.WebApi.ErrorHelper;

namespace Xpo.Common.Logging.WebApi
{
    /// <summary>
    /// NLog implementation of webapi's ITraceWriter tracing extensibility point.
    /// </summary>
    public class NLogTraceWriter : ITraceWriter
    {
        /// <summary>
        /// The class logger
        /// </summary>
        private static readonly Logger classLogger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// The logging map
        /// </summary>
        private static readonly Lazy<Dictionary<TraceLevel, Action<string>>> loggingMap =
            new Lazy<Dictionary<TraceLevel, Action<string>>>(() => new Dictionary<TraceLevel, Action<string>>
                                                                       {
                                                                           { TraceLevel.Info, classLogger.Info },
                                                                           { TraceLevel.Debug, classLogger.Debug },
                                                                           { TraceLevel.Error, classLogger.Error },
                                                                           { TraceLevel.Fatal, classLogger.Fatal },
                                                                           { TraceLevel.Warn, classLogger.Warn }
                                                                       });
        /// <summary>
        /// The traceRecord key
        /// </summary>
        public const string RecordKey = "webapi_trace_record";

        /// <summary>
        /// The request key
        /// </summary>
        public const string RequestKey = "webapi_request";

        /// <summary>
        /// Gets the logger.
        /// </summary>
        /// <value>The logger.</value>
        private Dictionary<TraceLevel, Action<string>> Logger
        {
            get { return loggingMap.Value; }
        }

        /// <summary>
        /// Traces the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="category">The category.</param>
        /// <param name="level">The level.</param>
        /// <param name="traceAction">The trace action.</param>
        public void Trace(HttpRequestMessage request, string category, TraceLevel level, Action<TraceRecord> traceAction)
        {
            if (level != TraceLevel.Off)
            {
                if (traceAction != null && traceAction.Target != null)
                    category = string.Format("{0}{1}Action Parameters : {2}", category, Environment.NewLine, ToJson(traceAction.Target));
                var record = new TraceRecord(request, category, level);
                if (traceAction != null)
                    traceAction(record);
                Log(record);
            }
        }

        /// <summary>
        /// To the json.
        /// </summary>
        /// <param name="object">The object.</param>
        /// <returns>System.String.</returns>
        private string ToJson(object @object)
        {

            var serializer = new JavaScriptSerializer();
            try
            {
                return serializer.Serialize(@object);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        #region Logs

        /// <summary>
        /// Logs info/Error to Log file
        /// </summary>
        /// <param name="traceRecord">The trace record.</param>
        private void Log(TraceRecord traceRecord)
        {
            var message = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(traceRecord.Message))
                message.AppendLine(string.Empty).Append(traceRecord.Message);

            if (traceRecord.Request != null)
            {
                if (traceRecord.Request.Method != null)
                    message.AppendLine(string.Empty).AppendFormat("Method: {0}", traceRecord.Request.Method);

                if (traceRecord.Request.RequestUri != null)
                    message.AppendLine(string.Empty).AppendFormat("URL: {0}", traceRecord.Request.RequestUri);

                if (traceRecord.Request.Headers != null &&
                    traceRecord.Request.Headers.Contains("Token") &&
                    traceRecord.Request.Headers.GetValues("Token") != null &&
                    traceRecord.Request.Headers.GetValues("Token").FirstOrDefault() != null)
                    message.AppendLine(string.Empty).AppendFormat("Token: {0}", traceRecord.Request.Headers.GetValues("Token").FirstOrDefault());
            }

            if (!string.IsNullOrWhiteSpace(traceRecord.Category))
                message.Append(" ").Append(traceRecord.Category);

            if (!string.IsNullOrWhiteSpace(traceRecord.Operator))
                message.Append(" ").Append(traceRecord.Operator).Append(" ").Append(traceRecord.Operation);

            if (traceRecord.Exception != null && !string.IsNullOrWhiteSpace(traceRecord.Exception.GetBaseException().Message))
            {
                var exceptionType = traceRecord.Exception.GetType();
                message.AppendLine();
                if (exceptionType == typeof(ApiException))
                {
                    var exception = traceRecord.Exception as ApiException;
                    if (exception != null)
                    {
                        message.AppendLine(string.Empty).AppendFormat("Error: {0}", exception.ErrorDescription);
                        message.AppendLine(string.Empty).AppendFormat("Error Code: {0}", exception.ErrorCode);
                    }
                }
                else if (exceptionType == typeof(ApiBusinessException))
                {
                    var exception = traceRecord.Exception as ApiBusinessException;
                    if (exception != null)
                    {
                        message.AppendLine(string.Empty).AppendFormat("Error: {0}", exception.ErrorDescription);
                        message.AppendLine(string.Empty).AppendFormat("Error Code: {0}", exception.ErrorCode);
                    }
                }
                else if (exceptionType == typeof(ApiDataException))
                {
                    var exception = traceRecord.Exception as ApiDataException;
                    if (exception != null)
                    {
                        message.AppendLine(string.Empty).AppendFormat("Error: {0}", exception.ErrorDescription);
                        message.AppendLine(string.Empty).AppendFormat("Error Code: {0}", exception.ErrorCode);
                    }
                }
                else
                    message.AppendLine(string.Empty).AppendFormat("Error: {0}", traceRecord.Exception.GetBaseException().Message);
            }
            Logger[traceRecord.Level](message.ToString() + Environment.NewLine);
        }

        #endregion Logs
    }
}