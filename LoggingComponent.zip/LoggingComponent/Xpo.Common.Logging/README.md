# Xpo.Common.Logging

* [Xpo.Common.Logging Documentation](./Xpo.Common.Logging)
* [Xpo.Common.Logging.NLog2 Documentation](./Xpo.Common.Logging.NLog2)
* [Xpo.Common.Logging.NLog3 Documentation](./Xpo.Common.Logging.NLog3)
* [Xpo.Common.Logging.NLog4 Documentation](./Xpo.Common.Logging.NLog4)