﻿namespace Xpo.Common.Logging
{
    public interface ILogger
    {
        void Flush();

        void Log(LogEntry logEntry);
    }
}
