# Xpo.Common.Logging

Xpo.Common.Logging provides a common abstraction over logging frameworks.

## Installation 

```powershell
PM> Install-Package Xpo.Common.Logging
```

## Usage

### Constructing an ILogger
The ILogManager interface can be used to generate an ILogger implementation for a specific type or name.

```csharp
public class Something
{
  public Something(ILogManager logManager)
  {
    // construct generic logger
    ILogger genericLogger = logManager.Get();

    // construct named logger
    ILogger namedLogger = logManager.Get(name);

    // construct logger for a specific type
    ILogger loggerFromGeneric = logManager.Get<Something>();
    ILogger loggerFromGeneric = logManager.Get(typeof(Something);
  }  
}
```

### Logging Levels
The library features 7 different logging levels.  When creating a log entry select the level that is appropriate for the criticality of the data.
It is generally recomended to disable Lower levels such as Trace & Debug in production.
```csharp
public class LogLevel
{
    Trace,
    Debug,
    Info,
    Warn,
    Error,
    Fatal,
    Off
}
``` 

### Logging using the ILogger interface
The ILogger interface provides a single `Log(LogEntry logEnty)` method that can be used to write data to the log.

```charp
ILogger logger = logManager.Get();
logger.Log(new LogEntry(LogLevel.Info, "Some Message"));    
```

### Logging extension methods
Instead of using the Log method directly, it is recommended to use one of the logging extension methods.
```charp
ILogger logger = logManager.Get();

logger.Trace("Info");

logger.Debug("Debug");

logger.Info("Info");

logger.Warn("Warn");

logger.Error("Error");

logger.Fatal("Fatal");
```

### Logging of exceptions
The library provides an extension method to simplify the logging of exceptions.
```csharp
ILogger logger = logManager.Get();
logger.LogException(LogLevel.Error, "An Exception", new Exception());  
```

### Logging of custom properties
The library provides the ability to pass custom data to the logger via a dictionary. This allows you to use this data in custom targets and layouts to render your data.
```csharp
ILogger logger = logManager.Get();
logger.Log(new LogEntry(LogLevel.Error, "Something went wrong {0}, {1}, {2}", new object[] {2, 4, 5}, new Dictionary<string, object> { {"MyProperty", "MyValue"} }));  
```

## Implementations
* [ConsoleLogger](./Console)
* [MultiThreadedLogger](./Multithreaded)
* [NLog4](../Xpo.Common.Logging.NLog4)

## Releases

### 1.0.0
* Initial release

### 2.0
* Deprecate NLog2 and NLog3 implementations
* Include Xpo.Common.Telemetry reference
* Add Custom Properties to LogEntry class
  * Custom Propertied are including Telemetry values by default  