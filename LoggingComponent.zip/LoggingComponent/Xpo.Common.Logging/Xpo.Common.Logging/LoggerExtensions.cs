﻿using System;

namespace Xpo.Common.Logging
{
    /// <summary>
    /// Extensions for the logger
    /// </summary>
    public static class LoggerExtensions
    {
        /// <summary>
        /// Debugs the specified logger.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Debug(this ILogger logger, string message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Debug, message, args));
        }

        /// <summary>
        /// Debugs the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Debug(this ILogger logger, Func<string> message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Debug, message(), args));
        }

        /// <summary>
        /// Errors the specified logger.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Error(this ILogger logger, string message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Error, message, args));
        }

        /// <summary>
        /// Errors the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="ex">The ex.</param>
        /// <param name="args">The arguments.</param>
        public static void Error(this ILogger logger, string message, Exception ex, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Error, message, args, ex));
        }

        /// <summary>
        /// Errors the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Error(this ILogger logger, Func<string> message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Error, message(), args));
        }

        /// <summary>
        /// Fatals the specified logger.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Fatal(this ILogger logger, string message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Fatal, message, args));
        }

        /// <summary>
        /// Fatals the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Fatal(this ILogger logger, Func<string> message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Fatal, message(), args));
        }

        /// <summary>
        /// Informations the specified logger.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Info(this ILogger logger, string message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Info, message, args));
        }

        /// <summary>
        /// Informations the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Info(this ILogger logger, Func<string> message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Info, message(), args));
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        /// <param name="exception">The exception.</param>
        public static void LogException(this ILogger logger, LogLevel logLevel, string message, Exception exception)
        {
            logger.Log(new LogEntry(logLevel, message, new object[0], exception));
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        /// <param name="exception">The exception.</param>
        public static void LogException(this ILogger logger, LogLevel logLevel, string message, object[] args, Exception exception)
        {
            logger.Log(new LogEntry(logLevel, message, args, exception));
        }

        /// <summary>
        /// Traces the specified logger.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Trace(this ILogger logger, string message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Trace, message, args));
        }

        /// <summary>
        /// Traces the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Trace(this ILogger logger, Func<string> message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Trace, message(), args));
        }

        /// <summary>
        /// Warns the specified logger.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Warn(this ILogger logger, string message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Warn, message, args));
        }

        /// <summary>
        /// Warns the specified message.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The arguments.</param>
        public static void Warn(this ILogger logger, Func<string> message, params object[] args)
        {
            logger.Log(new LogEntry(LogLevel.Warn, message(), args));
        }
    }
}