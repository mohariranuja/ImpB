﻿using System;

namespace Xpo.Common.Logging
{
    public interface ILogManager
    {
        ILogger Get();

        ILogger Get(string name);

        ILogger Get<T>();

        ILogger Get(Type type);
    }
}
