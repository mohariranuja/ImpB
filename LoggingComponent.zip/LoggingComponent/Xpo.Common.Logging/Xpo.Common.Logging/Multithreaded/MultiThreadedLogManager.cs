﻿using System;
using System.Threading;

namespace Xpo.Common.Logging.Multithreaded
{
    /// <summary>
    /// Special wrapper class for a log that adds additional
    /// </summary>
    public class MultiThreadedLogManager : ILogManager
    {
        private readonly ILogManager _logManager;
        private readonly Thread _mainThread;

        public MultiThreadedLogManager(ILogManager logManager, Thread mainThread)
        {
            _logManager = logManager;
            _mainThread = mainThread;
        }

        public ILogger Get()
        {
            return new MultiThreadedLogger(_logManager.Get(), _mainThread);
        }

        public ILogger Get(string name)
        {
            return new MultiThreadedLogger(_logManager.Get(name), _mainThread);
        }

        public ILogger Get<T>()
        {
            return Get(typeof (T));
        }

        public ILogger Get(Type type)
        {
            return Get(type.Name);
        }
    }
}
