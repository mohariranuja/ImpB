﻿using LoggingComponent;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Telemetry.Owin
{
    public static class AppBuilderExtensions
    {
        public static void UseXpoTelemetry(this IAppBuilder app, TelemetryMiddlewareOptions options)
        {
            app.Use<TelemetryMiddleware>(options);
        }
    }
}
