﻿

using LoggingComponent;

namespace Telemetry.Owin
{
    public class TelemetryMiddlewareOptions
    {
        public ILogManager LogManager { get; set; }

        /// <summary>
        /// Log an entry "Owin Request Start" when an HTTP request begins
        /// </summary>
        public bool EnableRequestStartLogging { get; set; } = true;

        /// <summary>
        /// Log an entry "Owin Request End" when an HTTP request ends
        /// </summary>
        public bool EnableRequestEndLogging { get; set; } = true;
    }
}
