﻿using NLog;
using NLog.Config;
using NLog.Targets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoggingComponent;
using Logging.NLog4;
using Telemetry;
using System.Threading;
using System.Security.Principal;

namespace ConsoleAppTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // Step 1. Create configuration object 
            var config = new LoggingConfiguration();

            // Step 2. Create targets and add them to the configuration 
            var consoleTarget = new ColoredConsoleTarget();
            config.AddTarget("console", consoleTarget);

            var fileTarget = new FileTarget();
            config.AddTarget("file", fileTarget);

            // Step 3. Set target properties 
            consoleTarget.Layout = @"${date:format=HH\:mm\:ss} ${logger} ${message} ${event-properties:item=Telemetry:Core:CorrelationId}";
            
            fileTarget.FileName = @"C:\global-logs\logs.txt";
            fileTarget.Layout = "${message} ${event-properties:item=CorrelationId}";
            //includeAllProperties="true" will add telemetry properties
            // Step 4. Define rules
            var rule1 = new LoggingRule("*", NLog.LogLevel.Debug, consoleTarget);
            config.LoggingRules.Add(rule1);

            var rule2 = new LoggingRule("*", NLog.LogLevel.Debug, fileTarget);
            config.LoggingRules.Add(rule2);
            
            // Step 5. Activate the configuration
            LogManager.Configuration = config;
            /*one way is  it was private readonly */
            TestTelemetryData();
            NLogLogManager _logManager = new NLogLogManager();
        var _logger = _logManager.Get();//.Get("logger");
            _logger.Error($"Error while validating the user's session id in the claims with the session id in Couchbase cache.");
            //below is code from api client 
            //ILogManager logManager = new NLogLogManager();
            //  _logger = logManager.Get<GoogleApiClient>();

// ILogManager logManager

// _logger = logManager.Get(GetType());
/*   this is end*/
/* Xpo.Marketplace.Mom.EventProcessors in mp-jobs uses TelemetryMiddlewareOptions in startup.config which is used in EventProcessor.cs */ 

Logger logger = LogManager.GetCurrentClassLogger();
LoggingComponent.ILogger lgger = new Logging.NLog4.NLogLogger(logger);
lgger.Info("This is test", null);
try
{
    var z = 0;
    int x = 1/z;
}
catch(Exception ex)
{
    object[] x = new object[] { ex };
    Dictionary<string, object> y = new Dictionary<string, object>();
    y.Add("CorrelationId", Guid.NewGuid());
    lgger.Log(new LogEntry(LoggingComponent.LogLevel.Error, "test Log Entry Message", x,y));
    lgger.LogException(LoggingComponent.LogLevel.Error,"Divide by Zero", ex);
}
Console.ReadKey();

}

private static TelemetryContextData GenerateTestTelemetryData()
{
return TelemetryContextData.Create();
}

public static void TestTelemetryData()
{
var contextData = GenerateTestTelemetryData();

TelemetryContext.Current.Begin(contextData);

Thread.CurrentPrincipal = new GenericPrincipal(new GenericIdentity("test_user", "test_authentication_type"),
    new[] { "test_role" });
            object[] x = new object[] { contextData.CorrelationId };
            Dictionary<string, object> y = new Dictionary<string, object>();
            y.Add("CorrelationId", contextData.CorrelationId);
            y.Add("RequestId", contextData.RequestId);

            var logEntry = new LogEntry(LoggingComponent.LogLevel.Error, "test object properties",x,y,null);

            ILogManager logManager = new NLogLogManager();
            LoggingComponent.ILogger _logger = logManager.Get();
            _logger.Log(logEntry);
            bool result1 =string.Equals(logEntry.Properties["Telemetry:Core:CorrelationId"], contextData.CorrelationId);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:RequestId"], contextData.RequestId);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:ParentRequestId"], contextData.ParentRequestId);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:IsInitialized"], true);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:Username"], Thread.CurrentPrincipal.Identity.Name);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:AuthenticationType"], Thread.CurrentPrincipal.Identity.AuthenticationType);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:IsAuthenticated"], Thread.CurrentPrincipal.Identity.IsAuthenticated);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:ThreadId"], Thread.CurrentThread.ManagedThreadId);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:ThreadName"], Thread.CurrentThread.Name);
 result1 = string.Equals(logEntry.Properties["Telemetry:Core:CultureName"], Thread.CurrentThread.CurrentCulture.Name);
}
}
}
