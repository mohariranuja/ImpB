﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Telemetry.Http
{
    public class TelemetryHttpHandler : DelegatingHandler
    {
        public TelemetryHttpHandler(HttpMessageHandler innerHandler)
            : base(innerHandler)
        {
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            if (TelemetryContext.Current.HasData)
            {
                var data = TelemetryContext.Current.Data;

                SetHeader(request, TelemetryConstants.HeaderNames.CorrelationId, data.CorrelationId.ToString());
                SetHeader(request, TelemetryConstants.HeaderNames.ParentRequestId, data.RequestId.ToString());
            }
            
            return base.SendAsync(request, cancellationToken);
        }

        private void SetHeader(HttpRequestMessage request, string key, string value)
        {
            if (request.Headers.Contains(key))
            {
                request.Headers.Remove(key);
            }

            request.Headers.Add(key, value);
        }
    }
}
