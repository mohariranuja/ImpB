﻿using System;

namespace LoggingComponent
{
    public class ConsoleLogManager : ILogManager
    {
        public ILogger Get()
        {
           return new ConsoleLogger("DEFAULT");
        }

        public ILogger Get(string name)
        {
            return new ConsoleLogger(name);
        }

        public ILogger Get<T>()
        {
            return Get(typeof (T));
        }

        public ILogger Get(Type type)
        {
            return Get(type.Name);
        }
    }
}
