﻿using System;
using System.Collections.Generic;

namespace LoggingComponent
{
    internal class ConsoleLogger : ILogger
    {
        private readonly string _name;

        public ConsoleLogger(string name)
        {
            _name = name;
        }

        private static readonly Dictionary<LogLevel, ConsoleColor> ColorMap = new Dictionary<LogLevel, ConsoleColor>
            {
                {LogLevel.Debug, ConsoleColor.Green},
                {LogLevel.Error, ConsoleColor.Red},
                {LogLevel.Fatal, ConsoleColor.DarkRed},
                {LogLevel.Trace, ConsoleColor.Red},
                {LogLevel.Warn, ConsoleColor.Yellow}
            };

        public void Flush()
        {
            // no-need to flush the console logger
        }

        public void Log(LogEntry logEntry)
        {
            var message = string.Format("{0} - {1} - {2}", _name, DateTime.Now,  FormatMessage(logEntry));

            if (logEntry.Exception != null)
            {
                message += Environment.NewLine + logEntry.Exception.Message + Environment.NewLine + logEntry.Exception.StackTrace;
            }

            ConsoleColor consoleColor;

            if (ColorMap.TryGetValue(logEntry.LogLevel, out consoleColor))
            {
                System.Console.ForegroundColor = consoleColor;
                System.Console.WriteLine(message);
                System.Console.ResetColor();
            }
            else
            {
                System.Console.WriteLine(message);
            }
        }

        private string FormatMessage(LogEntry logEntry)
        {
            if (logEntry.Parameters == null || logEntry.Parameters.Length == 0)
            {
                return logEntry.Message;
            }

            try
            {
                return string.Format(logEntry.Message, logEntry.Parameters);
            }
            catch (Exception exception)
            {
                System.Console.WriteLine("Error when formatting a message: {0}", exception);
                return logEntry.Message;
            }
        }
    }
}
