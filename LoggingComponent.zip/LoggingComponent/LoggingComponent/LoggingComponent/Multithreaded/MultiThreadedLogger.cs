﻿using System.Globalization;
using System.Threading;

namespace LoggingComponent
{
    internal class MultiThreadedLogger : ILogger
    {
        private readonly ILogger _logger;
        private readonly int _mainThreadId;

        public MultiThreadedLogger(ILogger logger, Thread mainThread)
        {
            _mainThreadId = mainThread.ManagedThreadId;
            _logger = logger;
        }

        public void Log(LogEntry logEntry)
        {
            var currentThreadId = Thread.CurrentThread.ManagedThreadId;
            var threadId = _mainThreadId == currentThreadId ? "Main" : currentThreadId.ToString(CultureInfo.InvariantCulture);

            _logger.Log(
                new LogEntry(logEntry.LogLevel, "Thread {0}: {1}", new[] {threadId, logEntry.Message},
                    logEntry.Properties));
        }

        public void Flush()
        {
            _logger.Flush();
        }
    }
}
