﻿namespace LoggingComponent
{
    public interface IOwinContext
    {
    }
}