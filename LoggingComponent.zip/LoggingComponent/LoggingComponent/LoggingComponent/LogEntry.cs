﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Telemetry;

namespace LoggingComponent
{
    /// <summary>
    /// Class LogEntry.
    /// </summary>
    public class LogEntry
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LogEntry"/> class.
        /// </summary>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        public LogEntry(LogLevel logLevel, string message)
            : this(logLevel, message, new object[0])
        {
            // This is called implicitly by the this() chained contstructor call, there's no need to set it twice here
            //InitializeProperties(null);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogEntry"/> class.
        /// </summary>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        /// <param name="parameters">The parameters.</param>
        public LogEntry(LogLevel logLevel, string message, object[] parameters)
        {
            LogLevel = logLevel;
            Message = message;
            Parameters = parameters;
            InitializeProperties(null);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogEntry"/> class.
        /// </summary>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="exception">The exception.</param>
        public LogEntry(LogLevel logLevel, string message, object[] parameters, Exception exception)
        {
            LogLevel = logLevel;
            Message = message;
            Parameters = parameters;
            Exception = exception;
            InitializeProperties(null);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogEntry"/> class.
        /// </summary>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="properties">Custom properties dictionary for this log entry</param>
        public LogEntry(LogLevel logLevel, string message, object[] parameters, IDictionary<string, object> properties)
        {
            LogLevel = logLevel;
            Message = message;
            Parameters = parameters;
            InitializeProperties(properties);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogEntry"/> class.
        /// </summary>
        /// <param name="logLevel">The log level.</param>
        /// <param name="message">The message.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="exception">The exception.</param>
        /// <param name="properties">Custom properties dictionary for this log entry</param>
        public LogEntry(LogLevel logLevel, string message, object[] parameters, IDictionary<string, object> properties, Exception exception)
        {
            LogLevel = logLevel;
            Message = message;
            Exception = exception;
            Parameters = parameters;
            InitializeProperties(properties);
        }

        private void InitializeProperties(IDictionary<string, object> properties)
        {
            if (properties?.Any() == true)
            {
                foreach (var property in properties)
                {
                    SetPropertyValue(property.Key, property.Value, "");
                }
            }

            if (TelemetryContext.Current.HasData)
            {
                var telemetryData = TelemetryContext.Current.Data.ToDictionary();

                if (telemetryData != null)
                {
                    foreach (var property in telemetryData)
                    {
                        SetPropertyValue(property.Key, property.Value);
                    }
                }

                SetPropertyValue("IsInitialized", true);
            }
            else
            {
                SetPropertyValue("IsInitialized", false);
            }

            SetPropertyValue("Username", Thread.CurrentPrincipal?.Identity?.Name);
            SetPropertyValue("AuthenticationType", Thread.CurrentPrincipal?.Identity?.AuthenticationType);
            SetPropertyValue("IsAuthenticated", Thread.CurrentPrincipal?.Identity?.IsAuthenticated ?? false);
            SetPropertyValue("ThreadId", Thread.CurrentThread?.ManagedThreadId);
            SetPropertyValue("ThreadName", Thread.CurrentThread?.Name);
            SetPropertyValue("CultureName", Thread.CurrentThread?.CurrentCulture?.Name);
        }

        private void SetPropertyValue(string key, object value, string prefix = "Telemetry:Core:")
        {
            var propertyKey = $"{prefix}{key}";

            if (Properties.ContainsKey(key))
                Properties[propertyKey] = value;
            else
                Properties.Add(propertyKey, value);
        }

        /// <summary>
        /// Gets the exception.
        /// </summary>
        /// <value>The exception.</value>
        public Exception Exception { get; private set; }

        /// <summary>
        /// Gets the log level.
        /// </summary>
        /// <value>The log level.</value>
        public LogLevel LogLevel { get; private set; }

        /// <summary>
        /// Gets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; private set; }

        /// <summary>
        /// Gets the parameters.
        /// </summary>
        /// <value>The parameters.</value>
        public object[] Parameters { get; private set; }

        /// <summary>
        /// Custom properties dictionary for this log entry
        /// </summary>
        public IDictionary<string, object> Properties { get; private set; } = new Dictionary<string, object>();
    }
}