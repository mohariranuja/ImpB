﻿namespace LoggingComponent
{
    public interface ILogger
    {
        void Flush();

        void Log(LogEntry logEntry);
    }
}
