﻿using System;

namespace Logging.WebApi
{
    internal class JavaScriptSerializer
    {
        public JavaScriptSerializer()
        {
        }

        internal string Serialize(object @object)
        {
            throw new NotImplementedException();
        }
    }
}