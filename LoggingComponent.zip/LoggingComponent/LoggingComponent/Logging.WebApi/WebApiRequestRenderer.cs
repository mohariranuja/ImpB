﻿
using System.Net.Http;
using System.Text;
using NLog;
using NLog.LayoutRenderers;

namespace Logging.WebApi
{
    /// <summary>
    /// Layout renderer for asp.net's web api traced http request message.
    /// </summary>
    [LayoutRenderer("webapi-request")]
    public class WebApiRequestRenderer : LayoutRenderer, IWebApiRequestRenderer
    {

        /// <summary>
        /// Request's route template
        /// </summary>
        /// <value><c>true</c> if route; otherwise, <c>false</c>.</value>
        /// <example>${webapi-request:route=true}</example>
        public bool Route { get; set; }

        /// <summary>
        /// Http method for request
        /// </summary>
        /// <value><c>true</c> if method; otherwise, <c>false</c>.</value>
        /// <example>${webapi-request:method=true}</example>
        public bool Method { get; set; }

        /// <summary>
        /// Absolute request Uri
        /// </summary>
        /// <value><c>true</c> if URI; otherwise, <c>false</c>.</value>
        /// <example>${webapi-request:uri=true}</example>
        public bool Uri { get; set; }

        /// <summary>
        /// Request's Http Content
        /// </summary>
        /// <value><c>true</c> if content; otherwise, <c>false</c>.</value>
        /// <example>${webapi-request:content=true}</example>
        public bool Content { get; set; }

        /// <summary>
        /// Appends the specified builder.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="logEvent">The log event.</param>
        protected override void Append(StringBuilder builder, LogEventInfo logEvent)
        {
            object value;
            if (!logEvent.Properties.TryGetValue(NLogTraceWriter.RequestKey, out value))
                return;

            var request = value as HttpRequestMessage;
            if (request == null)
                return;

            if (request != null)
            {
                if (Route)
                    builder.Append(request.GetRouteData().Route.RouteTemplate);

                if (Method)
                    builder.Append(request.Method.Method);

                if (Uri)
                    builder.Append(request.RequestUri.AbsoluteUri);

                if (Content)
                    builder.Append(request.Content.ReadAsStringAsync().Result);

            }
        }
    }
}