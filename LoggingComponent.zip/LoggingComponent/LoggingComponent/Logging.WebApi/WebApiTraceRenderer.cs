﻿using NLog;
using NLog.LayoutRenderers;
using System;
using System.Text;
using System.Web.Http.Tracing;

namespace Logging.WebApi
{
    /// <summary>
    ///     Layout renderer for asp.net's web api trace record.
    /// </summary>
    [LayoutRenderer("webapi-trace")]
    public class WebApiTraceRenderer : LayoutRenderer, IWebApiTraceRenderer
    {
        /// <summary>
        /// Name of the operation being performed during the trace. (e.g., Method)
        /// </summary>
        /// <value><c>true</c> if operation; otherwise, <c>false</c>.</value>
        /// <example>${webapi-trace:operation:true}</example>
        public bool Operation { get; set; }

        /// <summary>
        /// Http Status Code (e.g, 200)
        /// </summary>
        /// <value><c>true</c> if [status code]; otherwise, <c>false</c>.</value>
        /// <example>${webapi-trace:statuscode:true}</example>
        public bool StatusCode { get; set; }

        /// <summary>
        /// Http Status Code Description (e.g., OK)
        /// </summary>
        /// <value><c>true</c> if status; otherwise, <c>false</c>.</value>
        /// <example>${webapi-trace:status:true}</example>
        public bool Status { get; set; }

        /// <summary>
        /// Trace Request Guid; used for correlation.
        /// </summary>
        /// <value><c>true</c> if [request identifier]; otherwise, <c>false</c>.</value>
        /// <example>${webapi-trace:requestid:true}</example>
        public bool RequestId { get; set; }

        /// <summary>
        /// Name of the Operator of the Trace (e.g, MyApiController)
        /// </summary>
        /// <value><c>true</c> if operator; otherwise, <c>false</c>.</value>
        /// <example>${webapi-trace:operator:true}</example>
        public bool Operator { get; set; }

        /// <summary>
        /// Type of Trace (i.e, Begin, End, Trace)
        /// </summary>
        /// <value><c>true</c> if kind; otherwise, <c>false</c>.</value>
        /// <example>${webapi-trace:kind:true}</example>
        public bool Kind { get; set; }

        /// <summary>
        /// Appends the specified builder.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="logEvent">The log event.</param>
        protected override void Append(StringBuilder builder, LogEventInfo logEvent)
        {
            object value;
            if (!logEvent.Properties.TryGetValue(NLogTraceWriter.RecordKey, out value))
                return;

            var record = value as TraceRecord;
            if (record == null)
                return;

            if (Operation)
                builder.Append(record.Operation);

            if (Status)
                builder.Append(record.Status);

            if (StatusCode)
                builder.Append(Convert.ToInt32(record.Status));

            if (RequestId)
                builder.Append(record.RequestId);

            if (Operator)
                builder.Append(record.Operator);

            if (Kind)
                builder.Append(record.Kind);
        }
    }
}