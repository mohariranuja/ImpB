﻿namespace Logging.WebApi
{
    /// <summary>
    /// Interface IWebApiTraceRenderer
    /// </summary>
    internal interface IWebApiTraceRenderer
    {
        /// <summary>
        /// Name of the operation being performed during the trace. (e.g., Method)
        /// </summary>
        /// <value><c>true</c> if operation; otherwise, <c>false</c>.</value>
        bool Operation { get; set; }

        /// <summary>
        /// Http Status Code (e.g, 200)
        /// </summary>
        /// <value><c>true</c> if [status code]; otherwise, <c>false</c>.</value>
        bool StatusCode { get; set; }

        /// <summary>
        /// Http Status Code Description (e.g., OK)
        /// </summary>
        /// <value><c>true</c> if status; otherwise, <c>false</c>.</value>
        bool Status { get; set; }

        /// <summary>
        /// Trace Request Guid; used for correlation.
        /// </summary>
        /// <value><c>true</c> if [request identifier]; otherwise, <c>false</c>.</value>
        bool RequestId { get; set; }

        /// <summary>
        /// Name of the Operator of the Trace (e.g, MyApiController)
        /// </summary>
        /// <value><c>true</c> if operator; otherwise, <c>false</c>.</value>
        bool Operator { get; set; }

        /// <summary>
        /// Type of Trace (i.e, Begin, End, Trace)
        /// </summary>
        /// <value><c>true</c> if kind; otherwise, <c>false</c>.</value>
        bool Kind { get; set; }
    }
}