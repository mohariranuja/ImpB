﻿
namespace Logging.WebApi
{
    /// <summary>
    /// Interface IWebApiRequestRenderer
    /// </summary>
    internal interface IWebApiRequestRenderer
    {
        /// <summary>
        /// Request's route template
        /// </summary>
        /// <value><c>true</c> if route; otherwise, <c>false</c>.</value>
        bool Route { get; set; }

        /// <summary>
        /// Http method for request
        /// </summary>
        /// <value><c>true</c> if method; otherwise, <c>false</c>.</value>
        bool Method { get; set; }

        /// <summary>
        /// Absolute request Uri
        /// </summary>
        /// <value><c>true</c> if URI; otherwise, <c>false</c>.</value>
        bool Uri { get; set; }

        /// <summary>
        /// Request's Http Content
        /// </summary>
        /// <value><c>true</c> if content; otherwise, <c>false</c>.</value>
        bool Content { get; set; }
    }
}
