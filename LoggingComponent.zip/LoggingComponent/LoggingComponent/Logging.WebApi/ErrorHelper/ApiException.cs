﻿using System;
using System.Net;
using System.Runtime.Serialization;

namespace Logging.WebApi
{
    /// <summary>
    /// Api Exception
    /// </summary>
    [Serializable]
    [DataContract]
    public class ApiException : Exception, IApiExceptions
    {
        /// <summary>
        /// The reason phrase
        /// </summary>
        private string _reasonPhrase = "ApiException";

        /// <summary>
        /// ErrorCode
        /// </summary>
        /// <value>The error code.</value>
        [DataMember]
        public int ErrorCode { get; set; }

        /// <summary>
        /// ErrorDescription
        /// </summary>
        /// <value>The error description.</value>
        [DataMember]
        public string ErrorDescription { get; set; }

        /// <summary>
        /// HttpStatus
        /// </summary>
        /// <value>The HTTP status.</value>
        [DataMember]
        public HttpStatusCode HttpStatus { get; set; }

        /// <summary>
        /// ReasonPhrase
        /// </summary>
        /// <value>The reason phrase.</value>
        [DataMember]
        public string ReasonPhrase
        {
            get { return _reasonPhrase; }

            set { _reasonPhrase = value; }
        }
    }
}