﻿using System;
using System.Collections.Generic;
using System.Linq;
using NLog;
using NLog.Config;
using NLog.LayoutRenderers;
using NLog.Layouts;
using NLog.Targets;
using NUnit.Framework;
using LoggingComponent;
using Logging.Tests;


namespace  Logging.Tests

{
    [TestFixture]
    public class NLogLoggerTests
    {
        public LoggingComponent.ILogger Logger { get; }
        public   NLogLoggerTests()
        {
            
                // Step 1. Create configuration object 
                var config = new LoggingConfiguration();

                // Step 2. Create targets and add them to the configuration 
                var consoleTarget = new ColoredConsoleTarget();
                config.AddTarget("console", consoleTarget);

                var fileTarget = new FileTarget();
                config.AddTarget("file", fileTarget);

                // Step 3. Set target properties 
                consoleTarget.Layout = @"${date:format=HH\:mm\:ss} ${logger} ${message}";
                fileTarget.FileName = @"C:\global-logs\logs.txt";
                fileTarget.Layout = "${message}";
                // Step 4. Define rules
                var rule1 = new LoggingRule("*", NLog.LogLevel.Debug, consoleTarget);
                config.LoggingRules.Add(rule1);

                var rule2 = new LoggingRule("*", NLog.LogLevel.Debug, fileTarget);
                config.LoggingRules.Add(rule2);

                // Step 5. Activate the configuration
                LogManager.Configuration = config;
            }
        ////    public NLogLoggerTests()
        ////{
        ////   // LayoutRenderer.Register<InterceptLayoutRendererWrapper>("intercept");
            
        ////    var loggingConfig = new LoggingConfiguration();
        ////    var consoleTarget = new ConsoleTarget { Name = "TestTarget", Layout = Layout.FromString("${intercept:inner=${message} ${exception}}") };
        ////    loggingConfig.AddTarget(consoleTarget.Name, consoleTarget);
        ////  //  loggingConfig.AddRule(global::NLog.LogLevel.Trace, global::NLog.LogLevel.Fatal, "TestTarget", "*");
        ////    var loggerFactory = new LogFactory(loggingConfig);

        ////    Logger = new NLogLogger(loggerFactory.GetLogger("TestLog"));
        ////}

        [Test]
        public void XpoNlogLogger_ShouldLogExceptionAndFormattedMessage()
        {
            Logger.LogException(LoggingComponent.LogLevel.Error, "Something went wrong {0}, {1}, {2}", new object[] { 10, 9, 7 }, new Exception("TestExceptionMessage"));

            var msg = InterceptLayoutRendererWrapper.Message;
            Assert.AreEqual("Something went wrong 10, 9, 7 TestExceptionMessage", msg);
        }

        [Test]
        public void XpoNlogLogger_ShouldLogFormatMessage()
        {
            Logger.Log(new LogEntry(LoggingComponent.LogLevel.Error, "Something went wrong {0}, {1}, {2}", new object[]{2, 4, 5}));

            var msg = InterceptLayoutRendererWrapper.Message;

            // The renderer adds a space at the end
            Assert.AreEqual("Something went wrong 2, 4, 5 ", msg);
        }

        [Test]
        public void XpoNlogLogger_ShouldPassPropertiesAndPreserveMessage()
        {
            // The idea with passing custom properties is that you can use them to:
            //    1) Format your log message with custom data (for example, if you wanted to log data to a database table in custom fields)
            //    2) More importantly, passing custom telemetry data to the Lumberjack target

            var properties = new Dictionary<string, object>
            {
                {"Telemetry:TestObject:TestField1", 2},
                {"Telemetry:TestObject:TestField2", "Test235"}
            };

            var logEntry = new LogEntry(LoggingComponent.LogLevel.Error, "Something went wrong {0}, {1}, {2}", new object[] {2, 4, 5},
                properties);

            Logger.Log(logEntry);

            var msg = InterceptLayoutRendererWrapper.Message;
            var actualProperties = InterceptLayoutRendererWrapper.Properties;

            actualProperties = actualProperties.Where(p => !p.Key.ToString().StartsWith("Telemetry:Core"))
                .ToDictionary(x => x.Key, x => x.Value);

            // The renderer adds a space at the end
            Assert.AreEqual("Something went wrong 2, 4, 5 ", msg);

            // Dictionaries should be equal
            Assert.AreEqual(properties.Count, actualProperties.Count);
            Assert.False(actualProperties.Where(entry => properties[(string) entry.Key] != entry.Value)
                .ToDictionary(entry => entry.Key, entry => entry.Value).Any());
        }
    }
}
