﻿using System;
using System.Linq;
using NLog;
using LoggingComponent;

namespace Logging.NLog4
{
    /// <summary>
    /// Class NLogLogger.
    /// </summary>
    public class NLogLogger : LoggingComponent.ILogger
    {
        private readonly Logger _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="NLogLogger"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public NLogLogger(Logger logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Logs the specified log entry.
        /// </summary>
        /// <param name="logEntry">The log entry.</param>
        public void Log(LogEntry logEntry)
        {
            if(logEntry == null)
                throw new ArgumentNullException(nameof(logEntry));

            var message = FormatMessage(logEntry);
            var logLevel = NLog.LogLevel.FromString(logEntry.LogLevel.Name);

            var logEventInfo = new LogEventInfo
            {
                Level = logLevel,
                LoggerName = _logger.Name,
                Exception = logEntry.Exception,
                Message = message
            };

            if (logEntry?.Properties?.Any() == true)
            {
                foreach (var item in logEntry.Properties)
                {
                    logEventInfo.Properties.Add(item.Key, item.Value);
                }
            }

            _logger.Log(logEventInfo);
        }

        /// <summary>
        /// Formats the message.
        /// </summary>
        /// <param name="logEntry">The log entry.</param>
        /// <returns>String.</returns>
        private string FormatMessage(LogEntry logEntry)
        {
            if (logEntry.Parameters == null || logEntry.Parameters.Length == 0)
                return logEntry.Message;
            try
            {
                return string.Format(logEntry.Message, logEntry.Parameters);
            }
            catch (Exception exception)
            {
                _logger.Warn(exception, "Error when formatting a message: {0}", exception);
                return logEntry.Message;
            }
        }

        public void Flush()
        {
            if (_logger.Factory != null)
            {
                _logger.Factory.Flush();
            }
        }
    }
}