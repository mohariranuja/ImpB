﻿using System.Threading;

namespace Telemetry

{
    /// <summary>
    /// Cross   C FlowData class
    /// </summary>
    /// <typeparam name="T">The type of data to store.</typeparam>
    internal class FlowData<T>
    {
#if NET45

        private static readonly string _key = typeof(FlowData<T>).FullName;

        /// <summary>
        /// Gets or sets the value of the ambient data.
        /// </summary>
        public T Value
        {
            get
            {
                var handle = CallContext.LogicalGetData(_key) as ObjectHandle;
                return handle != null
                    ? (T)handle.Unwrap()
                    : default(T);
            }
            set { CallContext.LogicalSetData(_key, new ObjectHandle(value)); }
        }
#else
        private readonly static AsyncLocal<T> _backing = new AsyncLocal<T>();

        /// <summary>
        /// Gets or sets the value of the ambient data.
        /// </summary>
        public T Value
        {
            get { return _backing.Value; }
            set { _backing.Value = value; }
        }
#endif
    }
}
