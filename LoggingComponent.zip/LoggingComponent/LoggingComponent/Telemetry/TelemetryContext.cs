﻿namespace Telemetry
{
    public sealed class TelemetryContext
    {
        private static readonly TelemetryContext _instance = new TelemetryContext();

        private readonly FlowData<TelemetryContextData> _data;

        private TelemetryContext()
        {
            _data = new FlowData<TelemetryContextData>();
        }

        public void Begin(TelemetryContextData data)
        {
            _data.Value = data;
        }

        public TelemetryContextData Data => _data.Value;

        public bool HasData => Data != null;

        public void End()
        {
            _data.Value = null;
        }

        public static TelemetryContext Current => _instance;
    }
}