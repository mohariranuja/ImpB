﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telemetry
{
    public static class TelemetryConstants
    {
        public static class HeaderNames
        {
            public static readonly string CorrelationId = "X-telem-correlation-id";
            public static readonly string ParentRequestId = "X-telem-parent-id";
            public static readonly string RequestId = "X-telem-id";
        }

        public static readonly string LogName = "TELEMETRY_LOG";
    }
}
